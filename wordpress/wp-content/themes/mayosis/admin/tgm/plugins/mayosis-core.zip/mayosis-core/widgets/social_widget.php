<?php
// Digital Social
class mayosis_social_widget extends WP_Widget {

function __construct() {
parent::__construct(
// Base ID of your widget
'mayosis_social_widget', 

// Widget name will appear in UI
esc_html__('Mayosis Social', 'mayosis'), 

// Widget description
array( 'description' => esc_html__( 'Your site&#8217;s Social Profiles.', 'mayosis' ), ) 
);
}

// Creating widget front-end
// This is where the action happens
public function widget( $args, $instance ) {
  $title = apply_filters( 'widget_title', $instance[ 'title' ] );
  $facebook = apply_filters( 'facebook', $instance[ 'facebook' ] );
  $twitter = apply_filters( 'twitter', $instance[ 'twitter' ] );
  $google = apply_filters( 'google', $instance[ 'google' ] );
  $pinterest = apply_filters( 'pinterest', $instance[ 'pinterest' ] );
  $behance = apply_filters( 'behance', $instance[ 'behance' ] );
  $youtube = apply_filters( 'youtube', $instance[ 'youtube' ] );
  $target = apply_filters( 'target', $instance[ 'target' ] );
  $align = apply_filters( 'align', $instance[ 'align' ] );
  $without_bg = apply_filters( 'align', $instance[ 'without_bg' ] );
  echo $args['before_widget']; ?>
  <div class="sidebar-theme">
		<h2 class="footer-widget-title"><?php echo esc_html($title); ?></h2>

			<?php if ( $without_bg ){ ?>
			<div class="without-bg-social" style="text-align:<?php echo esc_html($align); ?>">
                   <?php if($facebook){ ?>
							<a href="<?php echo esc_url($facebook); ?>" class="facebook" target="_<?php echo esc_html($target); ?>"><i class="fa fa-facebook"></i></a>
							<?php } ?>
							
							 <?php if($twitter){ ?>
							<a href="<?php echo esc_url($twitter); ?>" class="twitter" target="_<?php echo esc_html($target); ?>"><i class="fa fa-twitter"></i></a>
							<?php } ?>
							<?php if($google){ ?>
							<a href="<?php echo esc_url($google); ?>" class="google" target="_<?php echo esc_html($target); ?>"><i class="fa fa-google-plus"></i></a>
							<?php } ?>
							
							<?php if($pinterest){ ?>
							<a href="<?php echo esc_url($pinterest); ?>" class="pinterest" target="_<?php echo esc_html($target); ?>"><i class="fa fa-pinterest-p"></i></a>
							<?php } ?>
							<?php if($behance){ ?>
							<a href="<?php echo esc_url($behance); ?>" class="behance" target="_<?php echo esc_html($target); ?>"><i class="fa fa-behance"></i></a>
			            	<?php } ?>
			            	
			            	<?php if($youtube){ ?>
				            <a href="<?php echo esc_url($youtube); ?>" class="youtube" target="_<?php echo esc_html($target); ?>"><i class="fa fa-youtube-play"></i></a>
				            <?php } ?>
						</div>
			<?php } else { ?>
			
                   <div class="social-profile" style="text-align:<?php echo esc_html($align); ?>">
                   <?php if($facebook){ ?>
							<a href="<?php echo esc_url($facebook); ?>" class="facebook" target="_<?php echo esc_html($target); ?>"><i class="fa fa-facebook"></i></a>
							<?php } ?>
							
							 <?php if($twitter){ ?>
							<a href="<?php echo esc_url($twitter); ?>" class="twitter" target="_<?php echo esc_html($target); ?>"><i class="fa fa-twitter"></i></a>
							<?php } ?>
							<?php if($google){ ?>
							<a href="<?php echo esc_url($google); ?>" class="google" target="_<?php echo esc_html($target); ?>"><i class="fa fa-google-plus"></i></a>
							<?php } ?>
							
							<?php if($pinterest){ ?>
							<a href="<?php echo esc_url($pinterest); ?>" class="pinterest" target="_<?php echo esc_html($target); ?>"><i class="fa fa-pinterest-p"></i></a>
							<?php } ?>
							<?php if($behance){ ?>
							<a href="<?php echo esc_url($behance); ?>" class="behance" target="_<?php echo esc_html($target); ?>"><i class="fa fa-behance"></i></a>
			            	<?php } ?>
			            	
			            	<?php if($youtube){ ?>
				            <a href="<?php echo esc_url($youtube); ?>" class="youtube" target="_<?php echo esc_html($target); ?>"><i class="fa fa-youtube-play"></i></a>
				            <?php } ?>
						</div>
                   <?php } ?>
<div class="clearfix"></div>
</div>
	<?php echo $args['after_widget'];
}
	/**
	 * Handles updating the settings for the current Digital Recent Productswidget instance.
	 *
	 * @since 2.8.0
	 * @access public
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Updated settings to save.
	 */
	/**
	 * Handles updating the settings for the current Digital Recent Productswidget instance.
	 *
	 * @since 2.8.0
	 * @access public
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Updated settings to save.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = sanitize_text_field( $new_instance['title'] );
		$instance['facebook'] = sanitize_text_field( $new_instance['facebook'] );
		$instance['twitter'] = sanitize_text_field( $new_instance['twitter'] );
		$instance['google'] = sanitize_text_field( $new_instance['google'] );
		$instance['pinterest'] = sanitize_text_field( $new_instance['pinterest'] );
		$instance['behance'] = sanitize_text_field( $new_instance['behance'] );
		$instance['youtube'] = sanitize_text_field( $new_instance['youtube'] );
		$instance['target'] = sanitize_text_field( $new_instance['target'] );
		$instance['align'] = sanitize_text_field( $new_instance['align'] );
		$instance['without_bg'] = sanitize_text_field( $new_instance['without_bg'] );
		

		return $instance;
	}

	/**
	 * Outputs the settings form for the Categories widget.
	 *
	 * @since 2.8.0
	 * @access public
	 *
	 * @param array $instance Current settings.
	 */
	public function form( $instance ) {
		//Defaults
		$instance = wp_parse_args( (array) $instance, array( 'title' => '') );
		$title = sanitize_text_field( $instance['title'] );
		$instance = wp_parse_args( (array) $instance, array( 'facebook' => '#') );
		$facebook = sanitize_text_field( $instance['facebook'] );
		$instance = wp_parse_args( (array) $instance, array( 'twitter' => '#') );
		$twitter= sanitize_text_field( $instance['twitter'] );
		$instance = wp_parse_args( (array) $instance, array( 'google' => '#') );
		$google= sanitize_text_field( $instance['google'] );
		$instance = wp_parse_args( (array) $instance, array( 'pinterest' => '#') );
		$pinterest= sanitize_text_field( $instance['pinterest'] );
		$instance = wp_parse_args( (array) $instance, array( 'behance' => '#') );
		$behance= sanitize_text_field( $instance['behance'] );
		$instance = wp_parse_args( (array) $instance, array( 'youtube' => '#') );
		$youtube= sanitize_text_field( $instance['youtube'] );
		$instance = wp_parse_args( (array) $instance, array( 'target' => 'self') );
		$target= sanitize_text_field( $instance['target'] );
		
		$instance = wp_parse_args( (array) $instance, array( 'align' => 'left') );
		$align= sanitize_text_field( $instance['align'] );
		$instance = wp_parse_args( (array) $instance, array( 'without_bg' => 'on') );
		$without_bg= sanitize_text_field( $instance['without_bg'] );
		?>
		<p><label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e( 'Title:','mayosis' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" /></p>
		
		<p><label for="<?php echo esc_attr($this->get_field_id('facebook')); ?>"><?php esc_html_e( 'Facebook:','mayosis' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('facebook'); ?>" name="<?php echo $this->get_field_name('facebook'); ?>" type="text" value="<?php echo esc_attr( $facebook ); ?>" /></p>
		
		<p><label for="<?php echo esc_attr($this->get_field_id('twitter')); ?>"><?php esc_html_e( 'Twitter:','mayosis' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('twitter'); ?>" name="<?php echo $this->get_field_name('twitter'); ?>" type="text" value="<?php echo esc_attr( $twitter ); ?>" /></p>
		
		<p><label for="<?php echo esc_attr($this->get_field_id('google')); ?>"><?php esc_html_e( 'Google:','mayosis' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('google'); ?>" name="<?php echo $this->get_field_name('google'); ?>" type="text" value="<?php echo esc_attr( $google ); ?>" /></p>
		
		<p><label for="<?php echo esc_attr($this->get_field_id('pinterest')); ?>"><?php esc_html_e( 'Pinterest:','mayosis' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('pinterest'); ?>" name="<?php echo $this->get_field_name('pinterest'); ?>" type="text" value="<?php echo esc_attr( $pinterest ); ?>" /></p>
		
		<p><label for="<?php echo esc_attr($this->get_field_id('behance')); ?>"><?php esc_html_e( 'Behance:','mayosis' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('behance'); ?>" name="<?php echo $this->get_field_name('behance'); ?>" type="text" value="<?php echo esc_attr( $behance ); ?>" /></p>
		
		<p><label for="<?php echo esc_attr($this->get_field_id('youtube')); ?>"><?php esc_html_e( 'Youtube:','mayosis' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('youtube'); ?>" name="<?php echo $this->get_field_name('youtube'); ?>" type="text" value="<?php echo esc_attr( $youtube ); ?>" /></p>

		<p><label for="<?php echo esc_attr($this->get_field_id('target')); ?>"><?php esc_html_e( 'Target(Input self or blank):','mayosis' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('target'); ?>" name="<?php echo $this->get_field_name('target'); ?>" type="text" value="<?php echo esc_attr( $target ); ?>" /></p>
		
		<p><label for="<?php echo esc_attr($this->get_field_id('align')); ?>"><?php esc_html_e( 'Align(Input left,right or center):','mayosis' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('align'); ?>" name="<?php echo $this->get_field_name('align'); ?>" type="text" value="<?php echo esc_attr( $align ); ?>" /></p>
		
		<p><input class="checkbox" type="checkbox" <?php checked( $instance['without_bg'], 'on' ); ?> id="<?php echo $this->get_field_id( 'without_bg' ); ?>" name="<?php echo $this->get_field_name( 'without_bg' ); ?>" /> 
    <label for="<?php echo esc_attr($this->get_field_id( 'without_bg' )); ?>"><?php _e('Show Icon Without Background', 'mayosis'); ?></label></p>
		<?php
	}

}
	
// Class mayosis_social_widget ends here

// Register and load the widget
function load_social_widget() {
	register_widget( 'mayosis_social_widget' );
}
add_action( 'widgets_init', 'load_social_widget' );