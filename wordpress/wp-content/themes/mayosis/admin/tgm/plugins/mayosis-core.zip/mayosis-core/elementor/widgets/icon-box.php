<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class icon_box_Elementor_Thing extends Widget_Base {

   public function get_name() {
      return 'mayosis-icon-box';
   }

   public function get_title() {
      return __( 'Mayosis Icon Box', 'mayosis' );
   }
public function get_categories() {
		return [ 'mayosis-ele-cat' ];
	}
   public function get_icon() { 
        return 'eicon-info-box';
   }

   protected function _register_controls() {

      $this->add_control(
         'section_icon_box',
         [
            'label' => __( 'Box Content', 'mayosis' ),
            'type' => Controls_Manager::SECTION,
         ]
      );

      $this->add_control(
         'section_heading',
         [
            'label' => __( 'Title', 'mayosis' ),
            'type' => Controls_Manager::TEXT,
            'default' => '',
            'title' => __( 'Enter Icon Box Title', 'mayosis' ),
            'section' => 'section_icon_box',
         ]
      );

		$this->add_control(
         'section_icon',
         [
            'label' => __( 'Icon', 'mayosis' ),
            'type' => Controls_Manager::ICON,
            'default' => '',
            'title' => __( 'Select Icon', 'mayosis' ),
            'section' => 'section_icon_box',
         ]
      );
      $this->add_control(
        	'show_cicon',
        	[
        		'label' => __( 'Show Custom Icon', 'mayosis' ),
        		'type' => Controls_Manager::SWITCHER,
        		'default' => '',
        		'label_on' => __( 'Show', 'mayosis' ),
        		'label_off' => __( 'Hide', 'mayosis' ),
        		'return_value' => 'yes',
        		'section' => 'section_icon_box',
        	]
        );
              $this->add_control(
         'image',
         [
            'label' => __( 'Custom Icon', 'mayosis' ),
            'type' => Controls_Manager::MEDIA,
            'section' => 'section_icon_box',
         ]
      );
      $this->add_control(
              'icon_width',
              [
                 'label'       => __( 'Custom Icon Width', 'mayosis' ),
                 'type'        => Controls_Manager::TEXT,
                 'default'     => __( '25', 'mayosis' ),
                 'placeholder' => __( 'Input only integear value', 'mayosis' ),
                 'section' => 'section_icon_box',
              ]
            );
            
            $this->add_control(
              'icon_height',
              [
                 'label'       => __( 'Custom Icon Width', 'mayosis' ),
                 'type'        => Controls_Manager::TEXT,
                 'default'     => __( '25', 'mayosis' ),
                 'placeholder' => __( 'Input only integear value', 'mayosis' ),
                 'section' => 'section_icon_box',
              ]
            );
      
		$this->add_control(
         'section_content',
         [
            'label' => __( 'Content', 'mayosis' ),
            'type' => Controls_Manager::TEXTAREA,
            'default' => '',
            'title' => __( 'Add Content', 'mayosis' ),
            'section' => 'section_icon_box',
         ]
      );
      
    $this->add_control(
         'section_icon_style',
         [
            'label' => __( 'Style', 'mayosis' ),
            'type' => Controls_Manager::SECTION,
         ]
      );
       
       $this->add_control(
         'icon_color',
         [
            'label' => __( 'Icon Color', 'mayosis' ),
            'type' => Controls_Manager::COLOR,
            'default' => '#ffffff',
            'title' => __( 'Select Icon Color', 'mayosis' ),
            'section' => 'section_icon_style',
         ]
      );
      
        $this->add_control(
         'icon_bg',
         [
            'label' => __( 'Icon Bg Color', 'mayosis' ),
            'type' => Controls_Manager::COLOR,
            'default' => '#4c00db',
            'title' => __( 'Select Icon Bg Color', 'mayosis' ),
            'section' => 'section_icon_style',
         ]
      );
      
       $this->add_control(
         'title_color',
         [
            'label' => __( 'Title Color', 'mayosis' ),
            'type' => Controls_Manager::COLOR,
            'default' => '#ffffff',
            'title' => __( 'Select Title Color', 'mayosis' ),
            'section' => 'section_icon_style',
         ]
      );
       
       $this->add_control(
         'content_color',
         [
            'label' => __( 'Content Color', 'mayosis' ),
            'type' => Controls_Manager::COLOR,
            'default' => '#ffffff',
            'title' => __( 'Select Content Color', 'mayosis' ),
            'section' => 'section_icon_style',
         ]
      );
       
       $this->add_control(
         'align_icon',
         [
            'label' => __( 'Icon Align', 'mayosis' ),
            'type' => Controls_Manager::SELECT,
            'default' => 'left',
            'title' => __( 'Select Icon Align', 'mayosis' ),
            'section' => 'section_icon_style',
             'options' => [
                    'left'  => __( 'Left', 'mayosis' ),
                    'center' => __( 'Center', 'mayosis' ),
                    'right' => __( 'Right', 'mayosis' ),
                 ],
         ]
      );
       
       $this->add_control(
         'align_image',
         [
            'label' => __( 'Custom Icon Align', 'mayosis' ),
            'type' => Controls_Manager::SELECT,
            'default' => 'center-block',
            'title' => __( 'Select Custom Icon Align', 'mayosis' ),
            'section' => 'section_icon_style',
             'options' => [
                    'align-left'  => __( 'Left', 'mayosis' ),
                    'center-block' => __( 'Center', 'mayosis' ),
                    'align-right' => __( 'Right', 'mayosis' ),
                 ],
         ]
      );
       $this->add_control(
         'align_title',
         [
            'label' => __( 'Title Align', 'mayosis' ),
            'type' => Controls_Manager::SELECT,
            'default' => 'left',
            'title' => __( 'Select Title Align', 'mayosis' ),
            'section' => 'section_icon_style',
             'options' => [
                    'left'  => __( 'Left', 'mayosis' ),
                    'center' => __( 'Center', 'mayosis' ),
                    'right' => __( 'Right', 'mayosis' ),
                 ],
         ]
      );

       $this->add_control(
         'align_content',
         [
            'label' => __( 'Content Align', 'mayosis' ),
            'type' => Controls_Manager::SELECT,
            'default' => 'left',
            'title' => __( 'Select Content Align', 'mayosis' ),
            'section' => 'section_icon_style',
             'options' => [
                    'left'  => __( 'Left', 'mayosis' ),
                    'center' => __( 'Center', 'mayosis' ),
                    'right' => __( 'Right', 'mayosis' ),
                 ],
         ]
      );
       
       $this->add_control(
         'icon_gradient',
         [
            'label' => __( 'Icon Gradient', 'mayosis' ),
            'type' => Controls_Manager::SELECT,
            'default' => 'no',
            'title' => __( 'Add Icon Gradient', 'mayosis' ),
            'section' => 'section_icon_style',
             'options' => [
                    'yes'  => __( 'Yes', 'mayosis' ),
                    'no' => __( 'No', 'mayosis' ),
                 ],
         ]
      );
    
       $this->add_control(
         'gradient_one',
         [
            'label' => __( 'Gradient Color One', 'mayosis' ),
            'type' => Controls_Manager::COLOR,
            'default' => '#ffffff',
            'title' => __( 'Select Gradient Color One', 'mayosis' ),
            'section' => 'section_icon_style',
         ]
      );
       
       $this->add_control(
         'gradient_two',
         [
            'label' => __( 'Gradient Color Two', 'mayosis' ),
            'type' => Controls_Manager::COLOR,
            'default' => '#ffffff',
            'title' => __( 'Select Gradient Color Two', 'mayosis' ),
            'section' => 'section_icon_style',
         ]
      );
       
       
       $this->add_control(
        	'icon_beside',
        	[
        		'label' => __( 'Icon Beside Title', 'mayosis' ),
        		'type' => Controls_Manager::SWITCHER,
        		'default' => '',
        		'label_on' => __( 'Yes', 'mayosis' ),
        		'label_off' => __( 'No', 'mayosis' ),
        		'return_value' => 'yes',
        		'section' => 'section_icon_style',
        	]
        );
   }

   protected function render( $instance = [] ) {

      // get our input from the widget settings.

       $settings = $this->get_settings();
       $images = $this->get_settings( 'image' );
      ?>



     <?php if ($settings['icon_beside'] == "yes"){ ?>
     <div class="quality-box quality-box-flex">
     <div class="icon-beside-title">
     <?php } else{ ?>
     <div class="quality-box">
     <div style="text-align:<?php echo $settings['align_icon']; ?>;">
     <?php } ?>
        
            <?php if ($settings['show_cicon'] == "yes"){ ?>
              <img src="<?php echo $images['url']; ?>" class="img-responsive <?php echo $settings['align_image']; ?>" alt="custom-img" style="width:<?php echo $settings['icon_width'];?>px; height:<?php echo $settings['icon_height'];?>px">
            <?php } else { ?>   
        <?php if($settings['icon_gradient'] == 'yes'){ ?>
		<i class="<?php echo $settings['section_icon']; ?>" aria-hidden="true" style="background: -webkit-linear-gradient(135deg,<?php echo $settings['gradient_one']; ?>, <?php echo $settings['gradient_two']; ?>);
-webkit-background-clip: text;
-webkit-text-fill-color: transparent;"></i>
       
        <?php } else { ?>				  
        <i class="<?php echo $settings['section_icon']; ?> icon-with-bg" aria-hidden="true" style="color:<?php echo $settings['icon_color']; ?>; background:<?php echo $settings['icon_bg']; ?>;"></i>
        <?php } ?>
               <?php } ?>  
			</div>
			  <?php if ($settings['icon_beside'] == "yes"){ ?>
			  <div class="icon-beside-title-text" style="color:<?php echo $settings['content_color']; ?>; text-align:<?php echo $settings['align_content']; ?>;">
			  <h2  style="color:<?php echo $settings['title_color']; ?>;text-align:<?php echo $settings['align_title']; ?>;"><?php echo $settings['section_heading']; ?></h2>
			  
			  <?php echo $settings['section_content']; ?>
			  </div>
			  <?php } else { ?>
			  <h2 style="color:<?php echo $settings['title_color']; ?>;text-align:<?php echo $settings['align_title']; ?>;"><?php echo $settings['section_heading']; ?></h2>
			  
			  <div style="color:<?php echo $settings['content_color']; ?>; text-align:<?php echo $settings['align_content']; ?>;"><?php echo $settings['section_content']; ?></div>
			  <?php } ?>
            
			
		</div>

      <?php

   }

   protected function content_template() {}

   public function render_plain_content( $instance = [] ) {}

}
Plugin::instance()->widgets_manager->register_widget_type( new icon_box_Elementor_Thing );
?>