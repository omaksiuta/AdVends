<?php
if (!defined('ABSPATH')) die('-1');

class VCExtendAddonClassrecentgrid
{

    function __construct()
    {
        add_action('init', array($this, 'recentWithVC'));
        add_action('wp_enqueue_scripts', array($this, 'productCSSAndJS'));
        add_shortcode('digital_edd_recent', array($this, 'renderJustifiedgrid'));
    }

    public function recentWithVC()
    {
        $categories_array = array(esc_html__('Select Category', 'mayosis') => '');
        $category_list = get_terms('download_category', array('hide_empty' => false));

        if (is_array($category_list) && !empty($category_list)) {
            foreach ($category_list as $category_details) {
                $begin = __(' (ID: ', 'mayosis');
                $end = __(')', 'mayosis');
                $categories_array[$category_details->name . $begin . $category_details->term_id . $end] = $category_details->term_id;
            }
        }

        vc_map(array(

            "base" => "digital_edd_recent",
            "name" => __("EDD Recent", 'mayosis'),
            "description" => __("mayosis easy digital download recent product grid", 'mayosis'),
            "class" => "",
            "icon" => get_template_directory_uri() . '/images/DM-Symbol-64px.png',
            "category" => __("Mayosis Elements", 'mayosis'),
            "params" => array(
                array(
                    'type' => 'textfield',
                    'heading' => __('Section Title', 'mayosis') ,
                    'param_name' => 'recent_section_title',
                    'value' => __('Recent Edd', 'mayosis') ,
                    'description' => __('Title for Recent Section', 'mayosis') ,
                ) ,
                array(
                    "type" => "textfield",
                    "heading" => __("Amount of Edd Recent to display:", 'mayosis') ,
                    "param_name" => "num_of_posts",
                    "description" => __("Choose how many news posts you would like to display.", 'mayosis') ,
                    'value' => __('3', 'mayosis') ,
                ) ,
                array(
                    "type" => "dropdown",
                    "heading" => __("Amount of Edd Recent Column:", 'mayosis') ,
                    "param_name" => "column_of_posts",
                    "description" => __("Choose how many news posts you would like to display.", 'mayosis') ,
                    "value" => array(
                        '1' => '1',
                        '2' => '2',
                        '3' => '3',
                        '4' => '4',
                        '5' => '5',
                        '6' => '6'
                    ) , //Add default value in $atts
                ) ,
                array(
                    "type" => "dropdown",
                    "heading" => __("Free Product Label(Download Count/ Free Label):", 'mayosis') ,
                    "param_name" => "free_product_label",
                    "description" => __("Choose How You want to show Free Product Label", 'mayosis') ,
                    "value" => array(
                        'Download Count' => '1',
                        'Custom Text Block' => '2'
                    ) , //Add default value in $atts
                ) ,
                array(
                    "type" => "textfield",
                    "heading" => __("Custom text", 'mayosis') ,
                    "param_name" => "custom_text",
                    "value" => '',
                    "description" => __("Set Custom text i.e. FREE", 'mayosis') ,
                    "dependency" => Array(
                        'element' => "free_product_label",
                        'value' => array(
                            '2'
                        )
                    )
                ) ,
                array(
                    "type" => "dropdown",
                    "heading" => __("Post Order", 'mayosis') ,
                    "param_name" => "post_order",
                    "description" => __("Set the order in which news posts will be displayed.", 'mayosis') ,
                    "value" => array(
                        'DESC' => 'DESC',
                        'ASC' => 'ASC'
                    ) , //Add default value in $atts
                ) ,

                array(
                    "type" => "dropdown",
                    "heading" => __("Show Product Category", 'mayosis'),
                    "param_name" => "category_product",
                    "description" => __("Show Product By Category", 'mayosis'),
                    "value" => array('No' => 'no','Yes' => 'yes'), //Add default value in $atts
                ),
                

                array(
                    "type" => "dropdown",
                    "heading" => __("Category", 'mayosis'),
                    "param_name" => "downloads_category",
                    "description" => __("Select a category", 'mayosis'),
                    'value' => $categories_array,
                    "dependency" => Array('element' => "category_product", 'value' => array('yes'))

                ),
                array(
                    "type" => "textfield",
                    "heading" => __("Custom Css", 'mayosis'),
                    "param_name" => "custom_css",
                    "description" => __("Custom Css Name", 'mayosis'),
                    'value' => __('', 'mayosis'),
                ),
            )

        ));
    }


    public function renderJustifiedgrid($atts, $content = null){

        //$custom_css = $el_class = $title = $icon = $output = $s_content = $number = '' ;
        $css = '';
        extract(shortcode_atts(array(
            "recent_section_title" => '',
            "num_of_posts" => '3',
            "column_of_posts" => '3',
            "post_order" => 'DESC',
            'category_product' =>'no',
            'downloads_category' => '',
            'free_product_label' => '1',
            'custom_text' => '',
            'custom_css' => ''
        ), $atts));



        /* ================  Render Shortcodes ================ */



        ob_start();

        if( $category_product == 'no' ) {
            //Fetch data
            $arguments = array(
                'post_type' => 'download',
                'post_status' => 'publish',
                //'posts_per_page' => -1,
                'order' => (string) trim($post_order),
                'posts_per_page' => $num_of_posts,
                'ignore_sticky_posts' => 1,

            );

            $post_query = new WP_Query($arguments);


        } else {

            //Fetch data
            $arguments = array(
                'post_type' => 'download',
                'post_status' => 'publish',
                //'posts_per_page' => -1,
                'order' => (string) trim($post_order),
                'posts_per_page' => $num_of_posts,
                'ignore_sticky_posts' => 1,

                'tax_query' => array(
                    array(
                        'taxonomy' => 'download_category',
                        'field' => 'term_id',
                        'terms' => $downloads_category,
                    )
                )
                //'tag' => get_query_var('tag')
            );
            $post_query = new WP_Query($arguments);
        }




        ?>

        <!-- Element Code start -->
    <div class="<?php
    echo esc_attr($custom_css); ?> edd_recent_ark">
        <h2 class="section-title"><?php
            echo esc_attr($recent_section_title); ?> </h2>

    <div<?php
    echo ($num_of_posts > 3 ? ' id="digital_post"' : ''); ?>>

        <div class="row fix">
        <?php
    if ($post_query->have_posts()):
    while ($post_query->have_posts()):
        $post_query->the_post(); ?>

        <?php
        if ($column_of_posts == "1") { ?>
        <div class="col-md-4 col-xs-12 col-sm-4 product-grid">
        <?php
        }
        elseif ($column_of_posts == "2") { ?>
        <div class="col-md-6 col-xs-12 col-sm-6 product-grid">
        <?php
        }
        elseif ($column_of_posts == "3") { ?>
        <div class="col-md-4 col-xs-12 col-sm-4 product-grid">
        <?php
        }
        elseif ($column_of_posts == "4") { ?>
        <div class="col-md-3 col-xs-12 col-sm-3 product-grid">
            <?php
            }
            elseif ($column_of_posts == "5") { ?>
            <div class="col-md-5ths col-xs-12 col-sm-5ths product-grid">
                <?php
                }
                elseif ($column_of_posts == "6") { ?>
                <div class="col-md-2 col-xs-12 col-sm-2 product-grid">
                    <?php
                    }
                    else { ?>
                    <div class="col-md-4 col-xs-12 col-sm-4 product-grid">
                        <?php
                        } ?>

                        <div class="grid_dm ribbon-box group edge">
                            <div class="product-box">
                                <?php
                                $postdate = get_the_time('Y-m-d'); // Post date
                                $postdatestamp = strtotime($postdate); // Timestamped post date
                                $newness = get_theme_mod('dm_days_products_new', '30'); // Newness in days
                                if ((time() - (60 * 60 * 24 * $newness)) < $postdatestamp) { // If the product was published within the newness time frame display the new badge
                                    echo '<div class="wrap-ribbon left-edge point lblue"><span>' . esc_html(__('New', 'mayosis')) . '</span></div>';
                                }

                                ?>
                                <figure class="mayosis-fade-in">
                                    <?php

                                    // display featured image?

                                    if (has_post_thumbnail()):
                                        the_post_thumbnail('full', array(
                                            'class' => 'img-responsive'
                                        ));
                                    endif;
                                    ?>
                                    <figcaption>
                                        <div class="overlay_content_center">
                                            <?php
                                            get_template_part('includes/product-hover-content-top'); ?>

                                            <div class="product_hover_details_button">
                                                <a href="<?php
                                                the_permalink(); ?>" class="button-fill-color"><?php
                                                    esc_html_e('View Details', 'mayosis'); ?></a>
                                            </div>
                                            <?php
                                            $demo_link = get_post_meta(get_the_ID() , 'demo_link', true);
                                            $livepreviewtext= get_theme_mod( 'live_preview_text','Live Preview' );
                                            ?>
                                            <?php
                                            if ($demo_link) { ?>
                                                <div class="product_hover_demo_button">
                                                    <a href="<?php
                                                    echo esc_url($demo_link); ?>" class="live_demo_onh" target="_blank"><?php echo esc_html($livepreviewtext); ?></a>
                                                </div>
                                                <?php
                                            } ?>

                                            <?php
                                            get_template_part('includes/product-hover-content-bottom'); ?>
                                        </div>
                                    </figcaption>

                                </figure>
                                <div class="product-meta">
                                    <?php
                                    get_template_part('includes/product-meta'); ?>

                                </div>

                            </div>
                        </div>


                    </div>

                    <?php
                    endwhile; ?>
                </div>
                <div class="clearfix"></div>
            </div>
            <!-- Element Code / END -->
        </div>
        <div class="clearfix"></div>
    <?php
    endif;
        wp_reset_postdata(); ?>
                  
        <?php

        $output = ob_get_clean();

        /* ================  Render Shortcodes ================ */

        return $output;

    }


    /*
        Load plugin css and javascript files which you may need on front end of your site
        */
    public function productCSSAndJS()
    {
        //  wp_register_style( 'vc_extend_style', plugins_url('assets/vc_extend.css', __FILE__) );
        // wp_enqueue_style( 'slick-slider-css', get_template_directory_uri() . '/css/slick.css' );

        // If you need any javascript files on front end, here is how you can load them.
    }
}
new VCExtendAddonClassrecentgrid();
