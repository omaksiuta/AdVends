<?php

if(!class_exists('WPBakeryShortCode')) return;

class WPBakeryShortCode_dm_icon_box extends WPBakeryShortCode {

    protected function content($atts, $content = null) {

        //$custom_css = $el_class = $title = $icon = $output = $s_content = $number = '' ;
		$css = '';
        extract(shortcode_atts(array(
			"title" => '',
			"icon" => 'fa fa-thumbs-o-up',
			//"animation_delay" => '0.3',
			"icon_color" => '#2C5C82',
			"title_color" => '#2C5C82',	
			"content_color" => '#ffffff',
			"content_align" =>'left',
			"icon_align" => 'left',		
			"title_align" => 'left',
			"icon_gradient" => '',
			"icon_color_gradient_1" => '#05efd7',
			"icon_color_gradient_2" => '#4434f6',
			'custom_image'=> '',
			'width_custom_image' =>'',
			'height_custom_image' => '',
			'icon_beside' =>'no',
			"custom_class" => '',
			'icon_bg_color'=>'#5a00f0',
			 'css' => ''
        ), $atts));
		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $this->settings['base'], $atts );


        /* ================  Render Shortcodes ================ */

        ob_start();

        ?>
        
        <?php 
			//$img = wp_get_attachment_image_src($el_image, "large"); 
			//$imgSrc = $img[0];
		?>

        <!-- Element Code start -->
        
            <?php if($icon_beside == "yes"){ ?>
            <div class="quality-box <?php echo esc_attr( $css_class ); ?> quality-box-flex <?php echo esc_attr( $custom_class ); ?>">
            <div class="icon-beside-title">
            <?php } else { ?>
            <div class="quality-box <?php echo esc_attr( $css_class ); ?>">
        <div style="text-align:<?php echo esc_attr($icon_align); ?>;">
            <?php } ?>
            <?php if($custom_image){ ?>
            <?php $customicon = wp_get_attachment_image_src($custom_image, 'thumbnail'); ?>
            <img src="<?php echo $customicon[0]; ?>" alt="custom-icon" style="width:<?php echo esc_attr($width_custom_image); ?>px;height:<?php echo esc_attr($height_custom_image); ?>px; ">
            <?php } else { ?>
            
            
        <?php if($icon_gradient == "on"){ ?>
         <?php } elseif($icon_gradient == "yes") { ?>
						<i class="<?php echo esc_attr($icon); ?>" aria-hidden="true" style="background: -webkit-linear-gradient(135deg,<?php echo esc_attr($icon_color_gradient_1); ?>, <?php echo esc_attr($icon_color_gradient_2); ?>);
-webkit-background-clip: text;
-webkit-text-fill-color: transparent;"></i>
						  <?php } else { ?>
						   <?php if($icon_beside == "yes"){ ?>
                      <i class="<?php echo esc_attr($icon); ?> icon-with-bg" aria-hidden="true" style="color:<?php echo esc_attr($icon_color); ?>; background:<?php echo esc_attr($icon_bg_color); ?>; "></i>
                      
                       <?php } else { ?>
                       
                        <i class="<?php echo esc_attr($icon); ?>" aria-hidden="true" style="color:<?php echo esc_attr($icon_color); ?>;"></i>
                        
                         <?php } ?>
                    <?php } ?>
                    
                    <?php } ?>
			</div>
			<?php if($icon_beside == "yes"){ ?>
		
				<div class="icon-beside-title-text" style="color:<?php echo esc_attr($content_color); ?>; text-align:<?php echo esc_attr($content_align); ?>;">
				    	<h2 style="color:<?php echo esc_attr($title_color); ?>;"><?php echo esc_attr($title); ?></h2>
				    <?php echo $content; ?>
				    
				    </div>
			<?php } else { ?>
			<h2 style="color:<?php echo esc_attr($title_color); ?>;text-align:<?php echo esc_attr($title_align); ?>;"><?php echo esc_attr($title); ?></h2>
				<div style="color:<?php echo esc_attr($content_color); ?>; text-align:<?php echo esc_attr($content_align); ?>;"><?php echo $content; ?></div>
			<?php } ?>
						
		
		</div><?php echo $this->endBlockComment('dm_icon_box'); ?>
        
        
        <!-- Element Code / END -->

        <?php

        $output = ob_get_clean();

        /* ================  Render Shortcodes ================ */

        return $output;

    }

}

vc_map( array(

    "base"      => "dm_icon_box",
    "name"      => __('Icon Box', 'mayosis'),
    "description"      => __('mayosis Text with icon', 'mayosis'),
    "class"     => "",
    "icon"      => get_template_directory_uri().'/images/DM-Symbol-64px.png',
    "category"  => __('Mayosis Elements', 'mayosis'),
    "params"    => array(
	
		array(
            "type" => "textfield",
            "heading" => __('Title', 'mayosis'),
            "param_name" => "title",
          
			"value" => '',
			"group" => 'General',
        ),
	
		array(
            "type" => "iconpicker",
            "heading" => __('Icon', 'mayosis'),
            "param_name" => "icon",
            "description" => __('Select Your Icon', 'mayosis'),
			"value" => 'fa fa-thumbs-o-up',
			"group" => 'General',
        ),
		    array(
                        'type' => 'attach_image',
                        'heading' => __( 'Custom Image', 'mayosis' ),
                        'param_name' => 'custom_image',
                        "group" => 'General',
                        'description' => __( 'Upload Custom Icon', 'mayosis' ),
                    ), 
		array(
            "type" => "textfield",
            "heading" => __('Custom Icon Width', 'mayosis'),
            "param_name" => "width_custom_image",
            'description' => __( 'Input without px', 'mayosis' ),
			"value" => '',
			"group" => 'General',
        ),
        array(
            "type" => "textfield",
            "heading" => __('Custom Icon Height', 'mayosis'),
            "param_name" => "height_custom_image",
            'description' => __( 'Input without px', 'mayosis' ),
			"value" => '',
			"group" => 'General',
        ),
		array(
            "type" => "colorpicker",
            "heading" => __('Icon Color', 'mayosis'),
            "param_name" => "icon_color",
			"value" => '#2C5C82',
			"group" => 'Style',
        ),
		
		array(
            "type" => "colorpicker",
            "heading" => __('Title Color', 'mayosis'),
            "param_name" => "title_color",
			"value" => '#2C5C82',
			"group" => 'Style',
        ),
	
	array(
            "type" => "colorpicker",
            "heading" => __('Icon Background Color', 'mayosis'),
            "param_name" => "icon_bg_color",
			"value" => '#5a00f0',
			"group" => 'Style',
			"dependency" => Array('element' => "icon_beside", 'value' => array('yes'))
        ),
        
        array(
            "type" => "colorpicker",
            "heading" => __('Content Color', 'mayosis'),
            "param_name" => "content_color",
			"value" => '#ffffff',
			"group" => 'Style',
        ),
        
	array(
            "type" => "dropdown",
            "heading" => __('Alignment of Icon', 'mayosis'),
            "param_name" => "icon_align",
            "description" => __('Choose Icon Align', 'mayosis'),
			"value"      => array( 'Left' => 'left', 'Center' => 'center', 'Right' => 'right' ), //Add default value in $atts
			"group" => 'Style',
        ),
	
	array(
            "type" => "dropdown",
            "heading" => __('Alignment of Title', 'mayosis'),
            "param_name" => "title_align",
            "description" => __('Choose Title Align', 'mayosis'),
			"value"      => array( 'Left' => 'left', 'Center' => 'center', 'Right' => 'right' ), //Add default value in $atts
			"group" => 'Style',
        ),
        
        	array(
            "type" => "dropdown",
            "heading" => __('Alignment of Content', 'mayosis'),
            "param_name" => "content_align",
            "description" => __('Choose Content Align', 'mayosis'),
			"value"      => array( 'Left' => 'left', 'Center' => 'center', 'Right' => 'right' ), //Add default value in $atts
			"group" => 'Style',
        ),
		
	array(
            "type" => "dropdown",
            "heading" => __('Gradient Icon', 'mayosis'),
            "param_name" => "icon_gradient",
            "description" => __('Choose Gradient or Not', 'mayosis'),
			"value"      => array( 'No' => 'no','Yes' => 'yes' ), //Add default value in $atts
			"group" => 'Style',
        ),
        
        array(
            "type" => "dropdown",
            "heading" => __('Icon Beside Title', 'mayosis'),
            "param_name" => "icon_beside",
            "description" => __('Choose Icon Position', 'mayosis'),
			"value"      => array( 'No' => 'no','Yes' => 'yes' ), //Add default value in $atts
			"group" => 'Style',
        ),
		
	
		array(
            "type" => "colorpicker",
            "heading" => __('Icon Color Gradient One', 'mayosis'),
            "param_name" => "icon_color_gradient_1",
          
			"value" => '#05efd7',
			"group" => 'Style',
			"dependency" => Array('element' => "icon_gradient", 'value' => array('yes'))
        ),
	
	array(
            "type" => "colorpicker",
            "heading" => __('Icon Color Gradient Two', 'mayosis'),
            "param_name" => "icon_color_gradient_2",
          
			"value" => '#4434f6',
			"group" => 'Style',
			"dependency" => Array('element' => "icon_gradient", 'value' => array('yes'))
        ),
		array(
            "type" => "textarea_html",
            "heading" => __('Content', 'mayosis'),
            "param_name" => "content",
			"group" => 'General',
            //"description" => __("Enter a short description for your service.", 'mayosis')
        ),
        	array(
            "type" => "textfield",
            "heading" => __("Custom Class", 'mayosis'),
            "param_name" => "custom_class",
            "description" => __("Add a custom Class.", 'mayosis'),
			"value" => '',
			"group" => 'Style'
        ),
	array(
            'type' => 'css_editor',
            'heading' => __( 'Css', 'mayosis' ),
            'param_name' => 'css',
            'group' => __( 'Design options', 'mayosis' ),
        ),


    )

));