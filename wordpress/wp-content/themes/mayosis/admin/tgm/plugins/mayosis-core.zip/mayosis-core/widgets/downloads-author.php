<?php
if ( class_exists( 'Easy_Digital_Downloads' ) ) :

add_action('widgets_init', 'dm_download_author');

function dm_download_author()
{
	register_widget('dm_download_author');
}

class dm_download_author extends WP_Widget {
	
	function __construct()
	{
		$widget_ops = array('classname' => 'dm_download_author', 'description' => esc_html__('Display Donwload Author Information','mayosis') );
		$control_ops = array('id_base' => 'dm_download_author');
		parent::__construct('dm_download_author', esc_html__('Mayosis Download Author widget','mayosis'), $widget_ops, $control_ops);
		
	}
	function widget($args, $instance)
	{
		extract($args);
	
		$title = $instance['title'];
		echo $before_widget;
		?>
		<?php 
		$postID = $wp_query->post->ID;
		$author = get_user_by( 'id', get_query_var( 'author' ) );
		$authorName=get_user_meta($author->ID,'nickname');
$authorDetails=get_userdata($author->ID);
?>
		<div class="single-product-widget">
			<h2 class="widget-title"><i class="fa fa-user" aria-hidden="true"></i>  <?php echo esc_html($title); ?> </h2>
			<div class="author_widget_box">
				<div class="author_image">
				
					<?php
		echo get_avatar(get_the_author_meta( 'ID' ), '150', $default, $alt,$author, array(
			'class' => array(
				'center-block',
				'img-responsive'
			)
		)); ?>
				</div>
				<h3 class="text-center widget_author_title"><a href="<?php echo esc_url(add_query_arg( 'author_downloads', 'true', get_author_posts_url( get_the_author_meta('ID')) )); ?>"><?php the_author(); ?></a></h3>
			<div class="author_social_items">
						<h4><?php esc_html_e('Network','mayosis'); ?></h4>
						<ul class="icons">
					<?php 
						$rss_url = get_the_author_meta( 'rss_url' );
						if ( $rss_url && $rss_url != '' ) {
							echo '<li class="rss"><a href="' . esc_url($rss_url) . '"><i class="fa fa-rss" aria-hidden="true"></i>
</a></li>';
						}
						
						$google_profile = get_the_author_meta( 'google_profile' );
						if ( $google_profile && $google_profile != '' ) {
							echo '<li class="google"><a href="' . esc_url($google_profile) . '" rel="author"><i class="fa fa-google-plus" aria-hidden="true"></i>
</a></li>';
						}
						
						$twitter_profile = get_the_author_meta( 'twitter_profile' );
						if ( $twitter_profile && $twitter_profile != '' ) {
							echo '<li class="twitter"><a href="' . esc_url($twitter_profile) . '"><i class="fa fa-twitter" aria-hidden="true"></i>
</a></li>';
						}
						
						$facebook_profile = get_the_author_meta( 'facebook_profile' );
						if ( $facebook_profile && $facebook_profile != '' ) {
							echo '<li class="facebook"><a href="' . esc_url($facebook_profile) . '"><i class="fa fa-facebook" aria-hidden="true"></i>
</a></li>';
						}
						
						$linkedin_profile = get_the_author_meta( 'linkedin_profile' );
						if ( $linkedin_profile && $linkedin_profile != '' ) {
							echo '<li class="linkedin"><a href="' . esc_url($linkedin_profile) . '"><i class="fa fa-linkedin" aria-hidden="true"></i>
</a></li>';
						}
					?>
				</ul>
			</div>
	</div>
	<div class="clearfix"></div>
		<?php
		echo $after_widget;
	}

	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		return $instance;
	}
	
	function form($instance)
	{
		$defaults = array('title' => esc_html__('Download Author','mayosis') );
		$instance = wp_parse_args((array) $instance, $defaults); ?>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title','mayosis');?>:</label>
			<input id="<?php echo esc_attr($this->get_field_id('title')); ?>" class="widefat" name="<?php echo esc_attr($this->get_field_name('title')); ?>" value="<?php echo esc_attr($instance['title']); ?>" />
		</p>
		<?php }
	}

endif;