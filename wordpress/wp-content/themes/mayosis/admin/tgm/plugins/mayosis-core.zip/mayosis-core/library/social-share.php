<?php

// //////////////////////////////////////////////////////////////////////////////////////////
// ////////////////////  Grid Social /////////////////////////////////////////
// /////////////////////////////////////////////////////////////////////////////////////////

function mayosis_gridsocial() {

    $dmsocialURL = urlencode(get_permalink());

    // Get current page title
    $dmsocialTitle = str_replace( ' ', '%20', get_the_title());


    // Construct sharing URL without using any script
    $twitterURL = 'https://twitter.com/share?url=' . $dmsocialURL . '&amp;text=' . $dmsocialTitle;
    $facebookURL = 'https://www.facebook.com/sharer/sharer.php?u='.$dmsocialURL;
    $googleURL = 'https://plus.google.com/share?url='.$dmsocialURL;
    $bufferURL = 'https://bufferapp.com/add?url='.$dmsocialURL.'&amp;text='.$dmsocialTitle;
    $whatsappURL = 'whatsapp://send?text='.$dmsocialTitle . ' ' . $dmsocialURL;
    $linkedInURL = 'https://www.linkedin.com/shareArticle?mini=true&url='.$dmsocialURL.'&amp;title='.$dmsocialTitle;

    // Based on popular demand added Pinterest too
    $pinterestURL = 'https://pinterest.com/pin/create/button/?url='.$dmsocialURL.'&amp;description='.$dmsocialTitle;

    echo '<div class="social-button">';
    echo '<i class="fas fa-share-alt"></i>';
    echo '<span>Share</span>';
    echo '<a href="'.$facebookURL.'" target="_blank" class="facebook"><i class="fa fa-facebook-f"></i></a>';
    echo '<a href="'.$twitterURL.'" target="_blank" class="twitter"><i class="fab fa-twitter"></i></a>';
    echo '<a href="'.$googleURL.'" target="_blank" class="google"><i class="fab fa-google-plus-g"></i></a>';
    echo'</div>';


};


// //////////////////////////////////////////////////////////////////////////////////////////
// ////////////////////  Product Breadcrumb Social /////////////////////////////////////////
// /////////////////////////////////////////////////////////////////////////////////////////

function mayosis_productbreadcrubm() {

    $dmsocialURL = urlencode(get_permalink());

    // Get current page title
    $dmsocialTitle = str_replace( ' ', '%20', get_the_title());


    // Construct sharing URL without using any script
    $twitterURL = 'https://twitter.com/share?url=' . $dmsocialURL . '&amp;text=' . $dmsocialTitle;
    $facebookURL = 'https://www.facebook.com/sharer/sharer.php?u='.$dmsocialURL;
    $googleURL = 'https://plus.google.com/share?url='.$dmsocialURL;
    $bufferURL = 'https://bufferapp.com/add?url='.$dmsocialURL.'&amp;text='.$dmsocialTitle;
    $whatsappURL = 'whatsapp://send?text='.$dmsocialTitle . ' ' . $dmsocialURL;
    $linkedInURL = 'https://www.linkedin.com/shareArticle?mini=true&url='.$dmsocialURL.'&amp;title='.$dmsocialTitle;

    // Based on popular demand added Pinterest too
    $pinterestURL = 'https://pinterest.com/pin/create/button/?url='.$dmsocialURL.'&amp;description='.$dmsocialTitle;
    ?>
    <div class="social-button">
        <span>Share</span>
        <a href="<?php echo $facebookURL; ?>" onclick="window.open(this.href, 'facebookwindow','left=20,top=20,width=500,height=400,toolbar=0,resizable=1'); return false;" class="facebook"><i class="fa fa-facebook-f"></i></a>


        <a href="<?php echo $twitterURL; ?>"  onclick="window.open(this.href, 'twitterwindow','left=20,top=20,width=500,height=400,toolbar=0,resizable=1'); return false;" class="twitter"><i class="fab fa-twitter"></i></a>

        <a href="<?php echo $googleURL; ?>"  onclick="window.open(this.href, 'googlepluswindow','left=20,top=20,width=500,height=400,toolbar=0,resizable=1'); return false;" class="google"><i class="fab fa-google-plus-g"></i></a>

        <a href="<?php echo $pinterestURL; ?>" onclick="window.open(this.href, 'pinterestwindow','left=20,top=20,width=500,height=400,toolbar=0,resizable=1'); return false;" class="pinterest"><i class="fab fa-pinterest-p"></i></a>

    </div>


<?php }


// //////////////////////////////////////////////////////////////////////////////////////////
// ////////////////////  Product Bottom Button /////////////////////////////////////////
// /////////////////////////////////////////////////////////////////////////////////////////

function mayosis_productbottombutton() {

    $dmsocialURL = urlencode(get_permalink());

    // Get current page title
    $dmsocialTitle = str_replace( ' ', '%20', get_the_title());


    // Construct sharing URL without using any script
    $twitterURL = 'https://twitter.com/share?url=' . $dmsocialURL . '&amp;text=' . $dmsocialTitle;
    $facebookURL = 'https://www.facebook.com/sharer/sharer.php?u='.$dmsocialURL;
    $googleURL = 'https://plus.google.com/share?url='.$dmsocialURL;
    $bufferURL = 'https://bufferapp.com/add?url='.$dmsocialURL.'&amp;text='.$dmsocialTitle;
    $whatsappURL = 'whatsapp://send?text='.$dmsocialTitle . ' ' . $dmsocialURL;
    $linkedInURL = 'https://www.linkedin.com/shareArticle?mini=true&url='.$dmsocialURL.'&amp;title='.$dmsocialTitle;

    // Based on popular demand added Pinterest too
    $pinterestURL = 'https://pinterest.com/pin/create/button/?url='.$dmsocialURL.'&amp;description='.$dmsocialTitle;
    ?>
    <div class="social-button-bottom">
        <span>Share</span>
        <a href="<?php echo $facebookURL; ?>" onclick="window.open(this.href, 'facebookwindow','left=20,top=20,width=500,height=400,toolbar=0,resizable=1'); return false;" class="facebook"><i class="fa fa-facebook-f"></i></a>


        <a href="<?php echo $twitterURL; ?>"  onclick="window.open(this.href, 'twitterwindow','left=20,top=20,width=500,height=400,toolbar=0,resizable=1'); return false;" class="twitter"><i class="fab fa-twitter"></i></a>

        <a href="<?php echo $googleURL; ?>"  onclick="window.open(this.href, 'googlepluswindow','left=20,top=20,width=500,height=400,toolbar=0,resizable=1'); return false;" class="google"><i class="fab fa-google-plus-g"></i></a>

        <a href="<?php echo $pinterestURL; ?>" onclick="window.open(this.href, 'pinterestwindow','left=20,top=20,width=500,height=400,toolbar=0,resizable=1'); return false;" class="pinterest"><i class="fab fa-pinterest-p"></i></a>
    </div>


<?php }


// //////////////////////////////////////////////////////////////////////////////////////////
// ////////////////////  Photo Social /////////////////////////////////////////
// /////////////////////////////////////////////////////////////////////////////////////////

function mayosis_photosocial() {

    $dmsocialURL = urlencode(get_permalink());

    // Get current page title
    $dmsocialTitle = str_replace( ' ', '%20', get_the_title());


    // Construct sharing URL without using any script
    $twitterURL = 'https://twitter.com/share?url=' . $dmsocialURL . '&amp;text=' . $dmsocialTitle;
    $facebookURL = 'https://www.facebook.com/sharer/sharer.php?u='.$dmsocialURL;
    $googleURL = 'https://plus.google.com/share?url='.$dmsocialURL;
    $bufferURL = 'https://bufferapp.com/add?url='.$dmsocialURL.'&amp;text='.$dmsocialTitle;
    $whatsappURL = 'whatsapp://send?text='.$dmsocialTitle . ' ' . $dmsocialURL;
    $linkedInURL = 'https://www.linkedin.com/shareArticle?mini=true&url='.$dmsocialURL.'&amp;title='.$dmsocialTitle;

    // Based on popular demand added Pinterest too
    $pinterestURL = 'https://pinterest.com/pin/create/button/?url='.$dmsocialURL.'&amp;description='.$dmsocialTitle;
    ?>
    <div class="photo-template-social">
        <a href="<?php echo $facebookURL; ?>" onclick="window.open(this.href, 'facebookwindow','left=20,top=20,width=500,height=400,toolbar=0,resizable=1'); return false;" class="facebook"><i class="fa fa-facebook-f"></i></a>


        <a href="<?php echo $twitterURL; ?>"  onclick="window.open(this.href, 'twitterwindow','left=20,top=20,width=500,height=400,toolbar=0,resizable=1'); return false;" class="twitter"><i class="fab fa-twitter"></i></a>

        <a href="<?php echo $googleURL; ?>"  onclick="window.open(this.href, 'googlepluswindow','left=20,top=20,width=500,height=400,toolbar=0,resizable=1'); return false;" class="google"><i class="fab fa-google-plus-g"></i></a>

        <a href="<?php echo $pinterestURL; ?>" onclick="window.open(this.href, 'pinterestwindow','left=20,top=20,width=500,height=400,toolbar=0,resizable=1'); return false;" class="pinterest"><i class="fab fa-pinterest-p"></i></a>
    </div>


<?php }

