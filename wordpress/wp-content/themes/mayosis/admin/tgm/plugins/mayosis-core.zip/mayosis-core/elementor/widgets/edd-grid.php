<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class mayosis_edd_grid_Elementor_Thing extends Widget_Base {

    public function get_name() {
        return 'mayosis-edd-grid';
    }

    public function get_title() {
        return __( 'Mayosis EDD Grid', 'mayosis' );
    }
    public function get_categories() {
        return [ 'mayosis-ele-cat' ];
    }
    public function get_icon() {
        return 'eicon-posts-grid';
    }

    protected function _register_controls() {

        $this->add_control(
            'section_edd',
            [
                'label' => __( 'mayosis EDD Grid', 'mayosis' ),
                'type' => Controls_Manager::SECTION,
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => __( 'Section Title', 'mayosis' ),
                'type' => Controls_Manager::TEXT,
                'default' => '',
                'title' => __( 'Enter Section Title', 'mayosis' ),
                'section' => 'section_edd',
            ]
        );

        $this->add_control(
            'item_per_page',
            [
                'label'   => esc_html_x( 'Amount of item to display', 'Admin Panel', 'mayosis' ),
                'type'    => Controls_Manager::NUMBER,
                'default' =>  "10",
                'section' => 'section_edd',
            ]
        );

        $this->add_control(
            'show_category',
            [
                'label'     => esc_html_x( 'Filter Category Wise', 'Admin Panel','mayosis' ),
                'description' => esc_html_x('Select if want to show product by category', 'mayosis' ),
                'type'      =>  Controls_Manager::SELECT,
                'default'    =>  "no",
                'section' => 'section_edd',
                "options"    => array(
                    "yes" => "Yes",
                    "no" => "No",

                ),
            ]

        );

        $this->add_control(
            'category',
            [
                'label' => __( 'Category Name', 'mayosis' ),
                'description' => __('Add one category slug','mayosis'),
                'type' => Controls_Manager::TEXT,
                'default' => '',
                'section' => 'section_edd',
            ]
        );

        $this->add_control(
            'order',
            [
                'label' => __( 'Order', 'mayosis' ),
                'type' => Controls_Manager::SELECT,
                'section' => 'section_edd',
                'options' => [
                    'asc' => 'Ascending',
                    'desc' => 'Descending'
                ],
                'default' => 'desc',

            ]
        );

    }

    protected function render( $instance = [] ) {

        // get our input from the widget settings.

        $settings = $this->get_settings();
        $post_count = ! empty( $settings['item_per_page'] ) ? (int)$settings['item_per_page'] : 5;
        $posts_category= $settings['category'];
        $post_order_term=$settings['order'];
        ?>




        <div class="full--grid-elementor">
            <h2 class="section-title"> <?php echo $settings['title']; ?></h2>
            <div class="fix">

                <?php
                global $post;
                if($settings['show_category'] == 'no') {
                    $args = array( 'post_type' => 'download','numberposts' => $post_count, 'category_name' => $posts_category,'order' => (string) trim($post_order_term), );
                } else {
                    $args = array(
                        'post_type' => 'download',
                        'numberposts' => $post_count,
                        'tax_query' => array(
                            array(
                                'taxonomy' => 'download_category',
                                'field' => 'slug',
                                'terms' => $posts_category,
                            ),
                        ),
                        'order' => (string)trim($post_order_term),);
                }
                $recent_posts = get_posts( $args ); ?>
                <ul class="recent_image_block">
                    <?php foreach( $recent_posts as $post ){?>

                        <li class="grid-product-box">
                            <div class="product-thumb grid_dm">
                                <figure class="mayosis-fade-in">
                                    <?php
                                    the_post_thumbnail( 'full', array( 'class' => 'img-responsive' ) );
                                    ?>
                                    <figcaption>
                                        <div class="overlay_content_center">
                                            <a href="<?php
                                            the_permalink(); ?>"><i class="fas fa-plus"></i></a>
                                        </div>
                                    </figcaption>
                                </figure>
                            </div>
                        </li>

                    <?php } ?>
                </ul>
                <?php  wp_reset_postdata();
                ?>
            </div>


        </div>
        <?php

    }

    protected function content_template() {}

    public function render_plain_content( $instance = [] ) {}

}
Plugin::instance()->widgets_manager->register_widget_type( new mayosis_edd_grid_Elementor_Thing );
?>