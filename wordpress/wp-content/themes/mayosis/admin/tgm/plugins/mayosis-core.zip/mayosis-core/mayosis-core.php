<?php
/* 
 * Plugin Name: Mayosis Core
 * Plugin URI: https://teconce.com
 * Description: This is core plugin for mayosis digital marketplace theme
 * Version:    2.1.1
 * Author:      Teconce Team
 * Author URI:  https://teconce.com
 * Text Domain: mayosis
 * Copyright:   2018, Teconce Team
 */

if( ! class_exists( 'mayosis_core' ) ) {
    class mayosis_core{

        /**
         * Plugin version, used for cache-busting of style and script file references.
         *
         * @since   1.0.0
         *
         * @var  string
         */
        const VERSION = '2.1.1';

        /**
         * Instance of this class.
         *
         * @since   1.0.0
         *
         * @var   object
         */
        protected static $instance = null;

        public function __construct(){
            add_action('init', array(&$this, 'init'));
            add_action('admin_init', array(&$this, 'admin_init'));
            add_action('after_setup_theme', array(&$this, 'load_digitalmarketplace_core_text_domain'));
            register_activation_hook(__FILE__, array($this,'plugin_activate')); //activate hook
            register_deactivation_hook(__FILE__, array($this,'plugin_deactivate')); //deactivate hook

        }

        /**
         * Register the plugin text domain
         *
         * @return void
         */
        function load_digitalmarketplace_core_text_domain() {
            load_plugin_textdomain( 'mayosis', false, dirname( plugin_basename(__FILE__) ) . '/languages' );
        }

        /**
         * Return an instance of this class.
         *
         * @since    1.0.0
         *
         * @return  object  A single instance of this class.
         */
        public static function get_instance() {

            // If the single instance hasn't been set, set it now.
            if ( null == self::$instance ) {
                self::$instance = new self;
            }

            return self::$instance;

        }


    }

}
// Load the instance of the plugin
add_action( 'mayosis_core', 'get_instance' );

// Footer Text
add_filter('admin_footer_text', 'mayosis_remove_footer_admin'); //footer info
function mayosis_remove_footer_admin () {
    echo '<span id="footer_text">'. esc_html__('Mayosis Digital Marketplace Theme Developed by','mayosis') .' <a href="https://teconce.com/" target="_blank">'. esc_html__('Teconce', 'mayosis') .'</a>'. esc_html__(' For Digital Marketplace by wordpress','mayosis')  . '</span>';
}
add_action('login_enqueue_scripts', 'digitalmarketplace_login_logo'); //login logo

add_filter('login_headertitle', 'digitalmarketplace_login_logo_url_title'); //login logo title

include( plugin_dir_path( __FILE__ ) .'library/login-backend.php');
include( plugin_dir_path( __FILE__ ) .'library/social-share.php');
include( plugin_dir_path( __FILE__ ) .'library/theme_customize.php');
include( plugin_dir_path( __FILE__ ) .'kirki/kirki.php');
include( plugin_dir_path( __FILE__ ) .'metabox/page.php');
include( plugin_dir_path( __FILE__ ) .'metabox/page-color.php');
include( plugin_dir_path( __FILE__ ) .'metabox/download-category.php');
include( plugin_dir_path( __FILE__ ) .'shortcodes/mayosis-shortcode.php');

include( plugin_dir_path( __FILE__ ) .'elementor/elementor-main.php');

include( plugin_dir_path( __FILE__ ) .'widgets/mayosis-instagram-widget.php');
include( plugin_dir_path( __FILE__ ) .'widgets/product-details.php');
include( plugin_dir_path( __FILE__ ) .'widgets/product-features.php');
include( plugin_dir_path( __FILE__ ) .'widgets/product-release-info.php');
include( plugin_dir_path( __FILE__ ) .'widgets/digital-recent-product.php');
include( plugin_dir_path( __FILE__ ) .'widgets/search_widget.php');
include( plugin_dir_path( __FILE__ ) .'widgets/post-categories.php');
include( plugin_dir_path( __FILE__ ) .'widgets/social_widget.php');
include( plugin_dir_path( __FILE__ ) .'widgets/about-us.php');
include( plugin_dir_path( __FILE__ ) .'widgets/subscribe.php');
include( plugin_dir_path( __FILE__ ) .'widgets/product_tag.php');
include( plugin_dir_path( __FILE__ ) .'widgets/blog_tag.php');
include( plugin_dir_path( __FILE__ ) .'widgets/recent_post.php');
include( plugin_dir_path( __FILE__ ) .'widgets/downloads-author.php');
include( plugin_dir_path( __FILE__ ) .'widgets/counter.php');
include( plugin_dir_path( __FILE__ ) .'widgets/recent-searches-widget.php');

if (class_exists('Easy_Digital_Downloads')):
    include( plugin_dir_path( __FILE__ ) .'metabox/edd-gallery.php');
    include( plugin_dir_path( __FILE__ ) .'metabox/edd-features.php');
    include( plugin_dir_path( __FILE__ ) .'metabox/edd.php');
    include( plugin_dir_path( __FILE__ ) .'library/edd-category-grid.php');
endif;
if (class_exists('WPBakeryShortCode')):


    include( plugin_dir_path( __FILE__ ) .'vc-elements/mayosis_icon_box.php');
    include( plugin_dir_path( __FILE__ ) .'vc-elements/mayosis_theme_button.php');
    include( plugin_dir_path( __FILE__ ) .'vc-elements/mayosis_post.php');
    include( plugin_dir_path( __FILE__ ) .'vc-elements/mayosis_clients.php');
    include( plugin_dir_path( __FILE__ ) .'vc-elements/mayosis_theme_dual_button.php');
    include( plugin_dir_path( __FILE__ ) .'vc-elements/mayosis_theme_hero.php');
    include( plugin_dir_path( __FILE__ ) .'vc-elements/mayosis_subscribe.php');
    include( plugin_dir_path( __FILE__ ) .'vc-elements/mayosis_testimonial.php');
    include( plugin_dir_path( __FILE__ ) .'vc-elements/mayosis_pricing_table.php');
    include( plugin_dir_path( __FILE__ ) .'vc-elements/mayosis_vc_extend.php');
    include( plugin_dir_path( __FILE__ ) .'vc-elements/mayosis_search.php');
    include( plugin_dir_path( __FILE__ ) .'vc-elements/mayosis_counter.php');
    include( plugin_dir_path( __FILE__ ) .'vc-elements/mayosis_team.php');
    include( plugin_dir_path( __FILE__ ) .'vc-elements/mayosis_contact.php');
    include( plugin_dir_path( __FILE__ ) .'vc-elements/mayosis_licence.php');
    include( plugin_dir_path( __FILE__ ) .'vc-elements/mayosis_slider.php');
    include( plugin_dir_path( __FILE__ ) .'vc-elements/mayosis_object_parallax.php');
    include( plugin_dir_path( __FILE__ ) .'vc-elements/mayosis-modal.php');
    include( plugin_dir_path( __FILE__ ) .'vc-elements/search_term.php');
    



if (class_exists('Easy_Digital_Downloads')):
    include( plugin_dir_path( __FILE__ ) .'vc-elements/edd_featured.php');
    include( plugin_dir_path( __FILE__ ) .'vc-elements/edd_recent.php');
    include( plugin_dir_path( __FILE__ ) .'vc-elements/edd_hero.php');
    include( plugin_dir_path( __FILE__ ) .'vc-elements/edd_recent_grid.php');
    include( plugin_dir_path( __FILE__ ) .'vc-elements/edd_login.php');
    include( plugin_dir_path( __FILE__ ) .'vc-elements/edd_register.php');
    include( plugin_dir_path( __FILE__ ) .'vc-elements/edd_justified_grid.php');
    include( plugin_dir_path( __FILE__ ) .'vc-elements/edd_masonary_grid.php');
    include( plugin_dir_path( __FILE__ ) .'vc-elements/edd_category_grid.php');
endif;

endif;
if( function_exists('edd_get_settings') ) {
	remove_filter('the_content', 'edd_append_purchase_link');
	remove_filter('edd_after_download_content', 'edd_append_purchase_link');

}
// //////////////////////////////////////////////////////////////////////////////////////////
// ////////////////////   Visual Composer  /////////////////////////////////////////
// /////////////////////////////////////////////////////////////////////////////////////////
// Before VC Init
add_action('vc_before_init', 'vc_before_init_actions');
function vc_before_init_actions()
{
    // Setup VC to be part of a theme
    if (function_exists('vc_set_as_theme')) {
        vc_set_as_theme(true);
    }
    // Link your VC elements's folder
    if (function_exists('vc_set_shortcodes_templates_dir')) {
        vc_set_shortcodes_templates_dir(get_template_directory() . '/vc_templates');
    }
    // Disable Instructional/Help Pointers
    if (function_exists('vc_pointer_load')) {
        remove_action('admin_enqueue_scripts', 'vc_pointer_load');
    }
}
// After VC Init
add_action('vc_after_init', 'vc_after_init_actions');
function vc_after_init_actions()
{
    // Enable VC by default on a list of Post Types
    if (function_exists('vc_set_default_editor_post_types')) {
        $list = array(
            'page',
            'post',
            'download'
            // add here your custom post types slug
        );
        vc_set_default_editor_post_types($list);
    }
    // Disable AdminBar VC edit link
    if (function_exists('vc_frontend_editor')) {
        remove_action('admin_bar_menu', array(
            vc_frontend_editor(),
            'adminBarEditLink'
        ), 1000);
    }
    // Disable Frontend VC links
    if (function_exists('vc_disable_frontend')) {
        vc_disable_frontend();
    }
}



add_action( 'init', 'mayosis_register_post_types' );
function mayosis_register_post_types() {
    register_post_type('testimonial', array(
        'public' => true,
        'label' => 'Testimonial',
        'menu_icon'           => 'dashicons-welcome-write-blog',
        'labels' => array(
            'name' => 'Testimonial',
            'singular_name' => 'Testimonials',
            'add_new' => 'Add New Testimonial',
        ),
        'supports' => array('title', 'thumbnail'),
        'can_export' => true,
    ));

    register_post_type('slider', array(
        'public' => true,
        'label' => 'Slider',
        'menu_icon'           => 'dashicons-images-alt',
        'labels' => array(
            'name' => 'Slider',
            'singular_name' => 'Sliders',
            'add_new' => 'Add New Slider',
        ),
        'supports' => array('title', 'thumbnail'),
        'can_export' => true,
    ));

    register_post_type('licence',
        array(
            'labels' => array(
                'name' => __( 'License' ),
                'singular_name' => __( 'License' ),
                'add_new' => __( 'Add New' ),
                'add_new_item' => __( 'Add New License' ),
                'edit' => __( 'Edit' ),
                'edit_item' => __( 'Edit License' ),
                'new_item' => __( 'New License' ),
                'view' => __( 'View License' ),
                'view_item' => __( 'View License' ),
                'search_items' => __( 'Search Licenses' ),
                'not_found' => __( 'No Licenses found' ),
                'not_found_in_trash' => __( 'No Licenses found in Trash' ),
                'parent' => __( 'Parent License' ),
            ),
            'public' => true,
            'menu_icon' => 'dashicons-tickets',
            'show_ui' => true,
            'exclude_from_search' => true,
            'hierarchical' => true,
            'supports' => array( 'title'),
            'query_var' => true
        )
    );

}
add_action( 'init', 'mayosis_license_taxonomies', 0 );

function mayosis_license_taxonomies()
{
    // Add new taxonomy, make it hierarchical (like categories)
    $labels = array(
        'name' => _x( 'License Group', 'taxonomy general name' ),
        'singular_name' => _x( 'License Groups', 'taxonomy singular name' ),
        'search_items' =>  __( 'Search Group' ),
        'popular_items' => __( 'Popular Group' ),
        'all_items' => __( 'All License Group' ),
        'parent_item' => __( 'Parent License Group' ),
        'parent_item_colon' => __( 'Parent License Group:' ),
        'edit_item' => __( 'Edit License Group' ),
        'update_item' => __( 'Update License Group' ),
        'add_new_item' => __( 'Add New License Group' ),
        'new_item_name' => __( 'New Recording License Group' ),
    );
    register_taxonomy('license-group',array('licence'), array(
        'hierarchical' => true,
        'labels' => $labels,
        'show_ui' => true,
        'query_var' => true,
        'rewrite' => array( 'slug' => 'license-group' ),
    ));
}






function short_excerpt($string)
{
    echo substr($string, 0, 210);
}
// //////////////////////////////////////////////////////////////////////////////////////////
// ////////////////////   AUTHOR CUSTOM LINK  /////////////////////////////////////////
// /////////////////////////////////////////////////////////////////////////////////////////

function digitalmarketplace_to_author_profile($contactmethods)
{
    $contactmethods['rss_url'] = 'RSS URL';
    $contactmethods['google_profile'] = 'Google Profile URL';
    $contactmethods['twitter_profile'] = 'Twitter Profile URL';
    $contactmethods['facebook_profile'] = 'Facebook Profile URL';
    $contactmethods['linkedin_profile'] = 'Linkedin Profile URL';
    return $contactmethods;
}

add_filter('user_contactmethods', 'digitalmarketplace_to_author_profile', 10, 1);
// //////////////////////////////////////////////////////////////////////////////////////////
// ////////////////////  XML SITEMAP GENARATOR  /////////////////////////////////////////
// /////////////////////////////////////////////////////////////////////////////////////////

add_action("publish_post", "digitalmarketplace_create_sitemap");
add_action("publish_page", "digitalmarketplace_create_sitemap");

function digitalmarketplace_create_sitemap()
{
    $postsForSitemap = get_posts(array(
        'numberposts' => - 1,
        'orderby' => 'modified',
        'post_type' => array(
            'post',
            'page',
            'download'
        ) ,
        'order' => 'DESC'
    ));
    $sitemap = '<?xml version="1.0" encoding="UTF-8"?>';
    $sitemap.= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
    foreach($postsForSitemap as $post)
    {
        setup_postdata($post);
        $postdate = explode(" ", $post->post_modified);
        $sitemap.= '<url>' . '<loc>' . get_permalink($post->ID) . '</loc>' . '<lastmod>' . $postdate[0] . '</lastmod>' . '<changefreq>monthly</changefreq>' . '</url>';
    }

    $sitemap.= '</urlset>';
    $fp = fopen(ABSPATH . "sitemap.xml", 'w');
    fwrite($fp, $sitemap);
    fclose($fp);
}
// //////////////////////////////////////////////////////////////////////////////////////////
// ////////////////////    Get Most Recent posts   /////////////////////////////////////////
// /////////////////////////////////////////////////////////////////////////////////////////

function mayosis_sidebar_post($numberOfPosts = 5, $thumb = true)
{
    global $post;
    $orig_post = $post;
    $lastPosts = get_posts('no_found_rows=1&suppress_filters=0&numberposts=' . $numberOfPosts);
    foreach($lastPosts as $post):
        setup_postdata($post);
        ?>
        <div class="widget-posts">

            <div class="col-md-6 col-sm-6 col-xs-6 sidebar-thumbnail">
                <div class="product-thumb grid_dm">
                    <figure class="mayosis-fade-in">
                        <?php
                        the_post_thumbnail( 'full', array( 'class' => 'img-responsive' ) );
                        ?>
                        <figcaption>
                            <div class="overlay_content_center">
                                <a href="<?php
                                the_permalink(); ?>"><i class="fas fa-plus"></i></a>
                            </div>
                        </figcaption>
                    </figure>
                </div> </div>

            <div class="col-md-6 col-sm-6 col-xs-6 sidebar-details paading-left-0">
                <h3><a href="<?php
                    the_permalink(); ?>"><?php
                        $title  = the_title('','',false);
                        if(strlen($title) > 36):
                            echo trim(substr($title, 0, 32)).'...';
                        else:
                            echo esc_html($title);
                        endif;
                        ?></a></h3>
                <p><?php
                    echo mayosis_views(get_the_ID()); ?> </p>



            </div>
        </div>
    <?php
    endforeach;
    $post = $orig_post;
}

// //////////////////////////////////////////////////////////////////////////////////////////
// ////////////////////   Get Popular posts   /////////////////////////////////////////
// /////////////////////////////////////////////////////////////////////////////////////////

function mayosis_popular_posts($pop_posts = 5, $thumb = true)
{
    global $post;
    $orig_post = $post;
    $popularposts = new WP_Query(array(
        'orderby' => 'comment_count',
        'order' => 'DESC',
        'posts_per_page' => $pop_posts,
        'post_status' => 'publish',
        'no_found_rows' => 1,
        'ignore_sticky_posts' => 1
    ));
    while ($popularposts->have_posts()):
        $popularposts->the_post() ?>
        <div class="widget-posts">

            <div class="col-md-6 col-sm-6 col-xs-6 sidebar-thumbnail">
                <div class="product-thumb grid_dm">
                    <figure class="mayosis-fade-in">
                        <?php
                        the_post_thumbnail( 'full', array( 'class' => 'img-responsive' ) );
                        ?>
                        <figcaption>
                            <div class="overlay_content_center">
                                <a href="<?php
                                the_permalink(); ?>"><i class="fas fa-plus"></i></a>
                            </div>
                        </figcaption>
                    </figure>
                </div>
            </div>

            <div class="col-md-6 col-sm-6 col-xs-6 sidebar-details paading-left-0">
                <h3><a href="<?php
                    the_permalink(); ?>"><?php
                        the_title(); ?></a></h3>
                <p><?php
                    echo mayosis_views(get_the_ID()); ?>  </p>



            </div>
        </div>
    <?php
    endwhile;
    $post = $orig_post;
}

// //////////////////////////////////////////////////////////////////////////////////////////
// ////////////////////    Get Popular posts / Views   /////////////////////////////////////////
// /////////////////////////////////////////////////////////////////////////////////////////

function mayosis_most_viewed_posts($posts_number = 5, $thumb = true)
{
    global $post;
    $original_post = $post;
    $args = array(
        'orderby' => 'meta_value_num',
        'meta_key' => 'mayosis_views',
        'posts_per_page' => $posts_number,
        'post_status' => 'publish',
        'no_found_rows' => true,
        'ignore_sticky_posts' => true
    );
    $popularposts = new WP_Query($args);
    if ($popularposts->have_posts()):
        while ($popularposts->have_posts()):
            $popularposts->the_post() ?>
            <div class="widget-posts">


                <div class="col-md-6 col-sm-6 col-xs-6 sidebar-thumbnail">
                    <div class="product-thumb grid_dm">
                        <figure class="mayosis-fade-in">
                            <?php
                            the_post_thumbnail( 'full', array( 'class' => 'img-responsive' ) );
                            ?>
                            <figcaption>
                                <div class="overlay_content_center">
                                    <a href="<?php
                                    the_permalink(); ?>"><i class="fas fa-plus"></i></a>
                                </div>
                            </figcaption>
                        </figure>
                    </div>
                </div>

                <div class="col-md-6 col-sm-6 col-xs-6 sidebar-details paading-left-0">
                    <h3><a href="<?php
                        the_permalink(); ?>"><?php
                            the_title(); ?></a></h3>
                    <p><?php
                        echo mayosis_views(get_the_ID()); ?> </p>



                </div>
            </div>
        <?php
        endwhile;
    endif;
    $post = $original_post;
    wp_reset_postdata();
}

// //////////////////////////////////////////////////////////////////////////////////////////
// ////////////////////   Get Most Viewed posts  /////////////////////////////////////////
// /////////////////////////////////////////////////////////////////////////////////////////

function mayosis_best_reviews_posts($pop_posts = 5, $thumb = true)
{
    global $post;
    $orig_post = $post;
    $cat_query1 = new WP_Query(array(
        'posts_per_page' => $pop_posts,
        'orderby' => 'meta_value_num',
        'meta_key' => 'mayosis_review_score',
        'post_status' => 'publish',
        'no_found_rows' => 1
    ));
    while ($cat_query1->have_posts()):
        $cat_query1->the_post() ?>
        <div class="widget-posts">
            <div class="col-md-6 col-sm-6 col-xs-6 sidebar-thumbnail">
                <div class="product-thumb grid_dm">
                    <figure class="mayosis-fade-in">
                        <?php
                        the_post_thumbnail( 'full', array( 'class' => 'img-responsive' ) );
                        ?>
                        <figcaption>
                            <div class="overlay_content_center">
                                <a href="<?php
                                the_permalink(); ?>"><i class="fas fa-plus"></i></a>
                            </div>
                        </figcaption>
                    </figure>
                </div>
            </div>

            <div class="col-md-6 col-sm-6 col-xs-6 sidebar-details paading-left-0">
                <h3><a href="<?php
                    the_permalink(); ?>"><?php
                        the_title(); ?></a></h3>
                <p><?php
                    echo mayosis_views(get_the_ID()); ?> </p>
            </div>
        </div>
    <?php
    endwhile;
    $post = $orig_post;
}

// //////////////////////////////////////////////////////////////////////////////////////////
// ////////////////////   Post View Count  /////////////////////////////////////////
// /////////////////////////////////////////////////////////////////////////////////////////
// function to display number of posts.

function mayosis_views($postID = '')
{
    global $post;
    if (empty($postID)) $postID = $post->ID;
    $count_key = 'mayosis_views';
    $count = get_post_meta($postID, $count_key, true);
    $count = @number_format($count);
    if (empty($count))
    {
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, 0);
        $count = 0;
    }

    return '<span class="post-views">' . $count . ' ' . __('Views', 'mayosis-digital-marketplace-theme') . '</span> ';
}

// function to count views.

function mayosis_setPostViews()
{
    global $post;
    $count = 0;
    $postID = $post->ID;
    $count_key = 'mayosis_views';
    $count = (int)get_post_meta($postID, $count_key, true);
    if (!defined('WP_CACHE') || !WP_CACHE)
    {
        $count++;
        update_post_meta($postID, $count_key, (int)$count);
    }
}

// //////////////////////////////////////////////////////////////////////////////////////////
// ////////////////////    Get Popular posts / Views  Footer ////////////////////////////////
// /////////////////////////////////////////////////////////////////////////////////////////

function mayosis_most_viewed_posts_footer($posts_number = 3, $thumb = true)
{
    global $post;
    $original_post = $post;
    $args = array(
        'orderby' => 'meta_value_num',
        'meta_key' => 'mayosis_views',
        'posts_per_page' => $posts_number,
        'post_status' => 'publish',
        'no_found_rows' => true,
        'ignore_sticky_posts' => true
    );
    $popularposts = new WP_Query($args);
    if ($popularposts->have_posts()):
        while ($popularposts->have_posts()):
            $popularposts->the_post() ?>
            <div class="bottom-widget-product ">
                <div class="col-md-6 col-sm-6 col-xs-6 sidebar-thumbnail paading-left-0">
                    <div class="product-thumb grid_dm">
                        <figure class="mayosis-fade-in">
                            <?php
                            the_post_thumbnail( 'full', array( 'class' => 'img-responsive' ) );
                            ?>
                            <figcaption>
                                <div class="overlay_content_center">
                                    <a href="<?php
                                    the_permalink(); ?>"><i class="fas fa-plus"></i></a>
                                </div>
                            </figcaption>
                        </figure>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-6 sidebar-details paading-left-0">
                    <h3><a href="<?php
                        the_permalink(); ?>">
                            <?php
                            $title  = the_title('','',false);
                            if(strlen($title) > 40):
                                echo trim(substr($title, 0, 37)).'...';
                            else:
                                echo esc_html($title);
                            endif;
                            ?>
                        </a></h3>
                    <p><?php
                        echo mayosis_views(get_the_ID()); ?> </p>


                </div>
                <div class="clearfix"></div>
            </div>
        <?php
        endwhile;
    endif;
    $post = $original_post;
    wp_reset_postdata();
}

// /////////////////////////////////////////////////////////////////////////////////////////
// ////////////////////    Get Popular Product  Footer ////////////////////////////////
// /////////////////////////////////////////////////////////////////////////////////////////

function mayosis_most_viewed_product_footer($posts_number = 3, $thumb = true)
{
    global $post;
    $original_post = $post;
    $args = array(
        'post_type' => 'download',
        'orderby' => 'meta_value_num',
        'meta_key' => 'mayosis_views',
        'posts_per_page' => $posts_number,
        'post_status' => 'publish',
        'no_found_rows' => true,
        'ignore_sticky_posts' => true
    );
    $popularposts = new WP_Query($args);
    if ($popularposts->have_posts()):
        while ($popularposts->have_posts()):
            $popularposts->the_post() ?>
            <div class="bottom-widget-product ">
                <div class="col-md-6 col-sm-6 col-xs-6 sidebar-thumbnail paading-left-0">
                    <div class="product-thumb grid_dm">
                        <figure class="mayosis-fade-in">
                            <?php
                            the_post_thumbnail( 'full', array( 'class' => 'img-responsive' ) );
                            ?>
                            <figcaption>
                                <div class="overlay_content_center">
                                    <a href="<?php
                                    the_permalink(); ?>"><i class="fas fa-plus"></i></a>
                                </div>
                            </figcaption>
                        </figure>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-6 sidebar-details paading-left-0">
                    <h3><a href="<?php
                        the_permalink(); ?>"><?php
                            the_title(); ?></a></h3>
                    <?php get_template_part( 'includes/product-additional-meta'); ?>


                </div>
                <div class="clearfix"></div>
            </div>
        <?php
        endwhile;
    endif;
    $post = $original_post;
    wp_reset_postdata();
}
//add SVG to allowed file uploads
function mayosis_file_types_to_uploads($file_types){

    $new_filetypes = array();
    $new_filetypes['svg'] = 'image/svg+xml';
    $file_types = array_merge($file_types, $new_filetypes );

    return $file_types;
}
add_action('upload_mimes', 'mayosis_file_types_to_uploads');


function mayosis_exif_data() {

    if ( ! is_singular( 'download' ) || ! has_post_thumbnail( get_the_ID() ) ) :
        return;
    endif;

    $thumb_id	= get_post_thumbnail_id();
    $image 		= wp_get_attachment_metadata( $thumb_id );
    $image_meta = $image['image_meta'];

    if ( $image_meta ) :

        ?><div id='product_exif' class='clearfix'>

        <div class='single-product-meta clearfix'>

            <?php

            if ( isset( $image_meta['aperture'] ) && ! empty( $image_meta['aperture'] ) && apply_filters( 'mayosis_display_exif_aperture', true ) ) :
                ?><div class='image-aperture'>
                <span class='label'><?php _e( 'Aperture', 'mayosis' ); ?></span>
                <span class='value'><?php echo $image_meta['aperture']; ?></span>
                </div><?php
            endif;


            if ( isset( $image_meta['camera'] ) && ! empty( $image_meta['camera'] ) && apply_filters( 'mayosis_display_exif_camera', true ) ) :
                ?><div class='image-camera'>
                <span class='label'><?php _e( 'Camera', 'mayosis' ); ?></span>
                <span class='value'><?php echo $image_meta['camera']; ?></span>
                </div><?php
            endif;


            if ( isset( $image_meta['created_timestamp'] ) && ! empty( $image_meta['created_timestamp'] ) && apply_filters( 'mayosis_display_exif_timestamp', true ) ) :
                ?><div class='image-meta-credit'>
                <span class='label'><?php _e( 'Created', 'mayosis' ); ?></span>
                <span class='value'><?php echo date( 'd-m-Y', $image_meta['created_timestamp'] ); ?></span>
                </div><?php
            endif;


            if ( isset( $image_meta['focal_length'] ) && ! empty( $image_meta['focal_length'] ) && apply_filters( 'mayosis_display_exif_focal_length', true ) ) :
                ?><div class='image-meta-focal_length'>
                <span class='label'><?php _e( 'Focal length', 'mayosis' ); ?></span>
                <span class='value'><?php echo $image_meta['focal_length']; ?></span>
                </div><?php
            endif;

            if ( isset( $image_meta['iso'] ) && ! empty( $image_meta['iso'] ) && apply_filters( 'mayosis_display_exif_iso', true ) ) :
                ?><div class='image-meta-iso'>
                <span class='label'><?php _e( 'ISO', 'mayosis' ); ?></span>
                <span class='value'><?php echo $image_meta['iso']; ?></span>
                </div><?php
            endif;

            if ( isset( $image_meta['shutter_speed'] ) && ! empty( $image_meta['shutter_speed'] ) && apply_filters( 'mayosis_display_exif_shutter_speed', true ) ) :
                ?><div class='image-meta-shutter-speed'>
                <span class='label'><?php _e( 'Shutter speed', 'mayosis' ); ?></span>
                <span class='value'><?php echo  $image_meta['shutter_speed']; ?></span>
                </div><?php
            endif;


            ?></div>

        </div><?php


    endif;

}

