<?php
// silence is golden, prevent direct access!
