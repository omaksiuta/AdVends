<?php

/**
 * Register page layout metaboxes
 */
add_action('add_meta_boxes', 'babystreet_add_layout_metabox');
add_action('save_post', 'babystreet_save_layout_postdata');

/* Adds a box to the side column on the Page edit screens */
if (!function_exists('babystreet_add_layout_metabox')) {

	function babystreet_add_layout_metabox() {

		$posttypes = array('page', 'post', 'babystreet-portfolio');
		if (BABYSTREET_PLUGIN_IS_WOOCOMMERCE) {
			$posttypes[] = 'product';
		}
		if (BABYSTREET_PLUGIN_IS_BBPRESS) {
			$posttypes[] = 'forum';
			$posttypes[] = 'topic';
		}
		if(post_type_exists('tribe_events')) {
			$posttypes[] = 'tribe_events';
		}

		foreach ($posttypes as $pt) {
			add_meta_box(
							'babystreet_layout', esc_html__('Page Layout Options', 'babystreet-plugin'), 'babystreet_layout_callback', $pt, 'side'
			);
		}
	}

}

/* Prints the box content */
if (!function_exists('babystreet_layout_callback')) {

	function babystreet_layout_callback($post) {
		// If current page is set as Blog page - don't show the options
		if ($post->ID == get_option('page_for_posts')) {
			echo esc_html__("Page Layout Options is disabled for this page, because the page is set as Blog page from Settings->Reading.", 'babystreet-plugin');
			return;
		}

		// If current page is set as Shop page - don't show the options
		if (BABYSTREET_PLUGIN_IS_WOOCOMMERCE && $post->ID == wc_get_page_id('shop')) {
			echo esc_html__("Page Layout Options is disabled for this page, because the page is set as Shop page.", 'babystreet-plugin');
			return;
		}

		// Use nonce for verification
		wp_nonce_field('babystreet_save_layout_postdata', 'layout_nonce');

		$custom = get_post_custom($post->ID);

		// Set default values
		$values = array(
				'babystreet_layout' => 'default',
				'babystreet_top_header' => 'default',
				'babystreet_footer_style' => 'default',
				'babystreet_footer_size' => 'default',
				'babystreet_header_size' => 'default',
				'babystreet_header_syle' => '',
				'babystreet_page_subtitle' => '',
				'babystreet_title_background_imgid' => '',
				'babystreet_title_alignment' => 'left_title'
		);

		if (isset($custom['babystreet_layout']) && $custom['babystreet_layout'][0] != '') {
			$values['babystreet_layout'] = esc_attr($custom['babystreet_layout'][0]);
		}
		if (isset($custom['babystreet_top_header']) && $custom['babystreet_top_header'][0] != '') {
			$values['babystreet_top_header'] = esc_attr($custom['babystreet_top_header'][0]);
		}
		if (isset($custom['babystreet_footer_style']) && $custom['babystreet_footer_style'][0] != '') {
			$values['babystreet_footer_style'] = esc_attr($custom['babystreet_footer_style'][0]);
		}
		if (isset($custom['babystreet_footer_size']) && $custom['babystreet_footer_size'][0] != '') {
			$values['babystreet_footer_size'] = esc_attr($custom['babystreet_footer_size'][0]);
		}
		if (isset($custom['babystreet_header_size']) && $custom['babystreet_header_size'][0] != '') {
			$values['babystreet_header_size'] = esc_attr($custom['babystreet_header_size'][0]);
		}
		if (isset($custom['babystreet_header_syle']) && $custom['babystreet_header_syle'][0] != '') {
			$values['babystreet_header_syle'] = esc_attr($custom['babystreet_header_syle'][0]);
		}
		if (isset($custom['babystreet_page_subtitle']) && $custom['babystreet_page_subtitle'][0] != '') {
			$values['babystreet_page_subtitle'] = esc_attr($custom['babystreet_page_subtitle'][0]);
		}
		if (isset($custom['babystreet_title_background_imgid']) && $custom['babystreet_title_background_imgid'][0] != '') {
			$values['babystreet_title_background_imgid'] = esc_attr($custom['babystreet_title_background_imgid'][0]);
		}
		if (isset($custom['babystreet_title_alignment']) && $custom['babystreet_title_alignment'][0] != '') {
			$values['babystreet_title_alignment'] = esc_attr($custom['babystreet_title_alignment'][0]);
		}

		// description
		$output = '<p>' . esc_html__("You can define layout specific options here.", 'babystreet-plugin') . '</p>';

		// Layout
		$output .= '<p><b>' . esc_html__("Choose Page Layout", 'babystreet-plugin') . '</b></p>';
		$output .= '<input id="babystreet_layout_default" ' . checked($values['babystreet_layout'], 'default', false) . ' type="radio" value="default" name="babystreet_layout">';
		$output .= '<label for="babystreet_layout_default">' . esc_html__('Default', 'babystreet-plugin') . '</label><br>';
		$output .= '<input id="babystreet_layout_fullwidth" ' . checked($values['babystreet_layout'], 'babystreet_fullwidth', false) . ' type="radio" value="babystreet_fullwidth" name="babystreet_layout">';
		$output .= '<label for="babystreet_layout_fullwidth">' . esc_html__('Full-Width', 'babystreet-plugin') . '</label><br>';
		$output .= '<input id="babystreet_layout_boxed" ' . checked($values['babystreet_layout'], 'babystreet_boxed', false) . ' type="radio" value="babystreet_boxed" name="babystreet_layout">';
		$output .= '<label for="babystreet_layout_boxed">' . esc_html__('Boxed', 'babystreet-plugin') . '</label><br>';

		// Top Menu Bar
		$output .= '<p><b>' . esc_html__("Top Menu Bar", 'babystreet-plugin') . '</b></p>';
		$output .= '<input id="babystreet_top_header_default" ' . checked($values['babystreet_top_header'], 'default', false) . ' type="radio" value="default" name="babystreet_top_header">';
		$output .= '<label for="babystreet_top_header_default">' . esc_html__('Default', 'babystreet-plugin') . '</label>&nbsp;';
		$output .= '<input id="babystreet_top_header_show" ' . checked($values['babystreet_top_header'], 'show', false) . ' type="radio" value="show" name="babystreet_top_header">';
		$output .= '<label for="babystreet_top_header_show">' . esc_html__('Show', 'babystreet-plugin') . '</label>&nbsp;';
		$output .= '<input id="babystreet_top_header_hide" ' . checked($values['babystreet_top_header'], 'hide', false) . ' type="radio" value="hide" name="babystreet_top_header">';
		$output .= '<label for="babystreet_top_header_hide">' . esc_html__('Hide', 'babystreet-plugin') . '</label>';

		// Footer Size
		$output .= '<p><b>' . esc_html__("Footer size", 'babystreet-plugin') . '</b></p>';
		$output .= '<input id="babystreet_footer_size_default" ' . checked($values['babystreet_footer_size'], 'default', false) . ' type="radio" value="default" name="babystreet_footer_size">';
		$output .= '<label for="babystreet_footer_size_default">' . esc_html__('Default', 'babystreet-plugin') . '</label>&nbsp;';
		$output .= '<input id="babystreet_footer_size_standard" ' . checked($values['babystreet_footer_size'], 'standard', false) . ' type="radio" value="standard" name="babystreet_footer_size">';
		$output .= '<label for="babystreet_footer_size_standard">' . esc_html__('Standard', 'babystreet-plugin') . '</label>&nbsp;';
		$output .= '<input id="babystreet_footer_size_hide" ' . checked($values['babystreet_footer_size'], 'babystreet-stretched-footer', false) . ' type="radio" value="babystreet-stretched-footer" name="babystreet_footer_size">';
		$output .= '<label for="babystreet_footer_size_hide">' . esc_html__('Fullwidth', 'babystreet-plugin') . '</label>';

		// Footer Style
		$output .= '<p><b>' . esc_html__("Footer style", 'babystreet-plugin') . '</b></p>';
		$output .= '<input id="babystreet_footer_style_default" ' . checked($values['babystreet_footer_style'], 'default', false) . ' type="radio" value="default" name="babystreet_footer_style">';
		$output .= '<label for="babystreet_footer_style_default">' . esc_html__('Default', 'babystreet-plugin') . '</label>&nbsp;';
		$output .= '<input id="babystreet_footer_style_show" ' . checked($values['babystreet_footer_style'], 'standart', false) . ' type="radio" value="standart" name="babystreet_footer_style">';
		$output .= '<label for="babystreet_footer_style_show">' . esc_html__('Standard', 'babystreet-plugin') . '</label>&nbsp;';
		$output .= '<input id="babystreet_footer_style_hide" ' . checked($values['babystreet_footer_style'], 'babystreet-reveal-footer', false) . ' type="radio" value="babystreet-reveal-footer" name="babystreet_footer_style">';
		$output .= '<label for="babystreet_footer_style_hide">' . esc_html__('Reveal', 'babystreet-plugin') . '</label>';

		// Header Size
		$output .= '<p><b>' . esc_html__("Header size", 'babystreet-plugin') . '</b></p>';
		$output .= '<input id="babystreet_header_size_default" ' . checked($values['babystreet_header_size'], 'default', false) . ' type="radio" value="default" name="babystreet_header_size">';
		$output .= '<label for="babystreet_header_size_default">' . esc_html__('Default', 'babystreet-plugin') . '</label>&nbsp;';
		$output .= '<input id="babystreet_header_size_standard" ' . checked($values['babystreet_header_size'], 'standard', false) . ' type="radio" value="standard" name="babystreet_header_size">';
		$output .= '<label for="babystreet_header_size_standard">' . esc_html__('Standard', 'babystreet-plugin') . '</label>&nbsp;';
		$output .= '<input id="babystreet_header_size_hide" ' . checked($values['babystreet_header_size'], 'babystreet-stretched-header', false) . ' type="radio" value="babystreet-stretched-header" name="babystreet_header_size">';
		$output .= '<label for="babystreet_header_size_hide">' . esc_html__('Fullwidth', 'babystreet-plugin') . '</label>';

		// Transparent header and Title with Image Background (only on posts, pages, forum, portfolio and topic)
		$screen = get_current_screen();
		if ($screen && in_array($screen->post_type, array('post', 'page', 'forum', 'topic', 'babystreet-portfolio', 'tribe_events', 'product'), true)) {

			// Below is not for product
			if($screen->post_type != 'product') {
				// Header style header
				$output .= '<p><b>' . esc_html__("Header Style", 'babystreet-plugin') . '</b></p>';
				$output .= '<p><label for="babystreet_header_syle">';

				$output .= "<select name='babystreet_header_syle'>";
				// Add a default option
				$output .= "<option";
				if ($values['babystreet_header_syle'] === '') {
					$output .= " selected='selected'";
				}
				$output .= " value=''>" . esc_html__('Normal', 'babystreet-plugin') . "</option>";

				// Fill the select element
				$header_style_values = array(
					'babystreet_transparent_header' => esc_html__('Transparent - Light Scheme', 'babystreet-plugin'),
					'babystreet_transparent_header babystreet-transparent-dark' => esc_html__('Transparent - Dark Scheme', 'babystreet-plugin')
				);

				foreach ($header_style_values as $header_style_val => $header_style_option) {
					$output .= "<option";
					if ($header_style_val === $values['babystreet_header_syle']) {
						$output .= " selected='selected'";
					}
					$output .= " value='" . esc_attr($header_style_val) . "'>" . esc_html($header_style_option) . "</option>";
				}

				$output .= "</select>";

				// The image
				$image_id = get_post_meta(
					$post->ID, 'babystreet_title_background_imgid', true
				);

				$add_link_style = '';
				$del_link_style = '';

				$output .= '<p class="hide-if-no-js">';
				$output .= '<span id="babystreet_title_background_imgid_images" class="babystreet_featured_img_holder">';

				if ( $image_id ) {
					$add_link_style = 'style="display:none"';
					$output .= wp_get_attachment_image( $image_id, 'medium' );
				} else {
					$del_link_style = 'style="display:none"';
				}

				$output .= '</span>';
				$output .= '</p>';
				$output .= '<p class="hide-if-no-js">';
				$output .= '<input id="babystreet_title_background_imgid" name="babystreet_title_background_imgid" type="hidden" value="' . esc_attr( $image_id ) . '" />';
				$output .= '<input type="button" value="' . esc_attr__( 'Manage Images', 'babystreet-plugin' ) . '" id="upload_babystreet_title_background_imgid" class="babystreet_upload_image_button" data-uploader_title="' . esc_attr__( 'Select Title Background Image', 'babystreet-plugin' ) . '" data-uploader_button_text="' . esc_attr__( 'Select', 'babystreet-plugin' ) . '">';
				$output .= '</p>';

				$output .= '<p><label for="babystreet_page_subtitle">' . esc_html__( "Page Subtitle", 'babystreet-plugin' ) . '</label></p>';
				$output .= '<input type="text" id="babystreet_page_subtitle" name="babystreet_page_subtitle" value="' . esc_attr( $values['babystreet_page_subtitle'] ) . '" class="large-text" />';
				$output .= '<p><label for="babystreet_title_alignment">' . esc_html__( "Title alignment", 'babystreet-plugin' ) . '</label></p>';
				$output .= '<select name="babystreet_title_alignment">';
				$output .= '<option ' . ( $values['babystreet_title_alignment'] == 'left_title' ? 'selected="selected"' : '' ) . ' value="left_title">Left</option>';
				$output .= '<option ' . ( $values['babystreet_title_alignment'] == 'centered_title' ? 'selected="selected"' : '' ) . ' value="centered_title">Center</option>';
				$output .= '</select>';
			}
		}

		echo $output; // All dynamic data escaped
	}

}

/* When the post is saved, saves our custom data */
if (!function_exists('babystreet_save_layout_postdata')) {

	function babystreet_save_layout_postdata($post_id) {
		global $pagenow;

		// verify if this is an auto save routine.
		// If it is our form has not been submitted, so we dont want to do anything
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
			return;
		}

		// verify this came from our screen and with proper authorization,
		// because save_post can be triggered at other times
		if (isset($_POST['layout_nonce']) && !wp_verify_nonce($_POST['layout_nonce'], 'babystreet_save_layout_postdata')) {
			return;
		}

		if (!current_user_can('edit_pages', $post_id)) {
			return;
		}

		if ('post-new.php' == $pagenow) {
			return;
		}

		if (isset($_POST['babystreet_layout'])) {
			update_post_meta($post_id, "babystreet_layout", sanitize_text_field($_POST['babystreet_layout']));
		}

		if (isset($_POST['babystreet_top_header'])) {
			update_post_meta($post_id, "babystreet_top_header", sanitize_text_field($_POST['babystreet_top_header']));
		}

		if (isset($_POST['babystreet_footer_style'])) {
			update_post_meta($post_id, "babystreet_footer_style", sanitize_text_field($_POST['babystreet_footer_style']));
		}

		if (isset($_POST['babystreet_footer_size'])) {
			update_post_meta($post_id, "babystreet_footer_size", sanitize_text_field($_POST['babystreet_footer_size']));
		}

		if (isset($_POST['babystreet_header_size'])) {
			update_post_meta($post_id, "babystreet_header_size", sanitize_text_field($_POST['babystreet_header_size']));
		}

		if (isset($_POST['babystreet_page_subtitle'])) {
			update_post_meta($post_id, "babystreet_page_subtitle", sanitize_text_field($_POST['babystreet_page_subtitle']));
		}

		if (isset($_POST['babystreet_header_syle'])) {
			update_post_meta($post_id, "babystreet_header_syle", sanitize_text_field($_POST['babystreet_header_syle']));
		}

		if (isset($_POST['babystreet_title_background_imgid'])) {
			update_post_meta($post_id, 'babystreet_title_background_imgid', sanitize_text_field($_POST['babystreet_title_background_imgid']));
		}

		if (isset($_POST['babystreet_title_alignment'])) {
			update_post_meta($post_id, 'babystreet_title_alignment', sanitize_text_field($_POST['babystreet_title_alignment']));
		}
	}

}

/**
 * Register metaboxes
 */
add_action('add_meta_boxes', 'babystreet_add_page_options_metabox');
add_action('save_post', 'babystreet_save_page_options_postdata');

/* Adds a box to the side column on the Page edit screens */
if (!function_exists('babystreet_add_page_options_metabox')) {

	function babystreet_add_page_options_metabox() {

		$posttypes = array('page', 'post', 'babystreet-portfolio', 'tribe_events');

		if (BABYSTREET_PLUGIN_IS_BBPRESS) {
			$posttypes[] = 'forum';
			$posttypes[] = 'topic';
		}
		if(post_type_exists('tribe_events')) {
			$posttypes[] = 'tribe_events';
		}

		foreach ($posttypes as $pt) {
			add_meta_box(
							'babystreet_page_options', esc_html__('Page Structure Options', 'babystreet-plugin'), 'babystreet_page_options_callback', $pt, 'side'
			);
		}
	}

}

/* Prints the box content */
if (!function_exists('babystreet_page_options_callback')) {

	function babystreet_page_options_callback($post) {
		// If current page is set as Blog page - don't show the options
		if ($post->ID == get_option('page_for_posts')) {
			echo esc_html__("Page Structure Options are disabled for this page, because the page is set as Blog page from Settings->Reading.", 'babystreet-plugin');
			return;
		}
		// If current page is set as Shop page - don't show the options
		if (BABYSTREET_PLUGIN_IS_WOOCOMMERCE && $post->ID == wc_get_page_id('shop')) {
			echo esc_html__("Page Structure Options are disabled for this page, because the page is set as Shop page.", 'babystreet-plugin');
			return;
		}

		// Use nonce for verification
		wp_nonce_field('babystreet_save_page_options_postdata', 'page_options_nonce');
		global $wp_registered_sidebars;

		$custom = get_post_custom($post->ID);

		// Set default values
		$values = array(
				'babystreet_top_menu' => 'default',
				'babystreet_show_title_page' => 'yes',
				'babystreet_show_breadcrumb' => 'yes',
				'babystreet_show_feat_image_in_post' => 'yes',
				'babystreet_show_sidebar' => 'yes',
				'babystreet_sidebar_position' => 'default',
				'babystreet_show_footer_sidebar' => 'yes',
				'babystreet_show_offcanvas_sidebar' => 'yes',
				'babystreet_show_share' => 'default',
				'babystreet_custom_sidebar' => 'default',
				'babystreet_custom_footer_sidebar' => 'default',
				'babystreet_custom_offcanvas_sidebar' => 'default'
		);

		if (isset($custom['babystreet_top_menu']) && $custom['babystreet_top_menu'][0] != '') {
			$values['babystreet_top_menu'] = $custom['babystreet_top_menu'][0];
		}
		if (isset($custom['babystreet_show_title_page']) && $custom['babystreet_show_title_page'][0] != '') {
			$values['babystreet_show_title_page'] = $custom['babystreet_show_title_page'][0];
		}
		if (isset($custom['babystreet_show_breadcrumb']) && $custom['babystreet_show_breadcrumb'][0] != '') {
			$values['babystreet_show_breadcrumb'] = $custom['babystreet_show_breadcrumb'][0];
		}
		if (isset($custom['babystreet_show_feat_image_in_post']) && $custom['babystreet_show_feat_image_in_post'][0] != '') {
			$values['babystreet_show_feat_image_in_post'] = $custom['babystreet_show_feat_image_in_post'][0];
		}
		if (isset($custom['babystreet_show_sidebar']) && $custom['babystreet_show_sidebar'][0] != '') {
			$values['babystreet_show_sidebar'] = $custom['babystreet_show_sidebar'][0];
		}
		if (isset($custom['babystreet_sidebar_position']) && $custom['babystreet_sidebar_position'][0] != '') {
			$values['babystreet_sidebar_position'] = $custom['babystreet_sidebar_position'][0];
		}
		if (isset($custom['babystreet_show_footer_sidebar']) && $custom['babystreet_show_footer_sidebar'][0] != '') {
			$values['babystreet_show_footer_sidebar'] = $custom['babystreet_show_footer_sidebar'][0];
		}
		if (isset($custom['babystreet_show_offcanvas_sidebar']) && $custom['babystreet_show_offcanvas_sidebar'][0] != '') {
			$values['babystreet_show_offcanvas_sidebar'] = $custom['babystreet_show_offcanvas_sidebar'][0];
		}
		if (isset($custom['babystreet_show_share']) && $custom['babystreet_show_share'][0] != '') {
			$values['babystreet_show_share'] = $custom['babystreet_show_share'][0];
		}
		if (isset($custom['babystreet_custom_sidebar']) && $custom['babystreet_custom_sidebar'][0] != '') {
			$values['babystreet_custom_sidebar'] = $custom['babystreet_custom_sidebar'][0];
		}
		if (isset($custom['babystreet_custom_footer_sidebar']) && $custom['babystreet_custom_footer_sidebar'][0] != '') {
			$values['babystreet_custom_footer_sidebar'] = $custom['babystreet_custom_footer_sidebar'][0];
		}
		if (isset($custom['babystreet_custom_offcanvas_sidebar']) && $custom['babystreet_custom_offcanvas_sidebar'][0] != '') {
			$values['babystreet_custom_offcanvas_sidebar'] = $custom['babystreet_custom_offcanvas_sidebar'][0];
		}

		// description
		$output = '<p>' . esc_html__("You can configure the page structure, using this options.", 'babystreet-plugin') . '</p>';

		// Top Menu
		$choose_menu_options = babystreet_get_choose_menu_options();
		$output .= '<p><label for="babystreet_top_menu"><b>' . esc_html__("Choose Top Menu", 'babystreet-plugin') . '</b></label></p>';
		$output .= "<select name='babystreet_top_menu'>";
		// Add a default option
		foreach ($choose_menu_options as $key => $val) {
			$output .= "<option value='" . esc_attr($key) . "' " . esc_attr(selected($values['babystreet_top_menu'], $key, false)) . " >" . esc_html($val) . "</option>";
		}
		$output .= "</select>";

		// Show title
		$output .= '<p><label for="babystreet_show_title_page"><b>' . esc_html__("Show Title", 'babystreet-plugin') . '</b></label></p>';
		$output .= '<input id="babystreet_show_title_page_yes" ' . checked($values['babystreet_show_title_page'], 'yes', false) . ' type="radio" value="yes" name="babystreet_show_title_page">';
		$output .= '<label for="babystreet_show_title_page_yes">Yes </label>&nbsp;';
		$output .= '<input id="babystreet_show_title_page_no" ' . checked($values['babystreet_show_title_page'], 'no', false) . ' type="radio" value="no" name="babystreet_show_title_page">';
		$output .= '<label for="babystreet_show_title_page_no">No</label>';

		// Show breadcrumb
		$output .= '<p><label for="babystreet_show_breadcrumb"><b>' . esc_html__("Show Breadcrumb", 'babystreet-plugin') . '</b></label></p>';
		$output .= "<input id='babystreet_show_breadcrumb_yes' " . checked($values['babystreet_show_breadcrumb'], 'yes', false) . " type='radio' value='yes' name='babystreet_show_breadcrumb'>";
		$output .= '<label for="babystreet_show_breadcrumb_yes">Yes </label>&nbsp;';
		$output .= '<input id="babystreet_show_breadcrumb_no" ' . checked($values['babystreet_show_breadcrumb'], 'no', false) . ' type="radio" value="no" name="babystreet_show_breadcrumb">';
		$output .= '<label for="babystreet_show_breadcrumb_no">No</label>';

		// Show featured image inside post in single post view
		$screen = get_current_screen();
		if ($screen && in_array($screen->post_type, array('post'), true)) {
			$output .= '<p><label for="babystreet_show_feat_image_in_post"><b>' . esc_html__( "Featured Image in Single Post View", 'babystreet-plugin' ) . '</b></label></p>';
			$output .= '<input id="babystreet_show_feat_image_in_post_yes" ' . checked( $values['babystreet_show_feat_image_in_post'], 'yes', false ) . ' type="radio" value="yes" name="babystreet_show_feat_image_in_post">';
			$output .= '<label for="babystreet_show_feat_image_in_post_yes">Yes </label>&nbsp;';
			$output .= '<input id="babystreet_show_feat_image_in_post_no" ' . checked( $values['babystreet_show_feat_image_in_post'], 'no', false ) . ' type="radio" value="no" name="babystreet_show_feat_image_in_post">';
			$output .= '<label for="babystreet_show_feat_image_in_post_no">No</label>';
		}

		// Show share
		$output .= '<p><label for="babystreet_show_share"><b>' . esc_html__("Show Social Share Links", 'babystreet-plugin') . '</b></label></p>';
		$output .= '<input id="babystreet_show_share_default" ' . checked($values['babystreet_show_share'], 'default', false) . ' type="radio" value="default" name="babystreet_show_share">';
		$output .= '<label for="babystreet_show_share_default">' . esc_html__('Default', 'babystreet-plugin') . '</label>&nbsp;';
		$output .= '<input id="babystreet_show_share_yes" ' . checked($values['babystreet_show_share'], 'yes', false) . ' type="radio" value="yes" name="babystreet_show_share">';
		$output .= '<label for="babystreet_show_share_yes">Yes </label>&nbsp;';
		$output .= '<input id="babystreet_show_share_no" ' . checked($values['babystreet_show_share'], 'no', false) . ' type="radio" value="no" name="babystreet_show_share">';
		$output .= '<label for="babystreet_show_share_no">No</label>';

		// Show Main sidebar
		$output .= '<p><label for="babystreet_show_sidebar"><b>' . esc_html__("Main Sidebar", 'babystreet-plugin') . '</b></label></p>';
		$output .= '<input id="babystreet_show_sidebar_yes" ' . checked($values['babystreet_show_sidebar'], 'yes', false) . ' type="radio" value="yes" name="babystreet_show_sidebar">';
		$output .= '<label for="babystreet_show_sidebar_yes">Show </label>&nbsp;';
		$output .= '<input id="babystreet_show_sidebar_no" ' . checked($values['babystreet_show_sidebar'], 'no', false) . ' type="radio" value="no" name="babystreet_show_sidebar">';
		$output .= '<label for="babystreet_show_sidebar_no">Hide </label>';

		// Select Main sidebar
		$output .= "<select name='babystreet_custom_sidebar'>";
		// Add a default option
		$output .= "<option";
		if ($values['babystreet_custom_sidebar'] == "default") {
			$output .= " selected='selected'";
		}
		$output .= " value='default'>" . esc_html__('default', 'babystreet-plugin') . "</option>";

		// Fill the select element with all registered sidebars
		foreach ($wp_registered_sidebars as $sidebar_id => $sidebar) {
			if ($sidebar_id != 'bottom_footer_sidebar' && $sidebar_id != 'pre_header_sidebar') {
				$output .= "<option";
				if ($sidebar_id == $values['babystreet_custom_sidebar']) {
					$output .= " selected='selected'";
				}
				$output .= " value='" . esc_attr($sidebar_id) . "'>" . esc_html($sidebar['name']) . "</option>";
			}
		}

		$output .= "</select>";

		// Main Sidebar Position
		$output .= '<p><label for="babystreet_sidebar_position"><b>' . esc_html__("Main Sidebar Position", 'babystreet-plugin') . '</b></label></p>';
		$output .= '<select name="babystreet_sidebar_position">';
		$output .= '<option value="default" '.esc_attr(selected($values['babystreet_sidebar_position'], 'default', false)).' >' . esc_html__("default", 'babystreet-plugin') . '</option>';
		$output .= '<option value="babystreet-left-sidebar" '.esc_attr(selected($values['babystreet_sidebar_position'], 'babystreet-left-sidebar', false)).'>' . esc_html__("Left", 'babystreet-plugin') . '</option>';
		$output .= '<option value="babystreet-right-sidebar" '.esc_attr(selected($values['babystreet_sidebar_position'], 'babystreet-right-sidebar', false)).'>' . esc_html__("Right", 'babystreet-plugin') . '</option>';
		$output .= '</select>';

		// Show offcanvas sidebar
		$output .= '<p><label for="babystreet_show_offcanvas_sidebar"><b>' . esc_html__("Off Canvas Sidebar", 'babystreet-plugin') . '</b></label></p>';
		$output .= '<input id="babystreet_show_offcanvas_sidebar_yes" ' . checked($values['babystreet_show_offcanvas_sidebar'], 'yes', false) . ' type="radio" value="yes" name="babystreet_show_offcanvas_sidebar">';
		$output .= '<label for="babystreet_show_offcanvas_sidebar_yes">Show </label>&nbsp;';
		$output .= '<input id="babystreet_show_offcanvas_sidebar_no" ' . checked($values['babystreet_show_offcanvas_sidebar'], 'no', false) . ' type="radio" value="no" name="babystreet_show_offcanvas_sidebar">';
		$output .= '<label for="babystreet_show_offcanvas_sidebar_no">Hide </label>';

		// Select offcanvas sidebar
		$output .= "<select name='babystreet_custom_offcanvas_sidebar'>";

		// Add a default option
		$output .= "<option";
		if ($values['babystreet_custom_offcanvas_sidebar'] == "default") {
			$output .= " selected='selected'";
		}
		$output .= " value='default'>" . esc_html__('default', 'babystreet-plugin') . "</option>";

		// Fill the select element with all registered sidebars
		foreach ($wp_registered_sidebars as $sidebar_id => $sidebar) {
			if ($sidebar_id != 'pre_header_sidebar') {
				$output .= "<option";
				if ($sidebar_id == $values['babystreet_custom_offcanvas_sidebar']) {
					$output .= " selected='selected'";
				}
				$output .= " value='" . esc_attr($sidebar_id) . "'>" . esc_html($sidebar['name']) . "</option>";
			}
		}

		$output .= "</select>";

		// Show footer sidebar
		$output .= '<p><label for="babystreet_show_footer_sidebar"><b>' . esc_html__("Footer Sidebar", 'babystreet-plugin') . '</b></label></p>';
		$output .= '<input id="babystreet_show_footer_sidebar_yes" ' . checked($values['babystreet_show_footer_sidebar'], 'yes', false) . ' type="radio" value="yes" name="babystreet_show_footer_sidebar">';
		$output .= '<label for="babystreet_show_footer_sidebar_yes">Show </label>&nbsp;';
		$output .= '<input id="babystreet_show_footer_sidebar_no" ' . checked($values['babystreet_show_footer_sidebar'], 'no', false) . ' type="radio" value="no" name="babystreet_show_footer_sidebar">';
		$output .= '<label for="babystreet_show_footer_sidebar_no">Hide </label>';

		// Select footer sidebar
		$output .= "<select name='babystreet_custom_footer_sidebar'>";

		// Add a default option
		$output .= "<option";
		if ($values['babystreet_custom_footer_sidebar'] == "default") {
			$output .= " selected='selected'";
		}
		$output .= " value='default'>" . esc_html__('default', 'babystreet-plugin') . "</option>";

		// Fill the select element with all registered sidebars
		foreach ($wp_registered_sidebars as $sidebar_id => $sidebar) {
			if ($sidebar_id != 'pre_header_sidebar') {
				$output .= "<option";
				if ($sidebar_id == $values['babystreet_custom_footer_sidebar']) {
					$output .= " selected='selected'";
				}
				$output .= " value='" . esc_attr($sidebar_id) . "'>" . esc_html($sidebar['name']) . "</option>";
			}
		}

		$output .= "</select>";

		echo $output; // All dynamic data escaped
	}

}

/* When the post is saved, saves our custom data */
if (!function_exists('babystreet_save_page_options_postdata')) {

	function babystreet_save_page_options_postdata($post_id) {
		// verify if this is an auto save routine.
		// If it is our form has not been submitted, so we dont want to do anything
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
			return;
		}

		// verify this came from our screen and with proper authorization,
		// because save_post can be triggered at other times
		if (isset($_POST['page_options_nonce']) && !wp_verify_nonce($_POST['page_options_nonce'], 'babystreet_save_page_options_postdata')) {
			return;
		}

		if (!current_user_can('edit_pages', $post_id)) {
			return;
		}

		if (isset($_POST['babystreet_top_menu'])) {
			update_post_meta($post_id, "babystreet_top_menu", sanitize_text_field($_POST['babystreet_top_menu']));
		}
		if (isset($_POST['babystreet_show_title_page'])) {
			update_post_meta($post_id, "babystreet_show_title_page", sanitize_text_field($_POST['babystreet_show_title_page']));
		}
		if (isset($_POST['babystreet_show_breadcrumb'])) {
			update_post_meta($post_id, "babystreet_show_breadcrumb", sanitize_text_field($_POST['babystreet_show_breadcrumb']));
		}
		if (isset($_POST['babystreet_show_feat_image_in_post'])) {
			update_post_meta($post_id, "babystreet_show_feat_image_in_post", sanitize_text_field($_POST['babystreet_show_feat_image_in_post']));
		}
		if (isset($_POST['babystreet_show_sidebar'])) {
			update_post_meta($post_id, "babystreet_show_sidebar", sanitize_text_field($_POST['babystreet_show_sidebar']));
		}
		if (isset($_POST['babystreet_sidebar_position'])) {
			update_post_meta($post_id, "babystreet_sidebar_position", sanitize_text_field($_POST['babystreet_sidebar_position']));
		}
		if (isset($_POST['babystreet_show_footer_sidebar'])) {
			update_post_meta($post_id, "babystreet_show_footer_sidebar", sanitize_text_field($_POST['babystreet_show_footer_sidebar']));
		}
		if (isset($_POST['babystreet_show_offcanvas_sidebar'])) {
			update_post_meta($post_id, "babystreet_show_offcanvas_sidebar", sanitize_text_field($_POST['babystreet_show_offcanvas_sidebar']));
		}
		if (isset($_POST['babystreet_show_share'])) {
			update_post_meta($post_id, "babystreet_show_share", sanitize_text_field($_POST['babystreet_show_share']));
		}
		if (isset($_POST['babystreet_custom_sidebar'])) {
			update_post_meta($post_id, "babystreet_custom_sidebar", sanitize_text_field($_POST['babystreet_custom_sidebar']));
		}
		if (isset($_POST['babystreet_custom_footer_sidebar'])) {
			update_post_meta($post_id, "babystreet_custom_footer_sidebar", sanitize_text_field($_POST['babystreet_custom_footer_sidebar']));
		}
		if (isset($_POST['babystreet_custom_offcanvas_sidebar'])) {
			update_post_meta($post_id, "babystreet_custom_offcanvas_sidebar", sanitize_text_field($_POST['babystreet_custom_offcanvas_sidebar']));
		}
	}

}

// If Revolution slider is active add the meta box
if (BABYSTREET_PLUGIN_IS_REVOLUTION) {
	add_action('add_meta_boxes', 'babystreet_add_revolution_slider_metabox');
	add_action('save_post', 'babystreet_save_revolution_slider_postdata');
}

/* Adds a box to the side column on the Post, Page and Portfolio edit screens */
if (!function_exists('babystreet_add_revolution_slider_metabox')) {

	function babystreet_add_revolution_slider_metabox() {
		add_meta_box(
						'babystreet_revolution_slider', esc_html__('Revolution Slider', 'babystreet-plugin'), 'babystreet_revolution_slider_callback', 'page', 'side'
		);

		add_meta_box(
						'babystreet_revolution_slider', esc_html__('Revolution Slider', 'babystreet-plugin'), 'babystreet_revolution_slider_callback', 'post', 'side'
		);

		add_meta_box(
						'babystreet_revolution_slider', esc_html__('Revolution Slider', 'babystreet-plugin'), 'babystreet_revolution_slider_callback', 'babystreet-portfolio', 'side'
		);

		add_meta_box(
						'babystreet_revolution_slider', esc_html__('Revolution Slider', 'babystreet-plugin'), 'babystreet_revolution_slider_callback', 'tribe_events', 'side'
		);
	}

}

/* Prints the box content */
if (!function_exists('babystreet_revolution_slider_callback')) {

	function babystreet_revolution_slider_callback($post) {

		// If current page is set as Blog page - don't show the options
		if ($post->ID == get_option('page_for_posts')) {
			echo esc_html__("Revolution slider is disabled for this page, because the page is set as Blog page from Settings->Reading.", 'babystreet-plugin');
			return;
		}

		// If current page is set as Shop page - don't show the options
		if (BABYSTREET_PLUGIN_IS_WOOCOMMERCE && $post->ID == wc_get_page_id('shop')) {
			echo esc_html__("Revolution slider is disabled for this page, because the page is set as Shop page.", 'babystreet-plugin');
			return;
		}

		// Use nonce for verification
		wp_nonce_field('babystreet_save_revolution_slider_postdata', 'babystreet_revolution_slider');

		$custom = get_post_custom($post->ID);

		if (isset($custom['babystreet_rev_slider'])) {
			$val = $custom['babystreet_rev_slider'][0];
		} else {
			$val = "none";
		}

		if (isset($custom['babystreet_rev_slider_before_header']) && $custom['babystreet_rev_slider_before_header'][0] != '') {
			$val_before_header = esc_attr($custom['babystreet_rev_slider_before_header'][0]);
		} else {
			$val_before_header = 0;
		}

		// description
		$output = '<p>' . esc_html__("You can choose a Revolution slider to be attached. It will show up on the top of this page/post.", 'babystreet-plugin') . '</p>';

		// select
		$output .= '<p><label for="babystreet_rev_slider"><b>' . esc_html__("Select slider", 'babystreet-plugin') . '</b></label></p>';
		$output .= "<select name='babystreet_rev_slider'>";

		// Add a default option
		$output .= "<option";
		if ($val == "none") {
			$output .= " selected='selected'";
		}
		$output .= " value='none'>" . esc_html__('none', 'babystreet-plugin') . "</option>";

		// Get defined revolution slides
		$slider = new RevSlider();
		$arrSliders = $slider->getArrSlidersShort();

		// Fill the select element with all registered slides
		foreach ($arrSliders as $id => $title) {
			$output .= "<option";
			if ($id == $val)
				$output .= " selected='selected'";
			$output .= " value='" . esc_attr($id) . "'>" . esc_html($title) . "</option>";
		}

		$output .= "</select>";
		$screen = get_current_screen();
		// only for pages
		if ($screen && in_array($screen->post_type, array('page'), true)) {
			// place before header
			$output .= '<p><label for="babystreet_rev_slider_before_header">';
			$output .= "<input type='checkbox' id='babystreet_rev_slider_before_header' name='babystreet_rev_slider_before_header' value='1' " . checked(esc_attr($val_before_header), 1, false) . "><b>" . esc_html__("Place before header", 'babystreet-plugin') . "</b></label></p>";
		}
		echo $output; // All dynamic data escaped
	}

}

/* When the post is saved, saves our custom data */
if (!function_exists('babystreet_save_revolution_slider_postdata')) {

	function babystreet_save_revolution_slider_postdata($post_id) {
		// verify if this is an auto save routine.
		// If it is our form has not been submitted, so we dont want to do anything
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
			return;
		}

		// verify this came from our screen and with proper authorization,
		// because save_post can be triggered at other times
		if (isset($_POST['babystreet_revolution_slider']) && !wp_verify_nonce($_POST['babystreet_revolution_slider'], 'babystreet_save_revolution_slider_postdata')) {
			return;
		}

		if (!current_user_can('edit_pages', $post_id)) {
			return;
		}

		if (isset($_POST['babystreet_rev_slider'])) {
			update_post_meta($post_id, "babystreet_rev_slider", sanitize_text_field($_POST['babystreet_rev_slider']));
		}

		if (isset($_POST['babystreet_rev_slider_before_header']) && $_POST['babystreet_rev_slider_before_header']) {
			update_post_meta($post_id, "babystreet_rev_slider_before_header", 1);
		} else {
			update_post_meta($post_id, "babystreet_rev_slider_before_header", 0);
		}
	}

}

/**
 * Register video background metaboxes
 */
add_action('add_meta_boxes', 'babystreet_add_video_bckgr_metabox');
add_action('save_post', 'babystreet_save_video_bckgr_postdata');

/* Adds a box to the side column on the Page edit screens */
if (!function_exists('babystreet_add_video_bckgr_metabox')) {

	function babystreet_add_video_bckgr_metabox() {

		$posttypes = array('page', 'post', 'babystreet-portfolio', 'tribe_events');
		if (BABYSTREET_PLUGIN_IS_WOOCOMMERCE) {
			$posttypes[] = 'product';
		}
		if (BABYSTREET_PLUGIN_IS_BBPRESS) {
			$posttypes[] = 'forum';
			$posttypes[] = 'topic';
		}

		foreach ($posttypes as $pt) {
			add_meta_box(
							'babystreet_video_bckgr', esc_html__('Video Background', 'babystreet-plugin'), 'babystreet_video_bckgr_callback', $pt, 'side'
			);
		}
	}

}

/* Prints the box content */
if (!function_exists('babystreet_video_bckgr_callback')) {

	function babystreet_video_bckgr_callback($post) {
		// If current page is set as Blog page - don't show the options
		if ($post->ID == get_option('page_for_posts')) {
			echo esc_html__("Video Background options are disabled for this page, because the page is set as Blog page from Settings->Reading.", 'babystreet-plugin');
			return;
		}

		// If current page is set as Shop page - don't show the options
		if (BABYSTREET_PLUGIN_IS_WOOCOMMERCE && $post->ID == wc_get_page_id('shop')) {
			echo esc_html__("Video Background options are disabled for this page, because the page is set as Shop page.", 'babystreet-plugin');
			return;
		}


		// Use nonce for verification
		wp_nonce_field('babystreet_save_video_bckgr_postdata', 'video_bckgr_nonce');

		$custom = get_post_custom($post->ID);

		// Set default values
		$values = array(
				'babystreet_video_bckgr_url' => '',
				'babystreet_video_bckgr_start' => '',
				'babystreet_video_bckgr_end' => '',
				'babystreet_video_bckgr_loop' => 1,
				'babystreet_video_bckgr_mute' => 1
		);

		if (isset($custom['babystreet_video_bckgr_url']) && $custom['babystreet_video_bckgr_url'][0] != '') {
			$values['babystreet_video_bckgr_url'] = esc_attr($custom['babystreet_video_bckgr_url'][0]);
		}
		if (isset($custom['babystreet_video_bckgr_start']) && $custom['babystreet_video_bckgr_start'][0] != '') {
			$values['babystreet_video_bckgr_start'] = esc_attr($custom['babystreet_video_bckgr_start'][0]);
		}
		if (isset($custom['babystreet_video_bckgr_end']) && $custom['babystreet_video_bckgr_end'][0] != '') {
			$values['babystreet_video_bckgr_end'] = esc_attr($custom['babystreet_video_bckgr_end'][0]);
		}
		if (isset($custom['babystreet_video_bckgr_loop']) && $custom['babystreet_video_bckgr_loop'][0] != '') {
			$values['babystreet_video_bckgr_loop'] = esc_attr($custom['babystreet_video_bckgr_loop'][0]);
		}
		if (isset($custom['babystreet_video_bckgr_mute']) && $custom['babystreet_video_bckgr_mute'][0] != '') {
			$values['babystreet_video_bckgr_mute'] = esc_attr($custom['babystreet_video_bckgr_mute'][0]);
		}

		// description
		$output = '<p>' . esc_html__("Define the video background options for this page/post.", 'babystreet-plugin') . '</p>';

		// Video URL
		$output .= '<p><label for="babystreet_video_bckgr_url"><b>' . esc_html__("YouTube video URL", 'babystreet-plugin') . '</b></label></p>';
		$output .= '<input type="text" id="babystreet_video_bckgr_url" name="babystreet_video_bckgr_url" value="' . esc_attr($values['babystreet_video_bckgr_url']) . '" class="large-text" />';

		// Start time
		$output .= '<p><label for="babystreet_video_bckgr_start"><b>' . esc_html__("Start time in seconds", 'babystreet-plugin') . '</b></label></p>';
		$output .= '<input type="text" id="babystreet_video_bckgr_start" name="babystreet_video_bckgr_start" value="' . esc_attr($values['babystreet_video_bckgr_start']) . '" size="8" />';

		// End time
		$output .= '<p><label for="babystreet_video_bckgr_end"><b>' . esc_html__("End time in seconds", 'babystreet-plugin') . '</b></label></p>';
		$output .= '<input type="text" id="babystreet_video_bckgr_end" name="babystreet_video_bckgr_end" value="' . esc_attr($values['babystreet_video_bckgr_end']) . '" size="8" />';

		// Loop
		$output .= '<p><label for="babystreet_video_bckgr_loop">';
		$output .= "<input type='checkbox' id='babystreet_video_bckgr_loop' name='babystreet_video_bckgr_loop' value='1' " . checked(esc_attr($values['babystreet_video_bckgr_loop']), 1, false) . "><b>" . esc_html__("Loop", 'babystreet-plugin') . "</b></label></p>";

		// Mute
		$output .= '<p><label for="babystreet_video_bckgr_mute">';
		$output .= "<input type='checkbox' id='babystreet_video_bckgr_mute' name='babystreet_video_bckgr_mute' value='1' " . checked(esc_attr($values['babystreet_video_bckgr_mute']), 1, false) . "><b>" . esc_html__("Mute", 'babystreet-plugin') . "</b></label></p>";


		echo $output; // All dynamic data escaped
	}

}

/* When the post is saved, saves our custom data */
if (!function_exists('babystreet_save_video_bckgr_postdata')) {

	function babystreet_save_video_bckgr_postdata($post_id) {
		global $pagenow;

		// verify if this is an auto save routine.
		// If it is our form has not been submitted, so we dont want to do anything
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
			return;
		}

		// verify this came from our screen and with proper authorization,
		// because save_post can be triggered at other times

		if (isset($_POST['video_bckgr_nonce']) && !wp_verify_nonce($_POST['video_bckgr_nonce'], 'babystreet_save_video_bckgr_postdata')) {
			return;
		}

		if (!current_user_can('edit_pages', $post_id)) {
			return;
		}

		if ('post-new.php' == $pagenow) {
			return;
		}

		if (isset($_POST['babystreet_video_bckgr_url'])) {
			update_post_meta($post_id, "babystreet_video_bckgr_url", esc_url($_POST['babystreet_video_bckgr_url']));
		}
		if (isset($_POST['babystreet_video_bckgr_start'])) {
			update_post_meta($post_id, "babystreet_video_bckgr_start", sanitize_text_field($_POST['babystreet_video_bckgr_start']));
		}
		if (isset($_POST['babystreet_video_bckgr_end'])) {
			update_post_meta($post_id, "babystreet_video_bckgr_end", sanitize_text_field($_POST['babystreet_video_bckgr_end']));
		}
		if (isset($_POST['babystreet_video_bckgr_loop']) && $_POST['babystreet_video_bckgr_loop']) {
			update_post_meta($post_id, "babystreet_video_bckgr_loop", 1);
		} else {
			update_post_meta($post_id, "babystreet_video_bckgr_loop", 0);
		}
		if (isset($_POST['babystreet_video_bckgr_mute']) && $_POST['babystreet_video_bckgr_mute']) {
			update_post_meta($post_id, "babystreet_video_bckgr_mute", 1);
		} else {
			update_post_meta($post_id, "babystreet_video_bckgr_mute", 0);
		}
	}

}

/**
 * Supersized slider
 */
add_action('add_meta_boxes', 'babystreet_add_supersized_slider_metabox');
add_action('save_post', 'babystreet_save_supersized_slider_postdata');

/* Adds a box to the side column on the Post and Page edit screens */
if (!function_exists('babystreet_add_supersized_slider_metabox')) {

	function babystreet_add_supersized_slider_metabox() {

		$posttypes = array('page', 'post', 'babystreet-portfolio', 'tribe_events');
		if (BABYSTREET_PLUGIN_IS_WOOCOMMERCE) {
			$posttypes[] = 'product';
		}
		if (BABYSTREET_PLUGIN_IS_BBPRESS) {
			$posttypes[] = 'forum';
			$posttypes[] = 'topic';
		}

		foreach ($posttypes as $pt) {
			add_meta_box(
							'babystreet_supersized_slider', esc_html__('Supersized Slider', 'babystreet-plugin'), 'babystreet_supersized_slider_callback', $pt, 'side'
			);
		}
	}

}

/* Prints the box content */
if (!function_exists('babystreet_supersized_slider_callback')) {

	function babystreet_supersized_slider_callback($post) {

		// If current page is set as Blog page - don't show the options
		if ($post->ID == get_option('page_for_posts')) {
			echo esc_html__("Supersized slider is disabled for this page, because the page is set as Blog page from Settings->Reading.", 'babystreet-plugin');
			return;
		}

		// If current page is set as Shop page - don't show the options
		if (BABYSTREET_PLUGIN_IS_WOOCOMMERCE && $post->ID == wc_get_page_id('shop')) {
			echo esc_html__("Supersized slider is disabled for this page, because the page is set as Shop page.", 'babystreet-plugin');
			return;
		}

		// Use nonce for verification
		wp_nonce_field('babystreet_save_supersized_slider_postdata', 'babystreet_supersized_slider');

		$custom = get_post_custom($post->ID);

		// get stored ids
		$image_ids = '';
		if (array_key_exists('babystreet_super_slider_ids', $custom)) {
			$image_ids = $custom['babystreet_super_slider_ids'][0];
		}
		$ids_arr = array();
		if ($image_ids) {
			$ids_arr = explode(';', $image_ids);
		}

		// description
		$output = '<p>' . esc_html__("Select images for the Supersized slider which will be used for this page/post.", 'babystreet-plugin') . '</p>';

		$output .= '<input id="babystreet_super_slider_ids" name="babystreet_super_slider_ids" type="hidden" value="' . esc_attr($image_ids) . '" />';
		$output .= '<input type="button" value="' . esc_html__('Manage images', 'babystreet-plugin') . '" id="upload_babystreet_super_slider_ids" class="babystreet_upload_image_button is_multiple" data-uploader_title="' . esc_attr__('Choose Supersized Images', 'babystreet-plugin') . '" data-uploader_button_text="' . esc_attr__('Insert', 'babystreet-plugin') . '">';

		$output .= '<div id="babystreet_super_slider_ids_images">';

		foreach ($ids_arr as $id) {
			$image_arr = wp_get_attachment_image_src($id, 'babystreet-general-small-size');
			$output .= '<img src="' . esc_url($image_arr[0]) . '">';
		}

		$output .= '</div>';

		echo $output; // All dynamic data escaped
	}

}

/* When the post is saved, saves our custom data */
if (!function_exists('babystreet_save_supersized_slider_postdata')) {

	function babystreet_save_supersized_slider_postdata($post_id) {
		// verify if this is an auto save routine.
		// If it is our form has not been submitted, so we dont want to do anything
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
			return;
		}

		// verify this came from our screen and with proper authorization,
		// because save_post can be triggered at other times

		if (isset($_POST['babystreet_supersized_slider']) && !wp_verify_nonce($_POST['babystreet_supersized_slider'], 'babystreet_save_supersized_slider_postdata')) {
			return;
		}

		if (!current_user_can('edit_pages', $post_id)) {
			return;
		}

		if (isset($_POST['babystreet_super_slider_ids'])) {
			update_post_meta($post_id, "babystreet_super_slider_ids", sanitize_text_field($_POST['babystreet_super_slider_ids']));
		}
	}

}

/**
 * Portfolio CPT metaboxes
 */
add_action('add_meta_boxes', 'babystreet_add_portfolio_metabox');
add_action('save_post', 'babystreet_save_portfolio_postdata');

/* Adds the custom fields for babystreet-portfolio CPT */
if (!function_exists('babystreet_add_portfolio_metabox')) {

	function babystreet_add_portfolio_metabox() {
		add_meta_box(
						'babystreet_portfolio_details', esc_html__('Portfolio details', 'babystreet-plugin'), 'babystreet_portfolio_callback', 'babystreet-portfolio', 'normal', 'high'
		);
	}

}

/* Prints the portfolio content */
if (!function_exists('babystreet_portfolio_callback')) {

	function babystreet_portfolio_callback($post) {
		// Use nonce for verification
		wp_nonce_field('babystreet_save_portfolio_postdata', 'babystreet_portfolio_nonce');

		echo '<h4>' . esc_html__('Fill any of the following fields. If you leave some of them empty, they won\'t show on the page.', 'babystreet-plugin') . '</h4>';

		echo '<label for="babystreet_client">';
		_e('Brand', 'babystreet-plugin');
		echo '</label> ';
		echo '<div><input type="text" id="babystreet_client" name="babystreet_client" value="' . esc_attr(get_post_meta($post->ID, 'babystreet_client', true)) . '" class="regular-text" /></div>';

		echo '<label for="babystreet_collection">';
		_e('Collection', 'babystreet-plugin');
		echo '</label> ';
		echo '<div><input type="text" id="babystreet_collection" name="babystreet_collection" value="' . esc_attr(get_post_meta($post->ID, 'babystreet_collection', true)) . '" class="regular-text" /></div>';

		echo '<label for="babystreet_materials">';
		_e('Materials', 'babystreet-plugin');
		echo '</label> ';
		echo '<div><input type="text" id="babystreet_materials" name="babystreet_materials" value="' . esc_attr(get_post_meta($post->ID, 'babystreet_materials', true)) . '" class="regular-text" /></div>';

		echo '<label for="babystreet_model">';
		_e('Model', 'babystreet-plugin');
		echo '</label> ';
		echo '<div><input type="text" id="babystreet_model" name="babystreet_model" value="' . esc_attr(get_post_meta($post->ID, 'babystreet_model', true)) . '" class="regular-text" /></div>';

		echo '<label for="babystreet_status">';
		_e('Current status of project', 'babystreet-plugin');
		echo '</label> ';
		echo '<div><input type="text" id="babystreet_status" name="babystreet_status" value="' . esc_attr(get_post_meta($post->ID, 'babystreet_status', true)) . '" class="regular-text" /></div>';


		echo '<h4>' . esc_html__('Project External Links:', 'babystreet-plugin') . '</h4>';
		echo '<label for="babystreet_ext_link_button_title">';
		_e('First Button Title', 'babystreet-plugin');
		echo '</label> ';
		echo '<div><input type="text" id="babystreet_ext_link_button_title" name="babystreet_ext_link_button_title" value="' . esc_attr(get_post_meta($post->ID, 'babystreet_ext_link_button_title', true)) . '" class="regular-text" /></div>';

		echo '<label for="babystreet_ext_link_url">';
		_e('First Button Url', 'babystreet-plugin');
		echo '</label> ';
		echo '<div><input type="text" id="babystreet_ext_link_url" name="babystreet_ext_link_url" value="' . esc_attr(get_post_meta($post->ID, 'babystreet_ext_link_url', true)) . '" class="regular-text" /></div>';

		echo '<label for="babystreet_ext_link_button_2_title">';
		_e('Second Button Title', 'babystreet-plugin');
		echo '</label> ';
		echo '<div><input type="text" id="babystreet_ext_link_button_2_title" name="babystreet_ext_link_button_2_title" value="' . esc_attr(get_post_meta($post->ID, 'babystreet_ext_link_button_2_title', true)) . '" class="regular-text" /></div>';

		echo '<label for="babystreet_ext_link_url_2">';
		_e('Second Button Url', 'babystreet-plugin');
		echo '</label> ';
		echo '<div><input type="text" id="babystreet_ext_link_url_2" name="babystreet_ext_link_url_2" value="' . esc_attr(get_post_meta($post->ID, 'babystreet_ext_link_url_2', true)) . '" class="regular-text" /></div>';

		echo '<h4>' . esc_html__('Project features list:', 'babystreet-plugin') . '</h4>';

		echo '<div><input type="text" id="babystreet_feature_1" name="babystreet_feature_1" value="' . esc_attr(get_post_meta($post->ID, 'babystreet_feature_1', true)) . '" class="regular-text" /></div>';
		echo '<div><input type="text" id="babystreet_feature_2" name="babystreet_feature_2" value="' . esc_attr(get_post_meta($post->ID, 'babystreet_feature_2', true)) . '" class="regular-text" /></div>';
		echo '<div><input type="text" id="babystreet_feature_3" name="babystreet_feature_3" value="' . esc_attr(get_post_meta($post->ID, 'babystreet_feature_3', true)) . '" class="regular-text" /></div>';
		echo '<div><input type="text" id="babystreet_feature_4" name="babystreet_feature_4" value="' . esc_attr(get_post_meta($post->ID, 'babystreet_feature_4', true)) . '" class="regular-text" /></div>';
		echo '<div><input type="text" id="babystreet_feature_5" name="babystreet_feature_5" value="' . esc_attr(get_post_meta($post->ID, 'babystreet_feature_5', true)) . '" class="regular-text" /></div>';
		echo '<div><input type="text" id="babystreet_feature_6" name="babystreet_feature_6" value="' . esc_attr(get_post_meta($post->ID, 'babystreet_feature_6', true)) . '" class="regular-text" /></div>';
		echo '<div><input type="text" id="babystreet_feature_7" name="babystreet_feature_7" value="' . esc_attr(get_post_meta($post->ID, 'babystreet_feature_7', true)) . '" class="regular-text" /></div>';
		echo '<div><input type="text" id="babystreet_feature_8" name="babystreet_feature_8" value="' . esc_attr(get_post_meta($post->ID, 'babystreet_feature_8', true)) . '" class="regular-text" /></div>';
		echo '<div><input type="text" id="babystreet_feature_9" name="babystreet_feature_9" value="' . esc_attr(get_post_meta($post->ID, 'babystreet_feature_9', true)) . '" class="regular-text" /></div>';
		echo '<div><input type="text" id="babystreet_feature_10" name="babystreet_feature_10" value="' . esc_attr(get_post_meta($post->ID, 'babystreet_feature_10', true)) . '" class="regular-text" /></div>';

		echo '<h4>' . esc_html__('Short Description', 'babystreet-plugin') . '</h4>';
		wp_editor(wp_kses_post(get_post_meta($post->ID, 'babystreet_add_description', true)), 'babystreetadddescription', $settings = array('textarea_name' => 'babystreet_add_description', 'textarea_rows' => 5));
	}

}

/* When the portfolio is saved, saves our custom data */
if (!function_exists('babystreet_save_portfolio_postdata')) {

	function babystreet_save_portfolio_postdata($post_id) {

		// Check if our nonce is set.
		if (!isset($_POST['babystreet_portfolio_nonce'])) {
			return;
		}

		// Verify that the nonce is valid.
		if (!wp_verify_nonce($_POST['babystreet_portfolio_nonce'], 'babystreet_save_portfolio_postdata')) {
			return;
		}

		// If this is an autosave, our form has not been submitted, so we don't want to do anything.
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
			return;
		}

		// Check the user's permissions.
		if (isset($_POST['post_type']) && 'page' === $_POST['post_type']) {

			if (!current_user_can('edit_pages', $post_id)) {
				return;
			}
		} else {

			if (!current_user_can('edit_posts', $post_id)) {
				return;
			}
		}

		/* OK, it's safe for us to save the data now. */
		// Make sure that it is set.
		if (!isset($_POST['babystreet_collection'], $_POST['babystreet_materials'], $_POST['babystreet_client'], $_POST['babystreet_model'], $_POST['babystreet_status'], $_POST['babystreet_ext_link_button_title'], $_POST['babystreet_ext_link_url'], $_POST['babystreet_ext_link_button_2_title'], $_POST['babystreet_ext_link_url_2'], $_POST['babystreet_feature_1'], $_POST['babystreet_feature_2'], $_POST['babystreet_feature_3'], $_POST['babystreet_feature_4'], $_POST['babystreet_feature_5'], $_POST['babystreet_feature_6'], $_POST['babystreet_feature_7'], $_POST['babystreet_feature_8'], $_POST['babystreet_feature_9'], $_POST['babystreet_feature_10'], $_POST['babystreet_add_description'])) {
			return;
		}

		update_post_meta($post_id, 'babystreet_collection', sanitize_text_field($_POST['babystreet_collection']));
		update_post_meta($post_id, 'babystreet_materials', sanitize_text_field($_POST['babystreet_materials']));
		update_post_meta($post_id, 'babystreet_client', sanitize_text_field($_POST['babystreet_client']));
		update_post_meta($post_id, 'babystreet_model', sanitize_text_field($_POST['babystreet_model']));
		update_post_meta($post_id, 'babystreet_status', sanitize_text_field($_POST['babystreet_status']));
		update_post_meta($post_id, 'babystreet_ext_link_button_title', sanitize_text_field($_POST['babystreet_ext_link_button_title']));
		update_post_meta($post_id, 'babystreet_ext_link_url', esc_url($_POST['babystreet_ext_link_url']));
		update_post_meta($post_id, 'babystreet_ext_link_button_2_title', sanitize_text_field($_POST['babystreet_ext_link_button_2_title']));
		update_post_meta($post_id, 'babystreet_ext_link_url_2', esc_url($_POST['babystreet_ext_link_url_2']));
		update_post_meta($post_id, 'babystreet_feature_1', sanitize_text_field($_POST['babystreet_feature_1']));
		update_post_meta($post_id, 'babystreet_feature_2', sanitize_text_field($_POST['babystreet_feature_2']));
		update_post_meta($post_id, 'babystreet_feature_3', sanitize_text_field($_POST['babystreet_feature_3']));
		update_post_meta($post_id, 'babystreet_feature_4', sanitize_text_field($_POST['babystreet_feature_4']));
		update_post_meta($post_id, 'babystreet_feature_5', sanitize_text_field($_POST['babystreet_feature_5']));
		update_post_meta($post_id, 'babystreet_feature_6', sanitize_text_field($_POST['babystreet_feature_6']));
		update_post_meta($post_id, 'babystreet_feature_7', sanitize_text_field($_POST['babystreet_feature_7']));
		update_post_meta($post_id, 'babystreet_feature_8', sanitize_text_field($_POST['babystreet_feature_8']));
		update_post_meta($post_id, 'babystreet_feature_9', sanitize_text_field($_POST['babystreet_feature_9']));
		update_post_meta($post_id, 'babystreet_feature_10', sanitize_text_field($_POST['babystreet_feature_10']));
		update_post_meta($post_id, 'babystreet_add_description', wp_kses_post($_POST['babystreet_add_description']));
	}

}

/**
 * Register additional featured images metaboxes (5)
 */
add_action('add_meta_boxes', 'babystreet_add_additonal_featured_meta');
add_action('save_post', 'babystreet_save_additonal_featured_meta_postdata');

/* Adds a box to the side column on the Page/Post/Portfolio edit screens */
if (!function_exists('babystreet_add_additonal_featured_meta')) {

	function babystreet_add_additonal_featured_meta() {
		$post_types_array = array('page', 'post', 'babystreet-portfolio', 'tribe_events');

		for ($i = 2; $i <= 6; $i++) {
			foreach ($post_types_array as $post_type) {
				add_meta_box(
								'babystreet_featured_' . $i, esc_html__('Featured Image', 'babystreet-plugin') . ' ' . $i, 'babystreet_additonal_featured_meta_callback', $post_type, 'side', 'default', array('num' => $i)
				);
			}
		}
	}

}

/* Prints the box content */
if (!function_exists('babystreet_additonal_featured_meta_callback')) {

	function babystreet_additonal_featured_meta_callback($post, $args) {
		// Use nonce for verification
		wp_nonce_field('babystreet_save_additonal_featured_meta_postdata', 'babystreet_featuredmeta');

		$num = esc_attr($args['args']['num']);

		$image_id = get_post_meta(
						$post->ID, 'babystreet_featured_imgid_' . $num, true
		);

		$add_link_style = '';
		$del_link_style = '';

		$output = '<p class="hide-if-no-js">';
		$output .= '<span id="babystreet_featured_imgid_' . esc_attr($num) . '_images" class="babystreet_featured_img_holder">';

		if ($image_id) {
			$add_link_style = 'style="display:none"';
			$output .= wp_get_attachment_image($image_id, 'medium');
		} else {
			$del_link_style = 'style="display:none"';
		}

		$output .= '</span>';
		$output .= '</p>';

		$output .= '<p class="hide-if-no-js">';
		$output .= '<input id="babystreet_featured_imgid_' . esc_attr($num) . '" name="babystreet_featured_imgid_' . esc_attr($num) . '" type="hidden" value="' . esc_attr($image_id) . '" />';

		// delete link
		$output .= '<a id="delete_babystreet_featured_imgid_' . esc_attr($num) . '" ' . wp_kses_data($del_link_style) . ' class="babystreet_delete_image_button" href="#" title="' . esc_attr__('Remove featured image', 'babystreet-plugin') . ' ' . esc_attr($num) . '">' . esc_html__('Remove featured image', 'babystreet-plugin') . ' ' . esc_attr($num) . '</a>';

		// add link
		$output .= '<a id="upload_babystreet_featured_imgid_' . esc_attr($num) . '" ' . wp_kses_data($add_link_style) . ' data-uploader_title="' . esc_attr__('Select Featured Image', 'babystreet-plugin') . ' ' . esc_attr($num) . '" data-uploader_button_text="' . esc_attr__('Set Featured Image', 'babystreet-plugin') . ' ' . esc_attr($num) . '" class="babystreet_upload_image_button is_upload_link" href="#" title="' . esc_attr__('Set featured image', 'babystreet-plugin') . ' ' . esc_attr($num) . '">' . esc_html__('Set featured image', 'babystreet-plugin') . ' ' . esc_attr($num) . '</a>';


		$output .= '</p>';

		echo $output; // All dynamic data escaped
	}

}

/* When the post is saved, saves our custom data */
if (!function_exists('babystreet_save_additonal_featured_meta_postdata')) {

	function babystreet_save_additonal_featured_meta_postdata($post_id) {
		// verify if this is an auto save routine.
		// If it is our form has not been submitted, so we dont want to do anything
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
			return;
		}

		// verify this came from our screen and with proper authorization,
		// because save_post can be triggered at other times

		if (isset($_POST['babystreet_featuredmeta']) && !wp_verify_nonce($_POST['babystreet_featuredmeta'], 'babystreet_save_additonal_featured_meta_postdata')) {
			return;
		}

		if (!current_user_can('edit_pages', $post_id)) {
			return;
		}

		foreach ($_POST as $key => $value) {
			if (strstr($key, 'babystreet_featured_imgid_')) {
				update_post_meta($post_id, sanitize_key($key), sanitize_text_field($value));
			}
		}
	}

}

/**
 * Register Portfolio enable Cloud Zoom metabox
 */
add_action('add_meta_boxes', 'babystreet_add_portfolio_cz_metabox');
add_action('save_post', 'babystreet_save_portfolio_cz_postdata');

if (!function_exists('babystreet_add_portfolio_cz_metabox')) {

	function babystreet_add_portfolio_cz_metabox() {
		add_meta_box(
						'babystreet_portfolio_cz', esc_html__('Portfolio Options', 'babystreet-plugin'), 'babystreet_portfolio_cz_callback', 'babystreet-portfolio', 'side', 'low'
		);
	}

}

/* Prints the box content */
if (!function_exists('babystreet_portfolio_cz_callback')) {

	function babystreet_portfolio_cz_callback($post) {

		// Use nonce for verification
		wp_nonce_field('babystreet_save_portfolio_cz_postdata', 'portfolio_cz_nonce');

		$custom = get_post_custom($post->ID);

		// Set default
		$babystreet_prtfl_custom_content = 0;
		$babystreet_prtfl_gallery = 'flex';

		if (isset($custom['babystreet_prtfl_custom_content']) && $custom['babystreet_prtfl_custom_content'][0]) {
			$babystreet_prtfl_custom_content = $custom['babystreet_prtfl_custom_content'][0];
		}
		if (isset($custom['babystreet_prtfl_gallery']) && $custom['babystreet_prtfl_gallery'][0]) {
			$babystreet_prtfl_gallery = $custom['babystreet_prtfl_gallery'][0];
		}

		$output = '<p><b>' . esc_html__('Custom Content:', 'babystreet-plugin') . '</b></p>';

		$output .= '<p><label for="babystreet_prtfl_custom_content">';
		$output .= "<input type='checkbox' id='babystreet_prtfl_custom_content' name='babystreet_prtfl_custom_content' value='1' " .
						checked(esc_attr($babystreet_prtfl_custom_content), 1, false) . ">" .
						esc_html__("Don't use the portfolio gallery and all portfolio related fields. Use only the content.", 'babystreet-plugin') . "</label></p>";

		$output .= '<p><b>' . esc_html__('Portfolio gallery will appear as:', 'babystreet-plugin') . '</b></p>';

		$output .= '<div><input id="babystreet_prtfl_gallery_flex" ' . checked($babystreet_prtfl_gallery, 'flex', false) . ' type="radio" value="flex" name="babystreet_prtfl_gallery">';
		$output .= '<label for="babystreet_prtfl_gallery_flex">' . esc_html__('Flex Slider', 'babystreet-plugin') . '</label></div>';
		$output .= '<div><input id="babystreet_prtfl_gallery_cloud" ' . checked($babystreet_prtfl_gallery, 'cloud', false) . ' type="radio" value="cloud" name="babystreet_prtfl_gallery">';
		$output .= '<label for="babystreet_prtfl_gallery_cloud">' . esc_html__('Cloud Zoom', 'babystreet-plugin') . '</label></div>';
		$output .= '<div><input id="babystreet_prtfl_gallery_list" ' . checked($babystreet_prtfl_gallery, 'list', false) . ' type="radio" value="list" name="babystreet_prtfl_gallery">';
		$output .= '<label for="babystreet_prtfl_gallery_list">' . esc_html__('Image List', 'babystreet-plugin') . '</label></div>';

		echo $output; // All dynamic data escaped
	}

}

/* When the post is saved, saves our custom data */
if (!function_exists('babystreet_save_portfolio_cz_postdata')) {

	function babystreet_save_portfolio_cz_postdata($post_id) {
		// verify if this is an auto save routine.
		// If it is our form has not been submitted, so we dont want to do anything
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
			return;
		}

		// verify this came from our screen and with proper authorization,
		// because save_post can be triggered at other times

		if (isset($_POST['portfolio_cz_nonce']) && !wp_verify_nonce($_POST['portfolio_cz_nonce'], 'babystreet_save_portfolio_cz_postdata')) {
			return;
		}

		// Check the user's permissions.
		if (isset($_POST['post_type']) && 'page' === $_POST['post_type']) {

			if (!current_user_can('edit_pages', $post_id)) {
				return;
			}
		} else {

			if (!current_user_can('edit_posts', $post_id)) {
				return;
			}
		}

		if (isset($_POST['babystreet_prtfl_custom_content']) && $_POST['babystreet_prtfl_custom_content']) {
			update_post_meta($post_id, "babystreet_prtfl_custom_content", 1);
		} else {
			update_post_meta($post_id, "babystreet_prtfl_custom_content", 0);
		}

		// It is checkbox - if is in the post - is set, if not - is not set
		if (isset($_POST['babystreet_prtfl_gallery'])) {
			update_post_meta($post_id, "babystreet_prtfl_gallery", sanitize_text_field($_POST['babystreet_prtfl_gallery']));
		}
	}

}

/**
 * Register product video option for products
 */
add_action('add_meta_boxes', 'babystreet_add_product_video_metabox');
add_action('save_post', 'babystreet_save_product_video_postdata');

/* Adds a box to the side column on the Page edit screens */
if (!function_exists('babystreet_add_product_video_metabox')) {

	function babystreet_add_product_video_metabox() {
		add_meta_box(
			'babystreet_product_video', esc_html__('Product Video', 'babystreet-plugin'), 'babystreet_product_video_callback', 'product', 'side'
		);
	}

}

/* Prints the box content */
if (!function_exists('babystreet_product_video_callback')) {

	function babystreet_product_video_callback($post) {

		// Use nonce for verification
		wp_nonce_field('babystreet_save_product_video_postdata', 'product_video_nonce');

		$custom = get_post_custom($post->ID);

		// Set default values
		$values = array(
			'babystreet_product_video_url' => ''
		);

		if (isset($custom['babystreet_product_video_url']) && $custom['babystreet_product_video_url'][0] != '') {
			$values['babystreet_product_video_url'] = esc_attr($custom['babystreet_product_video_url'][0]);
		}

		// description
		$output = '<p>' . esc_html__("Product Video to be displayed on the product page (YouTube, Vimeo, Self-hosted).", 'babystreet-plugin') . '</p>';

		// Video URL
		$output .= '<p><label for="babystreet_product_video_url"><b>' . esc_html__("Video URL", 'babystreet-plugin') . '</b></label></p>';
		$output .= '<input type="text" id="babystreet_product_video_url" name="babystreet_product_video_url" value="' . esc_attr($values['babystreet_product_video_url']) . '" class="large-text" />';

		echo $output; // All dynamic data escaped
	}

}

/* When the post is saved, saves our custom data */
if (!function_exists('babystreet_save_product_video_postdata')) {

	function babystreet_save_product_video_postdata($post_id) {
		global $pagenow;

		// verify if this is an auto save routine.
		// If it is our form has not been submitted, so we dont want to do anything
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
			return;
		}

		// verify this came from our screen and with proper authorization,
		// because save_post can be triggered at other times

		if (isset($_POST['product_video_nonce']) && !wp_verify_nonce($_POST['product_video_nonce'], 'babystreet_save_product_video_postdata')) {
			return;
		}

		if (!current_user_can('edit_pages', $post_id)) {
			return;
		}

		if ('post-new.php' == $pagenow) {
			return;
		}

		if (isset($_POST['babystreet_product_video_url'])) {
			update_post_meta($post_id, "babystreet_product_video_url", esc_url($_POST['babystreet_product_video_url']));
		}
	}

}

/**
 * Register product gallery type
 */
add_action('add_meta_boxes', 'babystreet_add_product_gallery_type_metabox');
add_action('save_post', 'babystreet_save_product_gallery_type_postdata');

/* Adds a box to the side column on the Page edit screens */
if (!function_exists('babystreet_add_product_gallery_type_metabox')) {

	function babystreet_add_product_gallery_type_metabox() {
		add_meta_box(
			'babystreet_product_gallery_type', esc_html__('Product Gallery Type', 'babystreet-plugin'), 'babystreet_product_gallery_type_callback', 'product', 'side'
		);
	}

}

/* Prints the box content */
if (!function_exists('babystreet_product_gallery_type_callback')) {

	function babystreet_product_gallery_type_callback($post) {

		// Use nonce for verification
		wp_nonce_field('babystreet_save_product_gallery_type_postdata', 'product_gallery_type_nonce');

		$saved_value = get_post_meta($post->ID, 'babystreet_single_product_gallery_type', true);

        // Set default values
		$value = 'default';

		if (isset($saved_value) && $saved_value != '') {
			$value = $saved_value;
		}

		$output = '';
		$choose_menu_options = array(
		        'default' => '- '. esc_html__("Use Theme Options Setting", 'babystreet-plugin') . ' -',
		        'woo_default' => esc_html__("WooCommerce Default Gallery", 'babystreet-plugin'),
		        'image_list' => esc_html__("Image List Gallery", 'babystreet-plugin'),
		        'mosaic_images' => esc_html__("Mosaic Images Gallery", 'babystreet-plugin')
		);
		$output .= '<p><label for="babystreet_single_product_gallery_type"><b>' . esc_html__("Choose between default WooCommerce gallery and image list gallery.", 'babystreet-plugin') . '</b></label></p>';
		$output .= "<select name='babystreet_single_product_gallery_type'>";

		// Add a default option
		foreach ($choose_menu_options as $key => $val) {
			$output .= "<option value='" . esc_attr($key) . "' " . esc_attr(selected($value, $key, false)) . " >" . esc_html($val) . "</option>";
		}
		$output .= "</select>";

		echo $output;
	}

}

/* When the post is saved, saves our custom data */
if (!function_exists('babystreet_save_product_gallery_type_postdata')) {

	function babystreet_save_product_gallery_type_postdata($post_id) {

		// verify if this is an auto save routine.
		// If it is our form has not been submitted, so we dont want to do anything
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
			return;
		}

		// verify this came from our screen and with proper authorization,
		// because save_post can be triggered at other times

		if (isset($_POST['product_gallery_type_nonce']) && !wp_verify_nonce($_POST['product_gallery_type_nonce'], 'babystreet_save_product_gallery_type_postdata')) {
			return;
		}

		if (!current_user_can('edit_pages', $post_id)) {
			return;
		}

		if (isset($_POST['babystreet_single_product_gallery_type'])) {
			update_post_meta($post_id, "babystreet_single_product_gallery_type", sanitize_text_field($_POST['babystreet_single_product_gallery_type']));
		}
	}

}