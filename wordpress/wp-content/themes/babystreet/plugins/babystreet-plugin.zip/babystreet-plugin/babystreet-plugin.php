<?php

/*
  Plugin Name: Babystreet Plugin
  Plugin URI: http://www.althemist.com/
  Description: Plugin containing the Babystreet theme functionality
  Version: 1.1.3
  Author: theAlThemist
  Author URI: http://www.althemist.com/
  Author Email: visibleone@gmail.com
  WC requires at least: 3.3
  WC tested up to: 3.7
  License: Themeforest Split Licence
  License URI: -
 */
defined( 'ABSPATH' ) || exit;

// Check if WooCommerce is active
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) || class_exists('WooCommerce') ) {
	define('BABYSTREET_PLUGIN_IS_WOOCOMMERCE', TRUE);
} else {
	define('BABYSTREET_PLUGIN_IS_WOOCOMMERCE', FALSE);
}

// Check if bbPress is active
if (class_exists('bbPress')) {
	define('BABYSTREET_PLUGIN_IS_BBPRESS', TRUE);
} else {
	define('BABYSTREET_PLUGIN_IS_BBPRESS', FALSE);
}

if ( in_array( 'revslider/revslider.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) || class_exists('RevSliderBase') ) {
	define('BABYSTREET_PLUGIN_IS_REVOLUTION', TRUE);
} else {
	define('BABYSTREET_PLUGIN_IS_REVOLUTION', FALSE);
}

// Check if WC Marketplace is active
if ( in_array( 'dc-woocommerce-multi-vendor/dc_product_vendor.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) || class_exists('WCMp') ) {
	define('BABYSTREET_PLUGIN_IS_WC_MARKETPLACE', TRUE);
} else {
	define('BABYSTREET_PLUGIN_IS_WC_MARKETPLACE', FALSE);
}

add_action('plugins_loaded', 'babystreet_plugin_after_plugins_loaded' );
add_action( 'plugins_loaded', 'babystreet_wc_variation_swatches_constructor' );

function babystreet_plugin_after_plugins_loaded() {
	load_plugin_textdomain('babystreet-plugin', FALSE, dirname(plugin_basename(__FILE__)) . '/languages/');

	/* independent widgets */
	foreach (array('BabystreetAboutWidget', 'BabystreetContactsWidget', 'BabystreetPaymentOptionsWidget', 'BabystreetPopularPostsWidget', 'BabystreetLatestProjectsWidget') as $file) {
		require_once( plugin_dir_path(__FILE__) . 'widgets/' . $file . '.php' );
	}

	if(BABYSTREET_PLUGIN_IS_WOOCOMMERCE) {
		/* WooCommerce dependent widgets */
		foreach ( array( 'BabystreetProductFilterWidget' ) as $file ) {
			require_once( plugin_dir_path( __FILE__ ) . 'widgets/wc_widgets/' . $file . '.php' );
		}

		require_once(plugin_dir_path( __FILE__ ) . '/incl/woocommerce-metaboxes.php');

		// subcategories after 3.3.1 - will need refactoring in future
		remove_filter( 'woocommerce_product_loop_start', 'woocommerce_maybe_show_product_subcategories' );
	}

	/* shortcodes */
	require_once( plugin_dir_path(__FILE__) . 'shortcodes/shortcodes.php' );

	/* Map all Babystreet shortcodes to VC */
	add_action('vc_before_init', 'babystreet_integrateWithVC');
	require_once( plugin_dir_path(__FILE__) . 'shortcodes/shortcodes_to_vc_mapping.php' );

	/* Load variation product swatches */
	require_once( plugin_dir_path(__FILE__) . 'incl/swatches/variation-swatches.php' );

	/* include metaboxes.php */
	require_once( plugin_dir_path(__FILE__) . '/incl/metaboxes.php');

	/* include customizer class */
	require_once( plugin_dir_path(__FILE__) . '/incl/customizer/class-babystreet-customizer.php');

    // Removed because causes categories to appear twice in shop and category view.
    // Functionality not lost, because "woocommerce_maybe_show_product_subcategories" is called
	remove_filter( 'woocommerce_product_loop_start', 'woocommerce_maybe_show_product_subcategories' );
}

// Fix bbpress  Notice: bp_setup_current_user was called incorrectly
if (class_exists( 'bbPress' )) {
	remove_action('set_current_user', 'bbp_setup_current_user', 10);
	add_action('set_current_user', 'babystreet_bbp_setup_current_user', 10);
}

if (!function_exists('babystreet_bbp_setup_current_user')) {

	function babystreet_bbp_setup_current_user() {
		do_action('bbp_setup_current_user');
	}

}

if (!function_exists('get_plugin_data')) {
	include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}

if (!defined('BABYSTREET_PLUGIN_IMAGES_PATH')) {
	define('BABYSTREET_PLUGIN_IMAGES_PATH', plugins_url('/assets/image/', plugin_basename(__FILE__)));
}

/**
 * Generate excerpt by post Id
 *
 * @param type $post_id
 * @param type $excerpt_length
 * @param type $dots_to_link
 * @return string
 */
if (!function_exists('babystreet_get_excerpt_by_id')) {

	function babystreet_get_excerpt_by_id($post_id, $excerpt_length = 35, $dots_to_link = false) {

		$the_post = get_post($post_id); //Gets post
		$the_excerpt = strip_tags($the_post->post_excerpt);
		$the_excerpt = '<p>' . $the_excerpt . '</p>';

		return $the_excerpt;
	}

}

/**
 * Define Portfolio custom post type
 * 'babystreet-portfolio'
 */
if (!function_exists('babystreet_register_cpt_babystreet_portfolio')) {
	add_action('init', 'babystreet_register_cpt_babystreet_portfolio', 5);

	function babystreet_register_cpt_babystreet_portfolio() {

		$labels = array(
				'name' => esc_html__('Portfolios', 'babystreet-plugin'),
				'singular_name' => esc_html__('Portfolio', 'babystreet-plugin'),
				'add_new' => esc_html__('Add New', 'babystreet-plugin'),
				'add_new_item' => esc_html__('Add New Portfolio', 'babystreet-plugin'),
				'edit_item' => esc_html__('Edit Portfolio', 'babystreet-plugin'),
				'new_item' => esc_html__('New Portfolio', 'babystreet-plugin'),
				'view_item' => esc_html__('View Portfolio', 'babystreet-plugin'),
				'search_items' => esc_html__('Search Portfolios', 'babystreet-plugin'),
				'not_found' => esc_html__('No portfolios found', 'babystreet-plugin'),
				'not_found_in_trash' => esc_html__('No portfolios found in Trash', 'babystreet-plugin'),
				'parent_item_colon' => esc_html__('Parent Portfolio:', 'babystreet-plugin'),
				'menu_name' => esc_html__('Portfolios', 'babystreet-plugin'),
		);

		$args = array(
				'labels' => $labels,
				'hierarchical' => false,
				'description' => 'Babystreet portfolio post type',
				'supports' => array('title', 'editor', 'excerpt', 'author', 'thumbnail', 'trackbacks', 'revisions', 'page-attributes'),
				'taxonomies' => array('babystreet_portfolio_category'),
				'public' => true,
				'show_ui' => true,
				'show_in_menu' => true,
				'show_in_nav_menus' => true,
				'publicly_queryable' => true,
				'exclude_from_search' => false,
				'has_archive' => true,
				'query_var' => true,
				'can_export' => true,
				'rewrite' => true,
				'capability_type' => 'page',
				'menu_icon' => 'dashicons-portfolio',
				'rewrite' => array(
						'slug' => esc_html__('portfolios', 'babystreet-plugin')
				)
		);

		register_post_type('babystreet-portfolio', $args);
	}

}

/**
 * Define babystreet_portfolio_category taxonomy
 * used by babystreet-portfolio post type
 */
if (!function_exists('babystreet_register_taxonomy_babystreet_portfolio_category')) {
	add_action('init', 'babystreet_register_taxonomy_babystreet_portfolio_category', 5);

	function babystreet_register_taxonomy_babystreet_portfolio_category() {

		$labels = array(
				'name' => esc_html__('Portfolio Category', 'babystreet-plugin'),
				'singular_name' => esc_html__('Portfolio categories', 'babystreet-plugin'),
				'search_items' => esc_html__('Search Portfolio Category', 'babystreet-plugin'),
				'popular_items' => esc_html__('Popular Portfolio Category', 'babystreet-plugin'),
				'all_items' => esc_html__('All Portfolio Category', 'babystreet-plugin'),
				'parent_item' => esc_html__('Parent Portfolio categories', 'babystreet-plugin'),
				'parent_item_colon' => esc_html__('Parent Portfolio categories:', 'babystreet-plugin'),
				'edit_item' => esc_html__('Edit Portfolio categories', 'babystreet-plugin'),
				'update_item' => esc_html__('Update Portfolio categories', 'babystreet-plugin'),
				'add_new_item' => esc_html__('Add New Portfolio categories', 'babystreet-plugin'),
				'new_item_name' => esc_html__('New Portfolio categories', 'babystreet-plugin'),
				'separate_items_with_commas' => esc_html__('Separate portfolio category with commas', 'babystreet-plugin'),
				'add_or_remove_items' => esc_html__('Add or remove portfolio category', 'babystreet-plugin'),
				'choose_from_most_used' => esc_html__('Choose from the most used portfolio category', 'babystreet-plugin'),
				'menu_name' => esc_html__('Portfolio Category', 'babystreet-plugin'),
		);

		$args = array(
				'labels' => $labels,
				'public' => true,
				'show_in_nav_menus' => true,
				'show_ui' => true,
				'show_tagcloud' => true,
				'show_admin_column' => false,
				'hierarchical' => true,
				'rewrite' => true,
				'query_var' => true,
				'rewrite' => array(
						'slug' => 'portfolios-category'
				)
		);

		register_taxonomy('babystreet_portfolio_category', array('babystreet-portfolio'), $args);
	}

}

add_action('init', 'babystreet_theme_options_link');
if(!function_exists('babystreet_theme_options_link')) {
	function babystreet_theme_options_link() {
		if ( wp_get_theme()->get_template() === 'babystreet' && current_user_can( 'edit_theme_options' ) ) {
			add_action( 'wp_before_admin_bar_render', 'babystreet_optionsframework_adminbar' );
		}
	}
}

/**
 * Add Theme Options menu item to Admin Bar.
 */
if(!function_exists('babystreet_optionsframework_adminbar')) {
	function babystreet_optionsframework_adminbar() {

		global $wp_admin_bar;

		$wp_admin_bar->add_menu( array(
			'parent' => false,
			'id'     => 'babystreet_of_theme_options',
			'title'  => esc_html__( 'Theme Options', 'babystreet-plugin' ),
			'href'   => esc_url( admin_url( 'themes.php?page=babystreet-optionsframework' ) ),
			'meta'   => array( 'class' => 'althemist-admin-opitons' )
		) );
	}
}

// Register scripts
add_action('wp_enqueue_scripts', 'babystreet_register_plugin_scripts');
if (!function_exists('babystreet_register_plugin_scripts')) {

	function babystreet_register_plugin_scripts() {

		// flexslider
		wp_enqueue_script('flexslider', get_template_directory_uri() . "/js/flex/jquery.flexslider-min.js", array('jquery'), '2.2.2', true);
		wp_enqueue_style('flexslider', get_template_directory_uri() . "/styles/flex/flexslider.css", array(), '2.2.2');

		// owl-carousel
		wp_enqueue_script('owl-carousel', get_template_directory_uri() . "/js/owl-carousel2-dist/owl.carousel.min.js", array('jquery'), '2.0.0', true);
		wp_enqueue_style('owl-carousel', get_template_directory_uri() . "/styles/owl-carousel2-dist/assets/owl.carousel.min.css", array(), '2.0.0');
		wp_enqueue_style('owl-carousel-theme-default', get_template_directory_uri() . "/styles/owl-carousel2-dist/assets/owl.theme.default.min.css", array(), '2.0.0');
		wp_enqueue_style('owl-carousel-animate', get_template_directory_uri() . "/styles/owl-carousel2-dist/assets/animate.css", array(), '2.0.0');

		// cloud-zoom
		wp_enqueue_script('cloud-zoom', get_template_directory_uri() . "/js/cloud-zoom/cloud-zoom.1.0.2.min.js", array('jquery'), '1.0.2', true);
		wp_enqueue_style('cloud-zoom', get_template_directory_uri() . "/styles/cloud-zoom/cloud-zoom.css", array(), '1.0.2');

		// countdown
		wp_enqueue_script('countdown', get_template_directory_uri() . "/js/count/jquery.countdown.min.js", array('jquery'), '2.0.0', true);

		// magnific
		wp_enqueue_script('magnific', get_template_directory_uri() . "/js/magnific/jquery.magnific-popup.min.js", array('jquery'), '1.0.0', true);
		wp_enqueue_style('magnific', get_template_directory_uri() . "/styles/magnific/magnific-popup.css", array(), '1.0.2');

		// appear
		wp_enqueue_script('appear', get_template_directory_uri() . "/js/jquery.appear.min.js", array('jquery'), '1.0.0', true);

		// appear
		wp_enqueue_script('typed', get_template_directory_uri() . "/js/typed.min.js", array('jquery'), '1.0.0', true);

		// nice-select
		wp_enqueue_script('nice-select', get_template_directory_uri() . "/js/jquery.nice-select.min.js", array('jquery'), '1.0.0', true);

		// is-in-viewport
		wp_enqueue_script('is-in-viewport', get_template_directory_uri() . "/js/isInViewport.min.js", array('jquery'), '1.0.0', true);

		// Isotope
		wp_register_script('isotope', get_template_directory_uri() . "/js/isotope/dist/isotope.pkgd.min.js", array('jquery', 'imagesloaded'), false, true);
		// google maps
        if(function_exists('babystreet_get_option')) {
	        wp_register_script( 'google-maps', 'https://maps.googleapis.com/maps/api/js?' . ( babystreet_get_option( 'google_maps_api_key' ) ? 'key=' . babystreet_get_option( 'google_maps_api_key' ) . '&' : '' ) . 'sensor=false', array( 'jquery' ), false, true );
        }
	}

}

// Register scripts
add_action('admin_enqueue_scripts', 'babystreet_register_admin_plugin_scripts');
if (!function_exists('babystreet_register_admin_plugin_scripts')) {
	function babystreet_register_admin_plugin_scripts() {
		// ajax upload files
		wp_enqueue_script( 'plupload' );
		wp_enqueue_script( 'babystreet-plugin-admin', plugins_url( 'assets/js/babystreet-plugin-admin.js', __FILE__ ), array( 'plupload' ), false, true );
		wp_localize_script('babystreet-plugin-admin', 'localise', array(
			'confirm_import_1' => esc_html__('Confirm importing settings from', 'babystreet-plugin'),
			'confirm_import_2' => esc_html__('. Current Theme Options will be overwritten. Continue?', 'babystreet-plugin'),
			'import_success' => esc_html__('Options successfully imported. Reloading.', 'babystreet-plugin'),
			'upload_error' => esc_html__('There was a problem with the upload. Error', 'babystreet-plugin'),
			'export_url' => esc_url( add_query_arg( 'action', 'babystreet_options_export', admin_url( 'admin-post.php' ) ) )
		));
	}
}

// Enqueue the script for proper positioning the custom added font in vc edit form
add_filter('vc_edit_form_enqueue_script', 'babystreet_enqueue_edit_form_scripts');
if (!function_exists('babystreet_enqueue_edit_form_scripts')) {

	function babystreet_enqueue_edit_form_scripts($scripts) {
		$scripts[] = plugin_dir_url(__FILE__) . 'assets/js/babystreet-vc-edit-form.js';
		return $scripts;
	}

}

add_filter('vc_iconpicker-type-etline', 'babystreet_vc_iconpicker_type_etline');

/**
 * Elegant Icons Font icons
 *
 * @param $icons - taken from filter - vc_map param field settings['source'] provided icons (default empty array).
 * If array categorized it will auto-enable category dropdown
 *
 * @since 4.4
 * @return array - of icons for iconpicker, can be categorized, or not.
 */
if (!function_exists('babystreet_vc_iconpicker_type_etline')) {

	function babystreet_vc_iconpicker_type_etline($icons) {
		// Categorized icons ( you can also output simple array ( key=> value ), where key = icon class, value = icon readable name ).
		$etline_icons = array(
				array('icon-mobile' => 'Mobile'),
				array('icon-laptop' => 'Laptop'),
				array('icon-desktop' => 'Desktop'),
				array('icon-tablet' => 'Tablet'),
				array('icon-phone' => 'Phone'),
				array('icon-document' => 'Document'),
				array('icon-documents' => 'Documents'),
				array('icon-search' => 'Search'),
				array('icon-clipboard' => 'Clipboard'),
				array('icon-newspaper' => 'Newspaper'),
				array('icon-notebook' => 'Notebook'),
				array('icon-book-open' => 'Open'),
				array('icon-browser' => 'Browser'),
				array('icon-calendar' => 'Calendar'),
				array('icon-presentation' => 'Presentation'),
				array('icon-picture' => 'Picture'),
				array('icon-pictures' => 'Pictures'),
				array('icon-video' => 'Video'),
				array('icon-camera' => 'Camera'),
				array('icon-printer' => 'Printer'),
				array('icon-toolbox' => 'Toolbox'),
				array('icon-briefcase' => 'Briefcase'),
				array('icon-wallet' => 'Wallet'),
				array('icon-gift' => 'Gift'),
				array('icon-bargraph' => 'Bargraph'),
				array('icon-grid' => 'Grid'),
				array('icon-expand' => 'Expand'),
				array('icon-focus' => 'Focus'),
				array('icon-edit' => 'Edit'),
				array('icon-adjustments' => 'Adjustments'),
				array('icon-ribbon' => 'Ribbon'),
				array('icon-hourglass' => 'Hourglass'),
				array('icon-lock' => 'Lock'),
				array('icon-megaphone' => 'Megaphone'),
				array('icon-shield' => 'Shield'),
				array('icon-trophy' => 'Trophy'),
				array('icon-flag' => 'Flag'),
				array('icon-map' => 'Map'),
				array('icon-puzzle' => 'Puzzle'),
				array('icon-basket' => 'Basket'),
				array('icon-envelope' => 'Envelope'),
				array('icon-streetsign' => 'Streetsign'),
				array('icon-telescope' => 'Telescope'),
				array('icon-gears' => 'Gears'),
				array('icon-key' => 'Key'),
				array('icon-paperclip' => 'Paperclip'),
				array('icon-attachment' => 'Attachment'),
				array('icon-pricetags' => 'Pricetags'),
				array('icon-lightbulb' => 'Lightbulb'),
				array('icon-layers' => 'Layers'),
				array('icon-pencil' => 'Pencil'),
				array('icon-tools' => 'Tools'),
				array('icon-tools-2' => '2'),
				array('icon-scissors' => 'Scissors'),
				array('icon-paintbrush' => 'Paintbrush'),
				array('icon-magnifying-glass' => 'Glass'),
				array('icon-circle-compass' => 'Compass'),
				array('icon-linegraph' => 'Linegraph'),
				array('icon-mic' => 'Mic'),
				array('icon-strategy' => 'Strategy'),
				array('icon-beaker' => 'Beaker'),
				array('icon-caution' => 'Caution'),
				array('icon-recycle' => 'Recycle'),
				array('icon-anchor' => 'Anchor'),
				array('icon-profile-male' => 'Male'),
				array('icon-profile-female' => 'Female'),
				array('icon-bike' => 'Bike'),
				array('icon-wine' => 'Wine'),
				array('icon-hotairballoon' => 'Hotairballoon'),
				array('icon-globe' => 'Globe'),
				array('icon-genius' => 'Genius'),
				array('icon-map-pin' => 'Pin'),
				array('icon-dial' => 'Dial'),
				array('icon-chat' => 'Chat'),
				array('icon-heart' => 'Heart'),
				array('icon-cloud' => 'Cloud'),
				array('icon-upload' => 'Upload'),
				array('icon-download' => 'Download'),
				array('icon-target' => 'Target'),
				array('icon-hazardous' => 'Hazardous'),
				array('icon-piechart' => 'Piechart'),
				array('icon-speedometer' => 'Speedometer'),
				array('icon-global' => 'Global'),
				array('icon-compass' => 'Compass'),
				array('icon-lifesaver' => 'Lifesaver'),
				array('icon-clock' => 'Clock'),
				array('icon-aperture' => 'Aperture'),
				array('icon-quote' => 'Quote'),
				array('icon-scope' => 'Scope'),
				array('icon-alarmclock' => 'Alarmclock'),
				array('icon-refresh' => 'Refresh'),
				array('icon-happy' => 'Happy'),
				array('icon-sad' => 'Sad'),
				array('icon-facebook' => 'Facebook'),
				array('icon-twitter' => 'Twitter'),
				array('icon-googleplus' => 'Googleplus'),
				array('icon-rss' => 'Rss'),
				array('icon-tumblr' => 'Tumblr'),
				array('icon-linkedin' => 'Linkedin'),
				array('icon-dribbble' => 'Dribbble'),
		);

		return array_merge($icons, $etline_icons);
	}

}

add_filter('vc_iconpicker-type-flaticon', 'babystreet_vc_iconpicker_type_flaticon');

/**
 * Flaticon Icons Font icons
 *
 * @param $icons - taken from filter - vc_map param field settings['source'] provided icons (default empty array).
 * If array categorized it will auto-enable category dropdown
 *
 * @since 4.4
 * @return array - of icons for iconpicker, can be categorized, or not.
 */
if (!function_exists('babystreet_vc_iconpicker_type_flaticon')) {

	function babystreet_vc_iconpicker_type_flaticon($icons) {
		// Categorized icons ( you can also output simple array ( key=> value ), where key = icon class, value = icon readable name ).
		$flaticon_icons = array(
			array('flaticon-3-standing-archives' => '3 standing archives'),
			array('flaticon-auricular-of-a-phone' => 'auricular of a phone'),
			array('flaticon-bag-with-handle' => 'bag with handle'),
			array('flaticon-baggage-doodle' => 'baggage'),
			array('flaticon-bar-graphic-doodle' => 'bar graphic'),
			array('flaticon-basket-doodle' => 'basket'),
			array('flaticon-blank-paper-doodle' => 'blank paper'),
			array('flaticon-blank-tag-doodle' => 'blank tag'),
			array('flaticon-calculator-doodle' => 'calculator'),
			array('flaticon-cd-with-shines' => 'cd with shines'),
			array('flaticon-chart-presentation-doodle' => 'chart presentation'),
			array('flaticon-circles-doodle' => 'circles'),
			array('flaticon-circular-grid' => 'circular grid'),
			array('flaticon-clip-doodle' => 'clip'),
			array('flaticon-clipboard-with-filled-out-paper' => 'clipboard with filled out paper'),
			array('flaticon-clipboard-with-paper' => 'clipboard with paper'),
			array('flaticon-clothing-hanger-doodle' => 'clothing hanger'),
			array('flaticon-computer-doodle-outline' => 'computer'),
			array('flaticon-computer-mouse-draw' => 'computer mouse draw'),
			array('flaticon-cross-mark' => 'cross mark'),
			array('flaticon-cup-doodle' => 'cup'),
			array('flaticon-cut-flag' => 'cut flag'),
			array('flaticon-database-gross-rustic-lines-symbol' => 'database gross rustic lines'),
			array('flaticon-dollar-sign-inside-oval-shape' => 'dollar sign inside oval shape'),
			array('flaticon-doodle-frame' => 'frame'),
			array('flaticon-draw-bag' => 'bag'),
			array('flaticon-draw-battery-charging-status' => 'battery charging status'),
			array('flaticon-draw-bible-book-with-bookmark' => 'bible book with bookmark'),
			array('flaticon-draw-boat' => 'boat'),
			array('flaticon-draw-calendar' => 'calendar'),
			array('flaticon-draw-calendar-day-five' => 'calendar day five'),
			array('flaticon-draw-cellular-phone' => 'cellular phone'),
			array('flaticon-draw-check-mark' => 'check mark'),
			array('flaticon-draw-computer-screen' => 'computer screen'),
			array('flaticon-draw-credit-card' => 'credit card'),
			array('flaticon-draw-directional-compass' => 'directional compass'),
			array('flaticon-draw-film-strip' => 'film strip'),
			array('flaticon-draw-flag' => 'flag'),
			array('flaticon-draw-information-sign' => 'information sign'),
			array('flaticon-draw-magnifying-lens' => 'magnifying lens'),
			array('flaticon-draw-mercury-thermometer-with-high-temperature' => 'mercury thermometer with high temperature'),
			array('flaticon-draw-pie-graph' => 'pie graph'),
			array('flaticon-draw-printer-with-paper' => 'printer with paper'),
			array('flaticon-draw-star' => 'star'),
			array('flaticon-draw-t-shirt' => 't-shirt'),
			array('flaticon-draw-upload-arrow' => 'upload arrow'),
			array('flaticon-drawn-drawer' => 'drawer'),
			array('flaticon-drawn-fence' => 'fence'),
			array('flaticon-envelope-doodle' => 'envelope'),
			array('flaticon-floppy-disk-doodle' => 'floppy disk'),
			array('flaticon-flower-with-petals' => 'flower with petals'),
			array('flaticon-full-inbox-doodle' => 'full inbox'),
			array('flaticon-game-control-doodle' => 'game control'),
			array('flaticon-gift-bag' => 'gift bag'),
			array('flaticon-half-filled-battery-status-doodle' => 'half filled battery status'),
			array('flaticon-hammer-and-wrench-doodle' => 'hammer and wrench'),
			array('flaticon-heart-doodle' => 'heart'),
			array('flaticon-large-pointer' => 'large pointer'),
			array('flaticon-lightbulb-doodle-with-shine' => 'lightbulb'),
			array('flaticon-line-graph-doodle' => 'line graph'),
			array('flaticon-locked-padlock' => 'locked padlock'),
			array('flaticon-microphone-drawing' => 'microphone'),
			array('flaticon-mobile-gaming-device' => 'mobile gaming device'),
			array('flaticon-mouse-arrow' => 'mouse arrow'),
			array('flaticon-music-quaver-draw' => 'music quaver'),
			array('flaticon-network-forum-avatar-doodle' => 'network forum avatar'),
			array('flaticon-open-box-doodle' => 'open box'),
			array('flaticon-open-empty-folder-outline' => 'open empty folder'),
			array('flaticon-open-padlock' => 'open padlock'),
			array('flaticon-origami-airplane' => 'origami airplane'),
			array('flaticon-painting-palette' => 'painting palette'),
			array('flaticon-plus-sign' => 'plus sign'),
			array('flaticon-power-button-doodle' => 'power button'),
			array('flaticon-recycling-sign-doodle' => 'recycling'),
			array('flaticon-rewind-arrow-draw' => 'rewind arrow'),
			array('flaticon-rounded-draw-airplane' => 'airplane'),
			array('flaticon-shooting-target-doodle' => 'shooting target'),
			array('flaticon-shop-cart-doodle' => 'shop cart'),
			array('flaticon-small-palm-tree' => 'small palm tree'),
			array('flaticon-speech-bubble' => 'speech bubble'),
			array('flaticon-speech-bubble-with-text-doodle' => 'speech bubble with text'),
			array('flaticon-spring-binder-notebook' => 'spring binder notebook'),
			array('flaticon-star-doodle' => 'star'),
			array('flaticon-suitcase-doodle' => 'suitcase'),
			array('flaticon-text-page-doodle' => 'text page'),
			array('flaticon-tiny-cloud' => 'tiny cloud'),
			array('flaticon-trash-bin-doodle' => 'trash bin'),
			array('flaticon-up-arrow-draw' => 'up arrow'),
			array('flaticon-upside-down-wifi-symbol' => 'upside down wifi symbol'),
			array('flaticon-user-information-doodle' => 'user information'),
			array('flaticon-volume-levels-or-bars-graph' => 'volume levels or bars graph'),
		);

		return array_merge($icons, $flaticon_icons);
	}

}

if (!function_exists('babystreet_portfolio_category_field_search')) {

	function babystreet_portfolio_category_field_search($search_string) {
		$data = array();

		$vc_taxonomies_types = array('babystreet_portfolio_category');
		$vc_taxonomies = get_terms($vc_taxonomies_types, array(
				'hide_empty' => false,
				'search' => $search_string,
		));
		if (is_array($vc_taxonomies) && !empty($vc_taxonomies)) {
			foreach ($vc_taxonomies as $t) {
				if (is_object($t)) {
					$data[] = vc_get_term_object($t);
				}
			}
		}

		return $data;
	}

}

if (!function_exists('babystreet_latest_posts_category_field_search')) {

	function babystreet_latest_posts_category_field_search($search_string) {
		$data = array();

		$vc_taxonomies_types = array('category');
		$vc_taxonomies = get_terms($vc_taxonomies_types, array(
				'hide_empty' => false,
				'search' => $search_string,
		));
		if (is_array($vc_taxonomies) && !empty($vc_taxonomies)) {
			foreach ($vc_taxonomies as $t) {
				if (is_object($t)) {
					$data[] = vc_get_term_object($t);
				}
			}
		}

		return $data;
	}

}
add_action('admin_init', 'babystreet_load_incl_importer', 99);
if (!function_exists('babystreet_load_incl_importer')) {

	function babystreet_load_incl_importer() {
		/* load required files */

        // Load Importer API
		require_once ABSPATH . 'wp-admin/includes/import.php';

		if (!class_exists('WP_Importer')) {
			$class_wp_importer = ABSPATH . 'wp-admin/includes/class-wp-importer.php';
			if (file_exists($class_wp_importer)) {
				require_once $class_wp_importer;
			}
		}

		$class_babystreet_importer = plugin_dir_path(__FILE__) . "importer/babystreet-wordpress-importer.php";
		if (file_exists($class_babystreet_importer)) {
			require_once $class_babystreet_importer;
		}
	}

}

// Contact form ajax actions
if (!function_exists('babystreet_submit_contact')) {

	function babystreet_submit_contact() {

		check_ajax_referer('babystreet_contactform', false, true);

		$unique_id = array_key_exists('unique_id', $_POST) ? sanitize_text_field($_POST['unique_id']) : '';
		$nonce = array_key_exists('_ajax_nonce', $_POST) ? sanitize_text_field($_POST['_ajax_nonce']) : '';

		ob_start();
		?>
		<script>
            //<![CDATA[
            "use strict";
            jQuery(document).ready(function () {
                var submitButton = jQuery('#holder_<?php echo esc_js($unique_id) ?> input:submit');
                var loader = jQuery('<img id="<?php echo esc_js($unique_id) ?>_loading_gif" class="babystreet-contacts-loading" src="<?php echo esc_url(plugin_dir_url(__FILE__)) ?>assets/image/contacts_ajax_loading.png" />').prependTo('#holder_<?php echo esc_attr($unique_id) ?> div.buttons div.left').hide();

                jQuery('#holder_<?php echo esc_js($unique_id) ?> form').ajaxForm({
                    target: '#holder_<?php echo esc_js($unique_id) ?>',
                    data: {
                        // additional data to be included along with the form fields
                        unique_id: '<?php echo esc_js($unique_id) ?>',
                        action: 'babystreet_submit_contact',
                        _ajax_nonce: '<?php echo esc_js($nonce); ?>'
                    },
                    beforeSubmit: function (formData, jqForm, options) {
                        // optionally process data before submitting the form via AJAX
                        submitButton.hide();
                        loader.show();
                    },
                    success: function (responseText, statusText, xhr, $form) {
                        // code that's executed when the request is processed successfully
                        loader.remove();
                        submitButton.show();
                    }
                });
            });
            //]]>
		</script>
		<?php
		require(plugin_dir_path( __FILE__ ) . 'shortcodes/partials/contact-form.php');

		$output = ob_get_contents();
		ob_end_clean();

		echo $output; // All dynamic data escaped
		wp_die();
	}

}

add_action('wp_ajax_babystreet_submit_contact', 'babystreet_submit_contact');
add_action('wp_ajax_nopriv_babystreet_submit_contact', 'babystreet_submit_contact');

//function to generate response
if (!function_exists('babystreet_contact_form_generate_response')) {

	function babystreet_contact_form_generate_response($type, $message) {

		$babystreet_contactform_response = '';

		if ($type == "success") {
			$babystreet_contactform_response = "<div class='success-message'>{$message}</div>";
		} else {
			$babystreet_contactform_response .= "<div class='error-message'>{$message}</div>";
		}

		return $babystreet_contactform_response;
	}

}

if (!function_exists('babystreet_share_links')) {

	/**
	 * Displays social networks share links
	 *
	 * @param $title
	 * @param $link
	 */
    function babystreet_share_links($title, $link) {

        $has_to_show_share = babystreet_has_to_show_share();

        if ( $has_to_show_share ) {
	        global $post;

	        $media = get_the_post_thumbnail_url( $post->ID, 'large' );
	        $share_links_html = '<span>' . esc_html__( 'Share', 'babystreet-plugin' ) . ':</span>';

            $share_links_html .= sprintf(
                '<a class="babystreet-share-facebook" title="%s" href="http://www.facebook.com/sharer.php?u=%s&t=%s" target="_blank" ></a>',
                esc_attr__( 'Share on Facebook', 'babystreet-plugin' ),
                urlencode( $link ),
	            urlencode( html_entity_decode($title) )
            );
	        $share_links_html .= sprintf(
		        '<a class="babystreet-share-twitter"  title="%s" href="http://twitter.com/share?text=%s&url=%s" target="_blank"></a>',
		        esc_attr__( 'Share on Twitter', 'babystreet-plugin' ),
		        urlencode( html_entity_decode($title) ),
                urlencode( $link )
	        );
	        $share_links_html .= sprintf(
		        '<a class="babystreet-share-pinterest" title="%s"  href="http://pinterest.com/pin/create/button?media=%s&url=%s&description=%s" target="_blank"></a>',
		        esc_attr__( 'Share on Pinterest', 'babystreet-plugin' ),
		        urlencode( $media ),
		        urlencode( $link ),
		        urlencode( html_entity_decode($title) )
	        );
	        $share_links_html .= sprintf(
		        '<a class="babystreet-share-linkedin" title="%s" href="http://www.linkedin.com/shareArticle?url=%s&title=%s" target="_blank"></a>',
		        esc_attr__( 'Share on LinkedIn', 'babystreet-plugin' ),
		        urlencode( $link ),
		        urlencode( html_entity_decode($title) )
	        );
	        $share_links_html .= sprintf(
		        '<a class="babystreet-share-vkontakte" title="%s"  href="http://vk.com/share.php?url=%s&title=%s&image=%s" target="_blank"></a>',
		        esc_attr__( 'Share on VK', 'babystreet-plugin' ),
		        urlencode( $link ),
		        urlencode( html_entity_decode($title) ),
		        urlencode( $media )
	        );

            printf( '<div class="babystreet-share-links">%s<div class="clear"></div></div>', $share_links_html );
        }

    }
}

add_action('wp_head', 'babystreet_insert_og_tags');
if (!function_exists('babystreet_insert_og_tags')) {
	/**
	 * Insert og tags sharers
	 */
    function babystreet_insert_og_tags() {
        global $post;

        if(is_singular() && babystreet_has_to_show_share()) {
            $large_size_width = get_option( "large_size_w" );
	        $large_size_height = get_option( "large_size_h" );

	        printf( '<meta property="og:image" content="%s">', get_the_post_thumbnail_url( $post->ID, 'large' ) );
	        printf( '<meta property="og:image:width" content="%d">', $large_size_width );
	        printf( '<meta property="og:image:height" content="%d">', $large_size_height );
        }
    }
}

if (!function_exists('babystreet_has_to_show_share')) {
	function babystreet_has_to_show_share() {

		if(function_exists('babystreet_get_option')) {
			$general_option = get_option( 'babystreet_share_on_posts' ) === 'yes';
			if ( ! get_option( 'babystreet_share_on_posts' ) && function_exists( 'babystreet_get_option' ) ) {
				$general_option = babystreet_get_option( 'show_share_general' );
			}
			$general_option_product = get_option( 'babystreet_share_on_products' ) === 'yes';
			if ( ! get_option( 'babystreet_share_on_products' ) && function_exists( 'babystreet_get_option' ) ) {
				$general_option_product = babystreet_get_option( 'show_share_shop' );
			}
			$single_meta            = get_post_meta( get_the_ID(), 'babystreet_show_share', true );

			$target = 'single';
			if (function_exists('is_product') && is_product()) {
			    $target = 'product';
			}

			$has_to_show_share = false;

			if ( $target === 'single' && $single_meta === 'yes' ) {
				$has_to_show_share = true;
			} elseif ( $target === 'single' && $general_option && $single_meta !== 'no' ) {
				$has_to_show_share = true;
			} elseif ( $target === 'product' && $general_option_product ) {
				$has_to_show_share = true;
			}

			return $has_to_show_share;
		}

		return false;
	}
}

add_action( 'woocommerce_single_product_summary', 'babystreet_show_custom_product_popup_link', 12 );
if ( ! function_exists( 'babystreet_show_custom_product_popup_link' ) ) {
	function babystreet_show_custom_product_popup_link() {
		if ( function_exists( 'babystreet_get_option' ) && trim( babystreet_get_option( 'custom_product_popup_link' ) ) != '' && trim( babystreet_get_option( 'custom_product_popup_content' ) ) != '' ) {
		    global $product;

			$link_text     = babystreet_get_option( 'custom_product_popup_link' );
			$popup_content = babystreet_get_option( 'custom_product_popup_content' );

			echo '<div class="babystreet-product-popup-link"><a href="#babystreet-product-' . esc_attr( $product->get_id() ) . '-popup-content" title="' . esc_attr( $link_text ) . '" >' . esc_html( $link_text ) . '</a></div>';

			echo '<div id="babystreet-product-' . esc_attr( $product->get_id() ) . '-popup-content" class="mfp-hide">';
			echo wp_kses_post( do_shortcode( $popup_content ) );
			echo '</div>';

			$inline_script_data = "(function ($) {
                $(document).ready(function () {
                    $('.babystreet-product-popup-link a').magnificPopup({
                        mainClass: 'babystreet-product-popup-content mfp-fade',
                        type: 'inline',
                        midClick: true
                    });
                });
            })(window.jQuery);";

			wp_add_inline_script( 'magnific', $inline_script_data );

		}
	}
}

// Promo info tooltips
add_action( 'woocommerce_single_product_summary', function () {
	babystreet_output_info_tooltips( 'above-price' );
}, 9 );
add_action( 'woocommerce_single_product_summary', function () {
	babystreet_output_info_tooltips( 'below-price' );
}, 11 );
add_action( 'woocommerce_single_product_summary', function () {
	babystreet_output_info_tooltips( 'below-add-to-cart' );
}, 39 );
add_action('woocommerce_after_shop_loop_item_title', function () {
	babystreet_output_info_tooltips( '', true );
}, 11);

if ( ! function_exists( 'babystreet_output_info_tooltips' ) ) {
	function babystreet_output_info_tooltips( $position, $show_in_listing = false ) {
		for ( $i = 1; $i <= 3; $i ++ ) {
			if (function_exists( 'babystreet_get_option' ) && babystreet_get_option( 'promo_tooltip_' . $i . '_trigger_text' ) && ( $position === babystreet_get_option( 'promo_tooltip_' . $i . '_position' ) || $show_in_listing && babystreet_get_option( 'promo_tooltip_' . $i . '_show_in_listing' ) ) ) {
				?>
                <div class="babystreet-promo-wrapper<?php if($position) echo ' babystreet-promo-'.$position ?>">
                    <div class="babystreet-promo-text">
						<?php echo babystreet_get_option( 'promo_tooltip_' . $i . '_text' ) ?>
                        <span class="babystreet-promo-trigger">
                            <?php echo babystreet_get_option( 'promo_tooltip_' . $i . '_trigger_text' ) ?>
                            <span class="babystreet-promo-content">
                                <?php echo babystreet_get_option( 'promo_tooltip_' . $i . '_content' ) ?>
                            </span>
                        </span>
                    </div>
                </div>
				<?php
			}
		}
	}
}

// Import theme options
add_action('wp_ajax_babystreet_options_upload', 'babystreet_options_upload');
if ( ! function_exists( 'babystreet_options_upload' ) ) {
	function babystreet_options_upload() {
		if(isset($_FILES['file']['tmp_name'])) {
			$babystreet_transfer_content = Babystreet_Transfer_Content::getInstance();
			return $babystreet_transfer_content->importSettings( $_FILES['file']['tmp_name'], false, false, false, true );
		} else {
			return false;
		}

		wp_die();
	}
}

// Export theme options
add_action( 'admin_post_babystreet_options_export', 'babystreet_options_export' );
if ( ! function_exists( 'babystreet_options_export' ) ) {
	function babystreet_options_export() {
		if ( current_user_can( 'administrator' ) ) {
			$babystreet_transfer_content = Babystreet_Transfer_Content::getInstance();
			$export_file_path       = $babystreet_transfer_content->exportThemeOptions();

			if ( file_exists( $export_file_path ) ) {
				header( 'Content-Description: File Transfer' );
				header( 'Content-Type: application/octet-stream' );
				header( 'Content-Disposition: attachment; filename="' . basename( $export_file_path ) . '"' );
				header( 'Expires: 0' );
				header( 'Cache-Control: must-revalidate' );
				header( 'Pragma: public' );
				header( 'Content-Length: ' . filesize( $export_file_path ) );
				readfile( $export_file_path );
				exit;
			} else {
				wp_redirect( admin_url( 'admin.php?page=babystreet-optionsframework' ) );
			}
		} else {
			wp_redirect(home_url());
		}
	}
}

// Allow HTML descriptions in WordPress Menu (related to Mega menu)
remove_filter('nav_menu_description', 'strip_tags');

// Allow Shortcodes in the Excerpt field
add_filter('the_excerpt', 'do_shortcode');

if ( ! function_exists( 'babystreet_default_share_on_posts' ) ) {
	function babystreet_default_share_on_posts() {
		if ( function_exists( 'babystreet_get_option' ) && babystreet_get_option( 'show_share_general' ) ) {
			return babystreet_get_option( 'show_share_general' ) ? 'yes' : 'no';
		}

		return 'no';
	}
}

if ( ! function_exists( 'babystreet_default_share_on_products' ) ) {
	function babystreet_default_share_on_products() {
		if ( function_exists( 'babystreet_get_option' ) && babystreet_get_option( 'show_share_shop' ) ) {
			return babystreet_get_option( 'show_share_shop' ) ? 'yes' : 'no';
		}

		return 'no';
	}
}